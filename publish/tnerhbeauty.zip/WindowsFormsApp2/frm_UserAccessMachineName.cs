﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;
using static tnerhbeauty.Class.invoice;

namespace tnerhbeauty
{
    public partial class frm_UserAccessMachineName : Form
    {
        int _id = 0;

        public frm_UserAccessMachineName()
        {
            InitializeComponent();
        }
        private void all_kushufat_Load(object sender, EventArgs e)
        {
            getdata();
        }

        private void getdata()
        {
            using (var db = new DataClasses1DataContext())
            {
                gv.DataSource = db.UserAccessMachineName_Views.ToList();
            }
            gv.CurrentCell = null;
        }
        //a=موافق d=حذف s=ايقاف
        private void button1_Click(object sender, EventArgs e)
        {

            char chr = Convert.ToChar((sender as Button).Tag.ToString());
            if(chr =='d')
            if (MyMessageBox.showMessage("تاكيد", massege.AskDelete, "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;
            if (gv.CurrentCell != null)
            {
                int rowindex = gv.CurrentRow.Index;
                int id = Convert.ToInt32(gv.Rows[rowindex].Cells[nameof(UserAccessMachineName.id)].Value.ToString());
                if (id > 0) 
                using (var db = new DataClasses1DataContext())
                {
                     db.mangeUserAccessMachineName(id,Session.User_login.id, chr);
                }
                getdata();
            }
            else MyMessageBox.showMessage("معلومات", "يجب تحديد صف اولا ", "", MessageBoxButtons.RetryCancel);
        }
    }
}
