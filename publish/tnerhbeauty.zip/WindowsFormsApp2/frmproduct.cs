﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;

namespace tnerhbeauty
{
    public partial class frmproduct : Form
    {
        public frmproduct()
        {
            InitializeComponent();
           
        }
        bool isrun = false;
        public async void refrsfgv()
        {
            if (isrun)
                return;
            isrun = true;
            pic_login.Visible = true;

            List<product_serch_View> qq = new List<product_serch_View>();
            qq = await cproduct.Find_product(tx_serch.Text, ch_zero.Checked, ch_store.Checked);
            qq = await cproduct.Find_product(tx_serch.Text, ch_zero.Checked, ch_store.Checked);
            gv_product.DataSource = qq.ToList();
            if (ch_store.Checked)
            {               
                gv_product.Columns[nameof(product_serch_View.store_name)].Visible = true;
            }
            else
            {
                gv_product.Columns[nameof(product_serch_View.store_name)].Visible = false;
            }
            gv_product.Columns[nameof(product_serch_View.id)].Visible = false;
            gv_product.Columns[nameof(product_serch_View.fullname)].Visible = false;
            //gv_product.Columns[nameof(product_serch_View.update_price)].Visible = false;
            gv_product.Columns[nameof(product_serch_View.store_id)].Visible = false;
            gv_product.Columns[nameof(product_serch_View.name)].HeaderText = "الاسم";
            gv_product.Columns[nameof(product_serch_View.price_buy)].HeaderText = "سعر الشراء";
            gv_product.Columns[nameof(product_serch_View.price_sale)].HeaderText = "سعر البيع محل";
            gv_product.Columns[nameof(product_serch_View.price_sale_100)].HeaderText = "سعر البيع  100";
            gv_product.Columns[nameof(product_serch_View.price_sale_75)].HeaderText = "سعر البيع 75";
            gv_product.Columns[nameof(product_serch_View.price_sale_vip2)].HeaderText = "سعر البيع VIP2";
            gv_product.Columns[nameof(product_serch_View.price_sale_vip1)].HeaderText = "سعر البيع VIP1";
            gv_product.Columns[nameof(product_serch_View.update_price)].HeaderText = "تاريخ تحديث السعر ";
            gv_product.Columns[nameof(product_serch_View.code)].HeaderText = "كود";
            gv_product.Columns[nameof(product_serch_View.is_stop)].HeaderText = "موقوف ";
            gv_product.Columns[nameof(product_serch_View.Balance)].HeaderText = "الرصيد ";
            gv_product.Columns[nameof(product_serch_View.store_name)].HeaderText = "المخزن";
            gv_product.Columns[nameof(product_serch_View.min_mum)].HeaderText = "اقل كمية";
            gv_product.Columns[nameof(product_serch_View.is_stop)].SortMode = DataGridViewColumnSortMode.Automatic;
            gv_product.CurrentCell = null;

            lp_price_buy.Text = qq.Sum(x => x.price_buy * x.Balance).ToString("0.00");
            lp_price_sale.Text = qq.Sum(x => x.price_sale * x.Balance).ToString("0.00");
            lp_price_sale_100.Text = qq.Sum(x => x.price_sale_100 * x.Balance).ToString("0.00");
            lp_price_sale_75.Text = qq.Sum(x => x.price_sale_75 * x.Balance).ToString("0.00");
            lp_price_sale_vip2.Text = qq.Sum(x => x.price_sale_vip2 * x.Balance).ToString("0.00");
            lp_price_sale_vip1.Text = qq.Sum(x => x.price_sale_vip1 * x.Balance).ToString("0.00");
            lp_price_1.Text = qq.Sum(x => x.price_1 * x.Balance).ToString("0.00");
            lp_price_2.Text = qq.Sum(x => x.price_2 * x.Balance).ToString("0.00");
            lp_price_3.Text = qq.Sum(x => x.price_3 * x.Balance).ToString("0.00");
            lp_price_4.Text = qq.Sum(x => x.price_4 * x.Balance).ToString("0.00");
            lp_price_5.Text = qq.Sum(x => x.price_5 * x.Balance).ToString("0.00");
            lp_price_6.Text = qq.Sum(x => x.price_6 * x.Balance).ToString("0.00");
            lp_price_7.Text = qq.Sum(x => x.price_7 * x.Balance).ToString("0.00");
            lp_price_8.Text = qq.Sum(x => x.price_8 * x.Balance).ToString("0.00");
            lp_price_9.Text = qq.Sum(x => x.price_9 * x.Balance).ToString("0.00");
            lp_price_10.Text = qq.Sum(x => x.price_10 * x.Balance).ToString("0.00");
            lp_total.Text = qq.Sum(x => x.Balance).ToString("0.000");
            pic_login.Visible = false;
            isrun = false;
        }
        private void gv_mariddata_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (!Session._setting.update_product)
                return;
            if (e.RowIndex < 0)
                return;
            int id = Convert.ToInt32(gv_product.Rows[e.RowIndex].Cells[nameof(product.id)].Value.ToString());
            add_product frm_add_Product = new add_product(id);
            frm_add_Product.ShowDialog();
            tx_serch_TextChanged(null, null);
        }
        private void tx_serch_TextChanged(object sender, EventArgs e)
        {
            refrsfgv();
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (gv_product.RowCount == 0)
                return;
            DataClasses1DataContext data = new DataClasses1DataContext();
            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("frmproduct", gv_product.DataSource),
            };
            frm_show_report _Report = new frm_show_report(null, "frmproduct", ReportDataSource, true);
            _Report.Show();
        }
        private void ch_zero_CheckedChanged(object sender, EventArgs e)
        {
            refrsfgv();
        }
        private void btn_export_exal_Click(object sender, EventArgs e)
        {
            if(gv_product.RowCount == 0) return;
            lb_mas.Text = "  جاري انشاء ملف الاكسيل ...";
            var xx = (List<product_serch_View>)gv_product.DataSource;
            xx.ExportListToExal("الاصناف");
            lb_mas.Text = @"تم حفظ الملف  \" + Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer" + @"\" + DateTime.Now.Ticks + "Response.xlsx" + "";
        }
        private  void frmproduct_Load(object sender, EventArgs e)
        {
            refrsfgv();
        }
    }
}
