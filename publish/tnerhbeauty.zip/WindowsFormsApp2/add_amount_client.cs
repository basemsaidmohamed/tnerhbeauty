﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using tnerhbeauty.Class;
using static tnerhbeauty.Class.Session;

namespace tnerhbeauty
{
    public partial class add_amount_client : Form
    {
        DataClasses1DataContext db;
        amount_client Amount_client;
        bool updateid = false;
        int id_type = 0;
        public add_amount_client()
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
            Amount_client = new amount_client();
        }
        public add_amount_client(int id)
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
            Amount_client = new amount_client();
            Amount_client = db.amount_clients.Where(s => s.id == id).FirstOrDefault();
            id_type = Amount_client.id_account;
            updateid = true;
        }
        private void add_marid_Load(object sender, EventArgs e)
        {
            dr_type_cach.IntializeData(Type_cash_list);
            dr_account.IntializeData(AccountClient);
            dr_account.SelectedIndex = -1;
            getdata();
        }
        void getdata()
        {
            tx_id_cient.Text = Amount_client.id_client.ToString();
            tx_amount.Value = 0;
            tx_nots.Text = Amount_client.nots;

            if (Amount_client.id != 0)
            {
                lp_titel.Text = "تعديل بيانات دفعة";
                var selctmarid = db.Clients.Where(x => x.id == Amount_client.id_client).FirstOrDefault();
                if (selctmarid != null)
                {
                    tx_name_cient.Text = selctmarid.name;
                }
                //tx_name.Text = "";
                //btn_print.Visible = true;
                tx_id_cient.Text = Amount_client.id_client.ToString();
                btn_delete.Visible = Session.User_setting().delete_amount_client;
                btn_save.Visible = Session.User_setting().update_amount_client;
                dr_account.SelectedValue = Amount_client.id_account;
                dr_type_cach.SelectedValue = db.AllAmounts.Where(x => x.Source_Id == Amount_client.id && x.id_account == id_type).FirstOrDefault().id_cash;
                tx_DateAdd.Value = Amount_client.DateAdd;
                if (Amount_client.amount_in != 0)
                    tx_amount.Value = Amount_client.amount_in;
                else tx_amount.Value = Amount_client.amount_out;
            }
            else
            {
                lp_titel.Text = "اضافة دفعة جديدة ";
                dr_account.SelectedIndex = -1;
                dr_type_cach.SelectedIndex = 0;
                tx_id_cient.Text = "";
                tx_name_cient.Text = "";
                btn_save.Visible = Session.User_setting().add_amount_client;
                btn_new.Visible = Session.User_setting().add_amount_client;
                tx_amount.Text = "";
            }

        }
        void setdata()
        {
            Amount_client.id_account = Session.ConvertInt(dr_account.SelectedValue.ToString());
            Amount_client.id_client = Session.ConvertInt(tx_id_cient.Text);
            Amount_client.amount_in = AccountClient.Where(x => x.id == Amount_client.id_account).FirstOrDefault().is_amount_in ? tx_amount.Value : 0;
            Amount_client.amount_out = AccountClient.Where(x => x.id == Amount_client.id_account).FirstOrDefault().is_amount_in ? 0 : tx_amount.Value;
            Amount_client.nots = tx_nots.Text.Replace_text();
            Amount_client.DateAdd = tx_DateAdd.Value;
            Amount_client.id_user = Session.User_login.id;
            Amount_client.id_fara = Session.User_login.id_fara;
            if (!updateid)
                Amount_client.DateServer = Session.GetDate();
        }
        private void AddAllamount()
        {
            if (updateid)
                db.AllAmounts.DeleteAllOnSubmit(db.AllAmounts.Where(x => x.Source_Id == Amount_client.id && x.id_account == id_type));
            AllAmount _AllAmount = new AllAmount();
            _AllAmount.amount = tx_amount.Value;
            _AllAmount.id_account = Amount_client.id_account;
            _AllAmount.id_cash = AccountClient.Where(x => x.id == Amount_client.id_account).FirstOrDefault().type_amount == 0 ? (int)PayMethods.no : Session.ConvertInt(dr_type_cach.SelectedValue.ToString());
            _AllAmount.nots = dr_account.Text + " " + tx_name_cient.Text;
            _AllAmount.Source_Id = Amount_client.id;
            _AllAmount.id_fara = User_login.id_fara;
            _AllAmount.id_user = User_login.id;
            _AllAmount.DateServer = Amount_client.DateServer;
            db.AllAmounts.InsertOnSubmit(_AllAmount);
            db.SubmitChanges();
        }
        bool valid()
        {
            errorProvider1.Clear();
            int error = 0;
            if (string.IsNullOrEmpty(tx_name_cient.Text.Trim()))
            {
                errorProvider1.SetError(tx_name_cient, massege.NotNull);
                error++;
            }
            if (Session.ConvertInt(tx_id_cient.Text) == 0)
            {
                errorProvider1.SetError(tx_name_cient, massege.NotNull);
                error++;
            }
            if (string.IsNullOrEmpty(tx_amount.Text.Trim()) || Session.ConvertDouble(tx_amount.Text) <= 0)
            {
                errorProvider1.SetError(tx_amount, massege.NotNull);
                error++;
            }
            if (string.IsNullOrEmpty(dr_account.Text.Trim()))
            {
                errorProvider1.SetError(dr_account, massege.NotNull);
                error++;
            }
            if (dr_type_cach.SelectedIndex == -1)
            {
                errorProvider1.SetError(dr_type_cach, massege.NotNull);
                error++;
            }
            return error == 0;
        }
        private void bt_new_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            updateid = false;
            Amount_client = new amount_client();
            getdata();
            tx_Balance.Text = "";
            tx_Balance_type.Text = "";
            tx_amount.Text = "";
            dr_account.Focus();
        }
        private void add_marid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F12)
            {
                btn_save.PerformClick();
            }
            if (e.KeyCode == Keys.F2)
            {
                btn_new.PerformClick();
            }
            if (e.KeyCode == Keys.P && e.Modifiers == Keys.Control)
            {
                btn_print.PerformClick();
            }
            if (e.KeyCode == Keys.Escape && updateid)
            {
                this.Close();
            }
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl(ActiveControl, true, true, true, true);
                if (ActiveControl is TextBox)
                {
                    TextBox tx = (TextBox)ActiveControl;
                    tx.SelectAll();
                }
            }
        }
        private void bt_save_Click(object sender, EventArgs e)
        {
            if (updateid)
                if (checkUpdate(type_.update, Amount_client.DateServer, Amount_client.id_user))
                    return;
            if (!valid())
                return;
            setdata();
            if (Amount_client.id == 0)
                db.amount_clients.InsertOnSubmit(Amount_client);

            db.SubmitChanges();
            AddAllamount();
            if (updateid)
            {
                this.Close();
                return;
            }
            btn_new.PerformClick();
            lb_mas.Text = massege.successfully;
        }
        private void bt_delete_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.delete, Amount_client.DateServer, Amount_client.id_user))
                return;
            if (MyMessageBox.showMessage("تاكيد", massege.AskDelete, "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;
            db.amount_clients.DeleteOnSubmit(Amount_client);
            db.AllAmounts.DeleteAllOnSubmit(db.AllAmounts.Where(x => x.Source_Id == Amount_client.id && x.id_account == id_type));
            db.SubmitChanges();
            this.Close();
        }
        private void bt_print_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.print, Amount_client.DateServer, Amount_client.id_user))
                return;
            //DataClasses1DataContext data = new DataClasses1DataContext();
            //ReportDataSource[] ReportDataSource = new ReportDataSource[]
            //{
            // new ReportDataSource("amount_client", data.Clients.Where(x=>x.id==Amount_client.id)),
            //};
            //frm_show_report _Report = new frm_show_report(null, "amount_client", ReportDataSource,false);
            //_Report.Show();
        }
        private void bt_aladawia_Click(object sender, EventArgs e)
        {
            selct_sick frm_Clint = new selct_sick();
            frm_Clint.ShowDialog();
            client_View client_View = frm_Clint.GetClient();
            if (client_View != null)
            {
                tx_id_cient.Text = client_View.id.ToString();
                tx_name_cient.Text = client_View.name;
                tx_Balance.Text = client_View.Balance.ToString();
                tx_Balance_type.Text = client_View.Balance_type;
            }
        }
        private void dr_account_SelectionChangeCommitted(object sender, EventArgs e)
        {            
            if (AccountClient.Where(x => x.id == (int)dr_account.SelectedValue).FirstOrDefault().type_amount == 0)
            {
                dr_type_cach.Visible = false;
                lp_type_cach.Visible = false;
            }
            else
            {
                dr_type_cach.Visible = true;
                lp_type_cach.Visible = true;
            }
        }
    }
}
