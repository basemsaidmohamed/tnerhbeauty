﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;

namespace tnerhbeauty
{
    public partial class frm_product_min_mum : Form
    {
        DataClasses1DataContext db;
        public frm_product_min_mum()
        {
            InitializeComponent();
        }
        product_min_mum_View _product_Min_Mum;
        private void all_kushufat_Load(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            gv.DataSource = new List<product_min_mum_View>();
            gv.Columns[nameof(_product_Min_Mum.id)].Visible = false;
            gv.Columns[nameof(_product_Min_Mum.fullname)].HeaderText = " اسم الصنف";
            gv.Columns[nameof(_product_Min_Mum.Balance)].HeaderText = "الرصيد الحالي";
            gv.Columns[nameof(_product_Min_Mum.min_mum)].HeaderText = "الحد الادني";
            gv.Columns[nameof(_product_Min_Mum.want)].HeaderText = "الكمية المطلوبه";
            getdata();
        }
        public void getdata()
        {
            if (ItemID != 0)
                gv.DataSource = db.product_min_mum_Views.Where(x => x.id == ItemID).ToList();
            else
                gv.DataSource = db.product_min_mum_Views.ToList();
        }
        int ItemID = 0;
        private void bt_product_Click(object sender, EventArgs e)
        {
            selct_prodct _selct_prodct = new selct_prodct();
            _selct_prodct.ShowDialog();
            product_serch_View prod = _selct_prodct.retrnval();
            if (prod != null)
            {
                ItemID = prod.id;
                tx_prodct.Text = prod.fullname;
            }
            getdata();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ItemID = 0;
            tx_prodct.Text = "";
            getdata();
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0)
                return;
            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("product_min_mum", gv.DataSource),
            };
            frm_show_report _Report = new frm_show_report(null, "frm_product_min_mum", ReportDataSource, true);
            _Report.Show();
        }

        private void btn_export_exal_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0) return;
            lb_mas.Text = "  جاري انشاء ملف الاكسيل ...";
            var xx = (List<product_min_mum_View>)gv.DataSource;
            xx.ExportListToExal(" اصناف حد الطلب " + tx_prodct.Text + " " );
            lb_mas.Text = @"تم حفظ الملف  \" + Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer" + @"\" + DateTime.Now.Ticks + "Response.xlsx" + "";
        }
    }
}

























//List<store_log_Balance_View> Store_log_Balance_View = new List<store_log_Balance_View>();

//var qq = db.store_log_Balance_Views.GroupBy(x => x.ItemID).Select(cl => new store_log_Balance_View
//{

//    ItemID = cl.First().ItemID,
//    code = cl.First().code,
//    product_name = cl.First().product_name,
//    Balance_sabk = (decimal?)cl.Where(x => x.DateAdd.Date < dt_date_from.Value.Date).Sum(x => (decimal?)x.ItemQty_in - (decimal?)x.ItemQty_out) ?? 0,
//    ItemQty_in = (decimal?)cl.Where(x => (x.DateAdd.Date >= dt_date_from.Value.Date) && (x.DateAdd.Date <= dt_date_to.Value.Date)).Sum(x => x.ItemQty_in) ?? 0,
//    ItemQty_out = (decimal?)cl.Where(x => (x.DateAdd.Date >= dt_date_from.Value.Date) && (x.DateAdd.Date <= dt_date_to.Value.Date)).Sum(x => x.ItemQty_out) ?? 0,
//    Balance = (decimal?)cl.Where(x => x.DateAdd.Date < dt_date_to.Value).Sum(x => x.ItemQty_in - x.ItemQty_out) ?? 0,
//}).ToList();

//gv.DataSource = qq;