﻿using System;
using System.Data;
using System.Deployment.Application;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using tnerhbeauty.Class;
using System.Management;
using System.Reflection;
using System.IO;
using Microsoft.Win32;

namespace tnerhbeauty
{
    public partial class login : Form
    {
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;
        public login()
        {
            InitializeComponent();
        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //private void WatchThemeChanges()
        //{
        //    SystemEvents.UserPreferenceChanged += (s, e) =>
        //    {
        //        if (e.Category == UserPreferenceCategory.General)
        //        {
        //            ApplyTheme();
        //        }
        //    };
        //}
        //public static bool IsDarkModeEnabled()
        //{
        //    const string registryKeyPath = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize";
        //    const string registryValueName = "AppsUseLightTheme";

        //    object registryValue = Registry.GetValue(registryKeyPath, registryValueName, null);
        //    return registryValue is int value && value == 0; // 0 يعني الوضع الداكن مفعل
        //}
        
        //private void ApplyTheme()
        //{
        //    if (IsDarkModeEnabled())
        //    {
        //        this.BackColor = System.Drawing.Color.Black; // خلفية داكنة
        //        this.ForeColor = System.Drawing.Color.White; // نص أبيض
        //    }
        //    else
        //    {
        //        this.BackColor = System.Drawing.Color.White; // خلفية فاتحة
        //        this.ForeColor = System.Drawing.Color.Black; // نص أسود
        //    }
        //}
        private void login_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(Assembly.GetExecutingAssembly().Location+"\n"+Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            //ApplyTheme();
            //WatchThemeChanges();
            label3.Text = "Version : " + Application.ProductVersion;
            this.ActiveControl = tx_user_name;            
            string tel = Properties.Settings.Default.tel;
            string pass = Properties.Settings.Default.pass;
            try
            {
                if (!string.IsNullOrEmpty(tel) || !string.IsNullOrEmpty(pass))
                    if (Session._User_login(tel, pass.show_Decrypt()))
                    {
                        home h = new home();
                        h.ShowDialog();
                        this.Close();
                    }
            }
            catch { }

            dr_data.SelectedIndex = -1;
        }
        private void bt_login_Click(object sender, EventArgs e)
        {
            if(tx_user_name.Text=="")
            {
                tx_user_name.Focus();
                return;
            }
            if(tx_pass.Text == "")
            {
                tx_pass.Focus();
                return;
            }
            //try
            //{
            if (Session._User_login(tx_user_name.Text, tx_pass.Text))
            {
                this.Hide();
                if (tx_pass.Text == "xxxxxx")
                {
                    ChchangePassword chchangePassword = new ChchangePassword();
                    chchangePassword.ShowDialog();
                    this.Show();
                }
                else
                {
                    if (ch_remper.Checked)
                    {
                        Properties.Settings.Default.id_user = Session.User_login.id;
                        Properties.Settings.Default.tel = tx_user_name.Text;
                        Properties.Settings.Default.pass = tx_pass.Text.hide_Encrypt();
                        Properties.Settings.Default.Save();
                    }
                    home h = new home();
                    h.ShowDialog();
                    this.Close();
                }
            }
           
            //}
            //catch 
            //{                
            //    MyMessageBox.showMessage("خطاء", "حدث خطاء اثناء الاتصال", "", MessageBoxButtons.RetryCancel); 
            //};
        }
        private void button1_Click(object sender, EventArgs e)
        {
            frm_Connection_ h = new frm_Connection_();
            h.ShowDialog();
        } 
        private void bt_update_Click(object sender, EventArgs e)
        {
            UpdateCheckInfo info;
            if (ApplicationDeployment.IsNetworkDeployed)
            {
                ApplicationDeployment ad = ApplicationDeployment.CurrentDeployment;
                try
                {
                    info = ad.CheckForDetailedUpdate();
                }
                catch (DeploymentDownloadException dde)
                {
                    MessageBox.Show("The new version of the application can't be downloaded at this time.\n\nPlease check your network connection or try again later. Error: " + dde.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                catch (InvalidDeploymentException ide)
                {
                    MessageBox.Show("Can't check for a new version of the application. The ClickOnce deployment is corrupt. Please redeploy the application and try again. Error: " + ide.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                catch (InvalidOperationException ioe)
                {
                    MessageBox.Show("This application can't be updated. It's likely not a ClickOnce application. Error: " + ioe.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (info.UpdateAvailable)
                {
                    if (MessageBox.Show("A newer version is available. Would you like to update it now ?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        try
                        {
                            ad.Update();
                            Application.Restart();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("You are running the latest version.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                System.Net.WebClient webClient = new System.Net.WebClient();
                int Version = Convert.ToInt16(Application.ProductVersion.Replace(".", ""));
                int updateVersion = Convert.ToInt16(webClient.DownloadString(new Uri("https://raw.githubusercontent.com/basemsaidmohamed/tnerhbeauty/refs/heads/main/publish/Version.txt")).Replace(".", ""));
                if (updateVersion > Version)
                {
                    if (MyMessageBox.showMessage("تنبيه ", "   متوفر نسخة احدث هل تريد التحديث الان ...؟  ", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        app_update _Update = new app_update();
                        _Update.Show();
                    }
                }
                else
                {
                    MyMessageBox.showMessage("تنبيه ", "لديك بالفعل احدث نسخة", "", MessageBoxButtons.OK);
                }
            }
        }                    
        private void login_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }            
        }
        private void login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                bt_login.PerformClick();
            }
        }      
    }
}
