﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using tnerhbeauty.Class;
namespace tnerhbeauty
{
    public partial class home : Form
    {
        DataClasses1DataContext db;
        public home()
        {
            InitializeComponent();
        }

        add_client Add_client;
        add_product Add_product;
        frmproduct Frm_Product;
        Frm_CompanyInfo Frm_CompanyInfo;
        all_client All_client;
        all_InvoiceHeader All_InvoiceHeader;
        all_prodcut_get All_prodcut_get;
        Formnew formnew;
        add_amount_client Add_amount_client;
        all_amount_client All_amount_client;
        all_amount_client_report All_amount_client_report;
        frm_store_log _frm_Store_Log;
        add_store Add_Store;
        all_store All_Store;
        add_fara Add_Fara;
        all_fara All_Fara;
        all_user All_User;
        add_setting _add_Setting;
        all_setting _all_Setting;
        frm_product_min_mum _Product_Min_Mum;
        frm_InvoiceHeader_nots _InvoiceHeader_nots;
        frm_up_product_min_mum _frm_up_product_min_mum;
        frm_All_Amount _frm_All_Amount;
        frm_store_log_stores Frm_store_log_stores;
        frm_store_log_in_out Frm_store_log_in_out;
        add_user User;
        all_type_cash all_type_cash;
        add_account _add_Account;
        add_amount _add_Amount;
        add_type_cash _add_type_cash;
        private const int WS_EX_COMPOSITED = 0x02000000;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WS_EX_COMPOSITED;
                return cp;
            }
        }
        private void home_Shown(object sender, EventArgs e)
        {
            titel();
            menuStrip1.Renderer = new MyRenderer();
            get_setting();
            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += (obj, ea) => loaddata();
            bw.RunWorkerAsync();
        }
        private async void loaddata()
        {
            try
            {
                await Task.Run(async () =>
            {
                using (var db = new DataClasses1DataContext())
                {
                    string q1 = "SELECT TOP 10 CONCAT(name, ' ', code) AS name, SUM(Balance) AS Balance FROM Balance_product_store_View GROUP BY ItemID, name, code ORDER BY SUM(Balance) DESC SELECT TOP 10  CONCAT(name, ' ', code) AS name, SUM(Balance) AS Balance FROM Balance_product_store_View GROUP BY ItemID, name, code ORDER BY SUM(Balance) DESC";
                    var maxBalanceData = await cproduct.ExecuteQuery(q1);
                    var minBalanceData = await cproduct.ExecuteQuery(" SELECT TOP 10 fullname, Balance, min_mum FROM product_min_mum_View WHERE Balance > 0 ORDER BY Balance ASC");
                    var maxSaleData = await cproduct.ExecuteQuery("  SELECT TOP 10 CONCAT(product_name, ' ', code) AS product_name, SUM(ItemQty_out) AS ItemQty_out FROM store_log_View WHERE CAST(DateAdd AS DATE) >= DATEADD(DAY, -30, GETDATE()) AND CAST(DateAdd AS DATE)  <= GETDATE() AND id_type IN (1,4) GROUP BY ItemID, product_name, code ORDER BY SUM(ItemQty_out) DESC");
                    this.Invoke(new MethodInvoker(() =>
                    {
                        gv_max_balanc.DataSource = maxBalanceData;
                        gv_min_balanc.DataSource = minBalanceData;
                        gv_max_sale.DataSource = maxSaleData;
                    }));
                }
            });
            }
            catch
            {
                ;
            }
        }
        private void SetVisibility(ToolStripMenuItem menuItem, params bool[] conditions)
        {
            menuItem.Visible = conditions.Any(condition => condition);
        }

        public void get_setting()
        {
            // إعداد اسم المستخدم والمجموعة
            this.Text += " " + $" {Session.User_login.name_fara}";
            ts_groub_login.Text = $"{Session.User_login.user_name}";
            var userSettings = Session.User_setting();

            // إعداد القوائم بناءً على الإعدادات
            SetVisibility(ts_add_invoice_pay, userSettings.add_invoice_pay);
            SetVisibility(ts_add_invoice_sale, userSettings.add_invoice_sale);
            SetVisibility(ts_add_invoice_to_store, userSettings.add_invoice_to_store);
            SetVisibility(ts_add_invoice_pay_from_store, userSettings.add_invoice_pay_from_store);
            SetVisibility(ts_add_invoice_return_to_supplier, userSettings.add_invoice_return_to_supplier);
            SetVisibility(ts_add_invoice_return_from_client, userSettings.add_invoice_return_from_client);
            SetVisibility(ts_add_invoice_taswet_edafa, userSettings.add_invoice_taswet_edafa);
            SetVisibility(ts_add_invoice_taswiat_khasm, userSettings.add_invoice_taswiat_khasm);
            SetVisibility(ts_add_invoice_broken, userSettings.add_invoice_broken);

            SetVisibility(ts_show_invoice_pay, userSettings.show_invoice_pay, userSettings.update_invoice_pay, userSettings.delete_invoice_pay);
            SetVisibility(ts_show_invoice_sale, userSettings.show_invoice_sale, userSettings.update_invoice_sale, userSettings.delete_invoice_sale);
            SetVisibility(ts_show_invoice_to_store, userSettings.show_invoice_to_store, userSettings.update_invoice_to_store, userSettings.delete_invoice_to_store);
            SetVisibility(ts_show_invoice_pay_from_store, userSettings.show_invoice_pay_from_store, userSettings.update_invoice_pay_from_store, userSettings.delete_invoice_pay_from_store);
            SetVisibility(ts_show_invoice_return_to_supplier, userSettings.show_invoice_return_to_supplier, userSettings.update_invoice_return_to_supplier, userSettings.delete_invoice_return_to_supplier);
            SetVisibility(ts_show_invoice_return_from_client, userSettings.show_invoice_return_from_client, userSettings.update_invoice_return_from_client, userSettings.delete_invoice_return_from_client);
            SetVisibility(ts_show_invoice_taswet_edafa, userSettings.show_invoice_taswet_edafa, userSettings.update_invoice_taswet_edafa, userSettings.delete_invoice_taswet_edafa);
            SetVisibility(ts_show_invoice_taswiat_khasm, userSettings.show_invoice_taswiat_khasm, userSettings.update_invoice_taswiat_khasm, userSettings.delete_invoice_taswiat_khasm);
            SetVisibility(ts_show_invoice_broken, userSettings.show_invoice_broken, userSettings.update_invoice_broken, userSettings.delete_invoice_broken);

            SetVisibility(ts_add_new_product, userSettings.add_product);
            SetVisibility(ts_show_all_product, userSettings.show_product, userSettings.update_product, userSettings.delete_product);
            SetVisibility(ts_update_price_producut, userSettings.update_price_producut);
            SetVisibility(ts_update_price_producut_exal, userSettings.update_price_producut_exal);
            SetVisibility(ts_frm_up_product_min_mum, userSettings.update_product_min_mum);

            SetVisibility(ts_kashf_hesab_prodct, userSettings.kashf_hesab_prodct);
            SetVisibility(ts_blance_in_storses, userSettings.blance_in_storses);
            SetVisibility(ts_product_min_mum, userSettings.blance_in_storses);
            SetVisibility(ts_store_in_and_out, userSettings.store_in_and_out);
            SetVisibility(ts_report_mabeat_product, userSettings.report_mabeat_product);

            SetVisibility(ts_add_new_client, userSettings.add_client);
            SetVisibility(ts_show_all_client, userSettings.show_client, userSettings.update_client, userSettings.delete_client);
            SetVisibility(ts_kashf_hesab_client, userSettings.kashf_hesab_client);
            SetVisibility(ts_add_amount_client, userSettings.add_amount_client);
            SetVisibility(ts_all_amount_client, userSettings.show_amount_client, userSettings.update_amount_client, userSettings.delete_amount_client);

            SetVisibility(ts_add_fara, userSettings.add_fara);
            SetVisibility(ts_add_store, userSettings.add_store);
            SetVisibility(ts_add_user, userSettings.add_user);
            SetVisibility(ts_add_setting, userSettings.add_setting);
            SetVisibility(ts_add_account, userSettings.add_All_account);
            SetVisibility(ts_add_type_cash, userSettings.add_type_cash);
            SetVisibility(ts_all_user_access_store, userSettings.show_UserAccessMachineName);
            SetVisibility(ts_all_fara, userSettings.show_fara, userSettings.update_fara, userSettings.delete_fara);
            SetVisibility(ts_all_store, userSettings.show_store, userSettings.update_store, userSettings.delete_store);
            SetVisibility(ts_all_user, userSettings.show_user, userSettings.update_user, userSettings.delete_user);
            SetVisibility(ts_all_setting, userSettings.show_setting, userSettings.update_setting, userSettings.delete_setting);
            SetVisibility(ts_all_account, userSettings.show_All_account, userSettings.update_All_account, userSettings.delete_All_account);
            SetVisibility(ts_all_type_cash, userSettings.show_type_cash, userSettings.update_type_cash, userSettings.delete_type_cash);


            SetVisibility(ts_add_Amount, userSettings.add_amount);
            SetVisibility(ts_all_amount, userSettings.show_amount, userSettings.update_amount, userSettings.delete_amount);
            SetVisibility(ts_report_all_amount, userSettings.report_all_amount);
            ActivateMenus();
            // إعداد المجموعات بناءً على الإعدادات
            //        ts_groub_setting.Visible = new[]
            //        {
            //            userSettings.add_setting,
            //            userSettings.show_setting,
            //            userSettings.update_setting,
            //            userSettings.delete_setting,
            //            userSettings.add_fara,
            //            userSettings.show_fara,
            //            userSettings.update_fara,
            //            userSettings.delete_fara,
            //            userSettings.add_store,
            //            userSettings.show_store,
            //            userSettings.update_store,
            //            userSettings.delete_store,
            //            userSettings.add_user,
            //            userSettings.show_user,
            //            userSettings.update_user,
            //            userSettings.delete_user,
            //            userSettings.show_type_cash,
            //            userSettings.add_type_cash,
            //            userSettings.update_type_cash,
            //            userSettings.delete_type_cash,
            //            userSettings.add_All_account,
            //            userSettings.show_All_account,
            //            userSettings.update_All_account,
            //            userSettings.delete_All_account,
            //        }.Any(setting => setting);

            //        ts_groub_invoices.Visible = new[]
            //        {
            //    userSettings.add_invoice_pay,
            //    userSettings.add_invoice_sale,
            //    userSettings.add_invoice_to_store,
            //    userSettings.add_invoice_pay_from_store,
            //    userSettings.add_invoice_return_to_supplier,
            //    userSettings.add_invoice_return_from_client,
            //    userSettings.add_invoice_taswet_edafa,
            //    userSettings.add_invoice_taswiat_khasm,
            //    userSettings.show_invoice_pay,
            //    userSettings.update_invoice_pay,
            //    userSettings.delete_invoice_pay,
            //    userSettings.show_invoice_sale,
            //    userSettings.update_invoice_sale,
            //    userSettings.delete_invoice_sale,
            //    userSettings.show_invoice_to_store,
            //    userSettings.update_invoice_to_store,
            //    userSettings.delete_invoice_to_store,
            //    userSettings.show_invoice_pay_from_store,
            //    userSettings.update_invoice_pay_from_store,
            //    userSettings.delete_invoice_pay_from_store,
            //    userSettings.show_invoice_return_to_supplier,
            //    userSettings.update_invoice_return_to_supplier,
            //    userSettings.delete_invoice_return_to_supplier,
            //    userSettings.show_invoice_return_from_client,
            //    userSettings.update_invoice_return_from_client,
            //    userSettings.delete_invoice_return_from_client,
            //    userSettings.show_invoice_taswet_edafa,
            //    userSettings.update_invoice_taswet_edafa,
            //    userSettings.delete_invoice_taswet_edafa,
            //    userSettings.show_invoice_taswiat_khasm,
            //    userSettings.update_invoice_taswiat_khasm,
            //    userSettings.delete_invoice_taswiat_khasm,       
            //}.Any(setting => setting);

            //        ts_groub_product.Visible = new[]
            //        {
            //    userSettings.add_product,
            //    userSettings.show_product,
            //    userSettings.update_product,
            //    userSettings.delete_product,
            //    userSettings.update_price_producut,
            //    userSettings.update_price_producut_exal,
            //    userSettings.blance_in_storses,
            //userSettings.update_product_min_mum,
            //}.Any(setting => setting);

            //        ts_groub_report_product.Visible = new[]
            //        {
            //    userSettings.kashf_hesab_prodct,
            //    userSettings.blance_in_storses,
            //    userSettings.store_in_and_out,
            //    userSettings.report_mabeat_product
            //}.Any(setting => setting);

            //        ts_groub_client.Visible = new[]
            //        {
            //    userSettings.add_client,
            //    userSettings.show_client,
            //    userSettings.update_client,
            //    userSettings.delete_client,
            //    userSettings.kashf_hesab_client,
            //    userSettings.add_amount_client,
            //    userSettings.show_amount_client,
            //    userSettings.update_amount_client,
            //    userSettings.delete_amount_client,
            //}.Any(setting => setting);

            //        ts_groub_report.Visible = new[]
            //        {
            //    userSettings.report_all_amount
            //}.Any(setting => setting);
        }
        public void get_setting2()
        {

            ts_groub_login.Text = Session.User_login.user_name + " - " + Session.User_login.name_fara;
            var userSettings = Session.User_setting();

            ts_add_invoice_pay.Visible = userSettings.add_invoice_pay;
            ts_add_invoice_sale.Visible = userSettings.add_invoice_sale;
            ts_add_invoice_to_store.Visible = userSettings.add_invoice_to_store;
            ts_add_invoice_pay_from_store.Visible = userSettings.add_invoice_pay_from_store;
            ts_add_invoice_return_to_supplier.Visible = userSettings.add_invoice_return_to_supplier;
            ts_add_invoice_return_from_client.Visible = userSettings.add_invoice_return_from_client;
            ts_add_invoice_taswet_edafa.Visible = userSettings.add_invoice_taswet_edafa;
            ts_add_invoice_taswiat_khasm.Visible = userSettings.add_invoice_taswiat_khasm;
            ts_add_invoice_broken.Visible = userSettings.add_invoice_broken;

            ts_show_invoice_pay.Visible = userSettings.show_invoice_pay || userSettings.update_invoice_pay || userSettings.delete_invoice_pay;
            ts_show_invoice_sale.Visible = userSettings.show_invoice_sale || userSettings.update_invoice_sale || userSettings.delete_invoice_sale;
            ts_show_invoice_to_store.Visible = userSettings.show_invoice_to_store || userSettings.update_invoice_to_store || userSettings.delete_invoice_to_store;
            ts_show_invoice_pay_from_store.Visible = userSettings.show_invoice_pay_from_store || userSettings.update_invoice_pay_from_store || userSettings.delete_invoice_pay_from_store;
            ts_show_invoice_return_to_supplier.Visible = userSettings.show_invoice_return_to_supplier || userSettings.update_invoice_return_to_supplier || userSettings.delete_invoice_return_to_supplier;
            ts_show_invoice_return_from_client.Visible = userSettings.show_invoice_return_from_client || userSettings.update_invoice_return_from_client || userSettings.delete_invoice_return_from_client;
            ts_show_invoice_taswet_edafa.Visible = userSettings.show_invoice_taswet_edafa || userSettings.update_invoice_taswet_edafa || userSettings.delete_invoice_taswet_edafa;
            ts_show_invoice_taswiat_khasm.Visible = userSettings.show_invoice_taswiat_khasm || userSettings.update_invoice_taswiat_khasm || userSettings.delete_invoice_taswiat_khasm;
            ts_show_invoice_broken.Visible = userSettings.show_invoice_broken || userSettings.update_invoice_broken || userSettings.delete_invoice_broken;

            ts_add_new_product.Visible = userSettings.add_product;
            ts_show_all_product.Visible = userSettings.show_product || userSettings.update_product || userSettings.delete_product;
            ts_update_price_producut.Visible = userSettings.update_price_producut;
            ts_update_price_producut_exal.Visible = userSettings.update_price_producut_exal;

            ts_kashf_hesab_prodct.Visible = userSettings.kashf_hesab_prodct;
            ts_blance_in_storses.Visible = userSettings.blance_in_storses;
            ts_product_min_mum.Visible = userSettings.blance_in_storses;
            ts_store_in_and_out.Visible = userSettings.store_in_and_out;
            ts_report_mabeat_product.Visible = userSettings.report_mabeat_product;

            ts_add_new_client.Visible = userSettings.add_client;
            ts_show_all_client.Visible = userSettings.show_client || userSettings.update_client || userSettings.delete_client;
            ts_kashf_hesab_client.Visible = userSettings.kashf_hesab_client;
            ts_add_amount_client.Visible = userSettings.add_amount_client;
            ts_all_amount_client.Visible = userSettings.show_amount_client || userSettings.update_amount_client || userSettings.delete_amount_client;

            ts_add_fara.Visible = userSettings.add_fara;
            ts_add_store.Visible = userSettings.add_store;
            ts_add_user.Visible = userSettings.add_user;
            ts_add_setting.Visible = userSettings.add_setting;
            ts_add_account.Visible = userSettings.add_All_account;

            ts_all_fara.Visible = userSettings.show_fara || userSettings.update_fara || userSettings.delete_fara;
            ts_all_store.Visible = userSettings.show_store || userSettings.update_store || userSettings.delete_store;
            ts_all_user.Visible = userSettings.show_user || userSettings.update_user || userSettings.delete_user;
            ts_all_setting.Visible = userSettings.show_setting || userSettings.update_setting || userSettings.delete_setting;
            ts_all_account.Visible = userSettings.show_All_account || userSettings.update_All_account || userSettings.delete_All_account;

            ts_report_all_amount.Visible = userSettings.report_all_amount;

            ts_groub_setting.Visible = new[]
            {
                userSettings.add_setting,
                userSettings.show_setting,
                userSettings.update_setting,
                userSettings.delete_setting,
                userSettings.add_fara,
                userSettings.show_fara,
                userSettings.update_fara,
                userSettings.delete_fara,
                userSettings.add_store,
                userSettings.show_store,
                userSettings.update_store,
                userSettings.delete_store,
                userSettings.add_user,
                userSettings.show_user,
                userSettings.update_user,
                userSettings.delete_user,
                userSettings.add_All_account,
                userSettings.show_All_account,
                userSettings.update_All_account,
                userSettings.delete_All_account,
            }.Any(setting => setting);
            ts_groub_invoices.Visible = new[]
            {
                userSettings.add_invoice_pay,
                userSettings.add_invoice_sale,
                userSettings.add_invoice_to_store,
                userSettings.add_invoice_pay_from_store,
                userSettings.add_invoice_return_to_supplier,
                userSettings.add_invoice_return_from_client,
                userSettings.add_invoice_taswet_edafa,
                userSettings.add_invoice_taswiat_khasm,
                userSettings.show_invoice_pay,
                userSettings.update_invoice_pay,
                userSettings.delete_invoice_pay,
                userSettings.show_invoice_sale,
                userSettings.update_invoice_sale,
                userSettings.delete_invoice_sale,
                userSettings.show_invoice_to_store,
                userSettings.update_invoice_to_store,
                userSettings.delete_invoice_to_store,
                userSettings.show_invoice_pay_from_store,
                userSettings.update_invoice_pay_from_store,
                userSettings.delete_invoice_pay_from_store,
                userSettings.show_invoice_return_to_supplier,
                userSettings.update_invoice_return_to_supplier,
                userSettings.delete_invoice_return_to_supplier,
                userSettings.show_invoice_return_from_client,
                userSettings.update_invoice_return_from_client,
                userSettings.delete_invoice_return_from_client,
                userSettings.show_invoice_taswet_edafa,
                userSettings.update_invoice_taswet_edafa,
                userSettings.delete_invoice_taswet_edafa,
                userSettings.show_invoice_taswiat_khasm,
                userSettings.update_invoice_taswiat_khasm,
                userSettings.delete_invoice_taswiat_khasm,
            }.Any(setting => setting);
            ts_groub_product.Visible = new[]
            {
                 userSettings.add_product,
                 userSettings.show_product,
                 userSettings.update_product,
                 userSettings.delete_product,
                 userSettings.update_price_producut,
                 userSettings.update_price_producut_exal,
                 userSettings.blance_in_storses
             }.Any(setting => setting);
            ts_groub_report_product.Visible = new[]
            {
            userSettings.kashf_hesab_prodct,
            userSettings.blance_in_storses,
            userSettings.store_in_and_out,
            userSettings.report_mabeat_product
            }.Any(setting => setting);
            ts_groub_client.Visible = new[]
            {
            userSettings.add_client,
            userSettings.show_client,
            userSettings.update_client,
            userSettings.delete_client,
            userSettings.kashf_hesab_client,
            userSettings.add_amount_client,
            userSettings.show_amount_client,
            userSettings.update_amount_client,
            userSettings.delete_amount_client,
            }.Any(setting => setting);
            ts_groub_report.Visible = new[]
            {
            userSettings.report_all_amount
            }.Any(setting => setting);
        }
        private class MyRenderer : ToolStripProfessionalRenderer
        {
            public MyRenderer(ProfessionalColorTable table) : base(table) { }
            //protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
            //{
            //    e.TextColor = Color.White;
            //    base.OnRenderItemText(e);
            //}
            //protected override void OnRenderItemBackground(ToolStripItemRenderEventArgs e)
            //{
            //    e.Item.BackColor = Color.Gold;
            //    base.OnRenderItemBackground(e);
            //}
            //protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
            //{
            //    if (e.Item.Selected)
            //    {
            //        Brush brush = new SolidBrush(Color.Green);
            //        Rectangle rc = new Rectangle(Point.Empty, e.Item.Size);
            //        e.Graphics.FillRectangle(brush, rc);
            //    }
            //}
            public MyRenderer() : base(new MyColors()) { }
        }
        private class MyColors : ProfessionalColorTable
        {
            //hover
            public override Color MenuItemSelectedGradientBegin
            {
                get { return ColorTranslator.FromHtml("#252451"); }
            }
            public override Color MenuItemSelectedGradientEnd
            {
                get { return ColorTranslator.FromHtml("#7160E8"); }
            }
            //selcted
            public override Color MenuItemPressedGradientBegin
            {
                get { return ColorTranslator.FromHtml("#252451"); }
            }
            public override Color MenuItemPressedGradientEnd
            {
                get { return ColorTranslator.FromHtml("#7160E8"); }
            }
            public override Color MenuItemBorder
            {
                get { return ColorTranslator.FromHtml("#252451"); }
            }
            public override Color MenuBorder  //added for changing the menu border
            {
                get { return ColorTranslator.FromHtml("#252451"); }
            }
            //hoveritem
            public override Color MenuItemSelected
            {
                get { return ColorTranslator.FromHtml("#7160E8"); }
            }

            public override Color ToolStripDropDownBackground
            {
                get { return ColorTranslator.FromHtml("#252451"); }
            }
            public override Color ToolStripBorder
            {
                get { return Color.Yellow; }
            }
            public override Color ToolStripGradientBegin
            {
                get { return Color.Yellow; }
            }
            public override Color ToolStripGradientEnd
            {
                get { return Color.Yellow; }
            }
            public override Color ToolStripGradientMiddle
            {
                get { return Color.Yellow; }
            }
        }
        public void titel()
        {
            ts_server.Text = Properties.Settings.Default.server;
            company_info info = new company_info();
            db = new DataClasses1DataContext();
            info = db.company_infos.FirstOrDefault();
            if (info != null)
            {
                lb_company.Text = info.hedar.ToUpper();
                this.Text = lb_company.Text;
                if (info.image != null)
                    Img_Company.Image = Class.Session.GetImageFromByteArray(info.image.ToArray());
            }
        }
        private void ts_all_amount_client_Click(object sender, EventArgs e)
        {
            ShowForm(ref All_amount_client);
        }
        private void ts_kashf_hesab_client_Click(object sender, EventArgs e)
        {
            ShowForm(ref All_amount_client_report);
        }
        private void ts_show_all_product_Click(object sender, EventArgs e)
        {
            ShowForm(ref Frm_Product);
        }
        private void ts_update_price_producut_exal_Click(object sender, EventArgs e)
        {
            ShowForm(ref formnew);
        }
        private void ts_all_invoice_pay_cash_Click(object sender, EventArgs e)
        {
            int itemText = Convert.ToInt16((sender as ToolStripMenuItem).Tag.ToString());
            ShowForm(ref All_InvoiceHeader, itemText);
        }
        private void ts_kashf_hesab_prodct_Click(object sender, EventArgs e)
        {
            ShowForm(ref _frm_Store_Log);
        }
        private void ts_blance_in_storses_Click(object sender, EventArgs e)
        {
            ShowForm(ref Frm_store_log_stores);
        }
        private void ts_store_in_and_out_Click(object sender, EventArgs e)
        {
            ShowForm(ref Frm_store_log_in_out);
        }
        private void ts_CompanyInfo_Click(object sender, EventArgs e)
        {
            if (!Session._setting.update_company)
                return;
            ShowForm(ref Frm_CompanyInfo);
        }
        private void ts_add_new_client_Click(object sender, EventArgs e)
        {
            ShowForm(ref Add_client);
        }
        private void ts_report_mabeat_product_Click(object sender, EventArgs e)
        {
            ShowForm(ref All_prodcut_get);
        }
        private void ts_add_amount_client_Click(object sender, EventArgs e)
        {
            ShowForm(ref Add_amount_client);
        }
        private void ts_add_new_product_Click(object sender, EventArgs e)
        {
            ShowForm(ref Add_product);
        }
        private void ts_update_price_producut_Click(object sender, EventArgs e)
        {
            update_all_prod formnew = new update_all_prod();
            formnew.ShowDialog();
        }
        private void ts_add_store_Click(object sender, EventArgs e)
        {
            ShowForm(ref Add_Store);
        }
        private void ts_all_store_Click(object sender, EventArgs e)
        {

            ShowForm(ref All_Store);
        }
        private void ts_add_fara_Click(object sender, EventArgs e)
        {
            ShowForm(ref Add_Fara);
        }
        private void ts_all_fara_Click(object sender, EventArgs e)
        {
            ShowForm(ref All_Fara);
        }
        private void ts_add_user_Click(object sender, EventArgs e)
        {
            ShowForm(ref User);
        }
        private void ts_all_user_Click(object sender, EventArgs e)
        {
            ShowForm(ref All_User);
        }
        private void ts_chang_pass_Click(object sender, EventArgs e)
        {
            ChchangePassword chchangePassword = new ChchangePassword();
            chchangePassword.ShowDialog();
        }
        private void ts_logout_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.id_user = 0;
            Properties.Settings.Default.pass = "";
            Properties.Settings.Default.tel = "";
            Properties.Settings.Default.Save();
            Application.Exit();
        }
        private void ts_add_setting_Click(object sender, EventArgs e)
        {
            ShowForm(ref _add_Setting);
        }
        private void ts_all_setting_Click(object sender, EventArgs e)
        {
            ShowForm(ref _all_Setting);
        }
        private void ts_setting_conntion_Click(object sender, EventArgs e)
        {
            frm_Connection h = new frm_Connection();
            h.ShowDialog();
        }
        private void ts_server_Click(object sender, EventArgs e)
        {
            //frm_Connection h = new frm_Connection();
            //h.ShowDialog();
        }
        private void ts_product_min_mum_Click(object sender, EventArgs e)
        {
            ShowForm(ref _Product_Min_Mum);
        }
        private void ts_new_invoice_nots_Click(object sender, EventArgs e)
        {

            int itemText = Convert.ToInt16((sender as ToolStripMenuItem).Tag.ToString());
            ShowForm(ref _InvoiceHeader_nots, itemText);
        }
        private void ts_frm_up_product_min_mum_Click(object sender, EventArgs e)
        {
            ShowForm(ref _frm_up_product_min_mum);
        }
        private void ts_report_all_amount_Click(object sender, EventArgs e)
        {
            ShowForm(ref _frm_All_Amount);
        }
        private void ts_show_all_sick_Click(object sender, EventArgs e)
        {
            ShowForm(ref All_client);
        }
        private void ShowForm<T>(ref T formInstance, object parameter = null) where T : Form
        {
            formInstance?.Dispose();

            formInstance = parameter != null
                ? (T)Activator.CreateInstance(typeof(T), parameter)
                : (T)Activator.CreateInstance(typeof(T));

            formInstance.TopLevel = false;
            formInstance.TopMost = true;
            formInstance.FormBorderStyle = FormBorderStyle.None;
            formInstance.Dock = DockStyle.Fill;

            pan_home.Controls.Add(formInstance);
            formInstance.Show();
            formInstance.BringToFront();
        }

        private void ts_add_type_cash_Click(object sender, EventArgs e)
        {
            ShowForm(ref _add_type_cash);
        }

        private void ts_all_type_cash_Click(object sender, EventArgs e)
        {
            ShowForm(ref all_type_cash);
        }
        private void ts_add_Amount_Click(object sender, EventArgs e)
        {
            ShowForm(ref _add_Amount);
        }
        private void ActivateMenus()
        {
            foreach (ToolStripMenuItem item in menuStrip1.Items)
            {
                AreAllSubItemsHidden(item);
            }
        }
        private void AreAllSubItemsHidden(ToolStripMenuItem parentItem)
        {
            if (parentItem.Name == "lb_company")
                return;
            parentItem.ShowDropDown();
            bool all = false;
            foreach (ToolStripItem subItem in parentItem.DropDownItems)
            {
                if (subItem is ToolStripMenuItem)
                    if (subItem.Visible)  // إذا كان أي عنصر مرئي
                    {
                        all = true;
                        break;// إذا كان عنصر واحد فقط مرئي، فإن الدالة سترجع false
                    }
            }
            parentItem.Visible = all;  // إذا كانت كل العناصر مخفية
            parentItem.HideDropDown();
        }

        private void ts_add_account_Click(object sender, EventArgs e)
        {
            ShowForm(ref _add_Account);
        }
        frm_All_account _frm_All_account;
        private void ts_all_account_Click(object sender, EventArgs e)
        {
            ShowForm(ref _frm_All_account);
        }
        all_amount _all_amount;
        private void ts_all_amount_Click(object sender, EventArgs e)
        {
            ShowForm(ref _all_amount);
        }
        private void home_Load(object sender, EventArgs e)
        {            
        }
        frm_UserAccessMachineName frm_userAccessMachineName;
        private void ts_user_access_store_Click(object sender, EventArgs e)
        {
            ShowForm(ref frm_userAccessMachineName);
        }
    }
}
