﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace tnerhbeauty
{
    public partial class app_update : Form
    {
        public app_update()
        {
            InitializeComponent();
        }
        private async void login_Load(object sender, EventArgs e)
        {
            await update();
        }
        private async Task update()
        {
            try
            {

                string downloadUrl = "https://raw.githubusercontent.com/basemsaidmohamed/tnerhbeauty/refs/heads/main/publish/Setupapp.zip"; // رابط التحميل
                string zipPath = Path.Combine(Directory.GetCurrentDirectory(), "Setupapp.zip");
                string extractPath = Path.GetTempPath();
                string msiPath = Path.Combine(extractPath, "Setupapp.msi");
                string exePath = Assembly.GetExecutingAssembly().Location;
                string exeName = Path.GetFileName(exePath);
                if (File.Exists(msiPath))
                {
                    File.Delete(msiPath);
                }
                using (WebClient client = new WebClient())
                {
                    client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
                    await client.DownloadFileTaskAsync(new Uri(downloadUrl), zipPath);
                }
                ZipFile.ExtractToDirectory(zipPath, extractPath);
                if (File.Exists(msiPath))
                {                   
                    Process process = new Process
                    {
                        StartInfo = new ProcessStartInfo
                        {
                            WindowStyle = ProcessWindowStyle.Hidden,
                            FileName = "cmd.exe",
                            Arguments = string.Format($@"/c taskkill /IM ""{exeName}"" /F &&  msiexec.exe /i ""{msiPath}"" /qb &&  ""{exePath}"""),
                            UseShellExecute = false,
                            CreateNoWindow = true
                        }
                    };
                    process.Start();                  
                }
                else
                {
                    MessageBox.Show("فشل تحميل الملف", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
            //if (File.Exists(@".\Setupapp.zip"))
            //{
            //    File.Delete(@".\Setupapp.zip");
            //}

            //using (WebClient client = new WebClient())
            //{
            //    client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
            //    await client.DownloadFileTaskAsync(new Uri("https://raw.githubusercontent.com/basemsaidmohamed/tnerhbeauty/refs/heads/main/publish/Setupapp.zip"), @"Setupapp.zip");
            //}

            //string zipPath = @".\Setupapp.zip";
            //string extractPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Setupapp.zip");

            //// حذف أي إصدارات سابقة
            //if (Directory.Exists(extractPath))
            //{
            //    Directory.Delete(extractPath, true);
            //}

            //// استخراج الملفات
            //ZipFile.ExtractToDirectory(zipPath, extractPath);

            // تشغيل التطبيق الجديد
            //string newAppPath = Path.Combine(extractPath, "Setupapp.msi");
            //Process process = new Process();
            //process.StartInfo.FileName = newAppPath;
            //process.Start();

            //// إنهاء التطبيق الحالي
            //Application.Exit();

            //Process process = new Process();
            //process.StartInfo.FileName = "msiexec.exe";
            //process.StartInfo.Arguments = @"/i ""path_to_your_file.msi"" /quiet";
            //process.StartInfo.UseShellExecute = false;
            //process.StartInfo.CreateNoWindow = true; // تشغيل العملية في الخلفية
            //process.Start();
            //process.WaitForExit();
            //Console.WriteLine("Installation completed successfully.");


            //if (File.Exists(@".\Setupapp.msi"))
            //{ File.Delete(@".\Setupapp.msi"); }
            //if (File.Exists(@".\Setupapp.zip"))
            //{ File.Delete(@".\Setupapp.zip"); }
            //using (WebClient Client = new WebClient())
            //{
            //    Client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
            //    await Client.DownloadFileTaskAsync(new Uri("https://raw.githubusercontent.com/basemsaidmohamed/tnerhbeauty/refs/heads/main/publish/Setupapp.zip"), @"Setupapp.zip");
            //}
            //string zipPath = @".\Setupapp.zip";
            //string extractPath = @"%TEMP%";
            //ZipFile.ExtractToDirectory(zipPath, extractPath);

            //Process process = new Process();
            //process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            //process.StartInfo.FileName = "cmd.exe";
            //process.StartInfo.Arguments = string.Format(@"/c msiexec.exe /i Setupapp.msi /qb &&  Tnerh.exe");
            //Application.Exit();
            //process.Start();
        private void client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            progressBar1.Minimum = 0;
            double receive = double.Parse(e.BytesReceived.ToString());
            double total = double.Parse(e.TotalBytesToReceive.ToString());
            double percentage = receive / total * 100;
            lblStatus.Text = $"{string.Format("{0:0.##}", percentage)}%";
            progressBar1.Value = int.Parse(Math.Truncate(percentage).ToString());

            //progressBar1.Value = e.ProgressPercentage;
        }
    }
}
