﻿
using System;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using tnerhbeauty.Class;
using static tnerhbeauty.Class.Session;


namespace tnerhbeauty
{
    public partial class add_user : Form
    {
        DataClasses1DataContext db;
        user User;
        bool updateid = false;
        user_View _user_View;
        //int id_user;
        public add_user()
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
            User = new user();
            dr_id_fara.IntializeData(Session.Fara.Where(x => x.is_stop == false).ToList(), nameof(fara.name_fara), nameof(fara.id));
        }
        public add_user(int id)
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
            User = new user();
            User = db.users.Where(s => s.id == id).FirstOrDefault();
            dr_id_fara.IntializeData(Session.Fara, nameof(fara.name_fara), nameof(fara.id));            
            updateid = true;
        }
        private void add_marid_Load(object sender, EventArgs e)
        {
            dr_setting.IntializeData(Session.Setting);
            gv_stores.AutoGenerateColumns = false;
            getdata();
            
        }
        void getdata()
        {
            _user_View = new user_View();
            if (User.id != 0)
            {
               
                _user_View = db.user_Views.Where(s => s.id == User.id).FirstOrDefault();
                tx_name.Text = _user_View.user_name;
                tx_tel.Text = _user_View.tel;
                tx_adress.Text = _user_View.adress;
                dr_setting.SelectedValue = _user_View.id_setting;
                ch_isstop.Checked = _user_View.is_stop;
                lp_titel.Text = "تعديل بيانات موظف";
                btn_delete.Visible = Session.User_setting().delete_user;
                btn_save.Visible = Session.User_setting().update_user;
                dr_id_fara.SelectedValue = _user_View.id_fara;
                dr_id_fara_SelectionChangeCommitted(null, null);
                ch_any_Machine.Checked = _user_View.any_Machine;                
                SelectStoreUser();
            }
            else
            {
                lp_titel.Text = "اضافة موظف جديد ";
                dr_id_fara.SelectedIndex = -1;
                dr_setting.SelectedIndex = -1;
               
                btn_save.Visible = Session.User_setting().add_user;
                btn_new.Visible = Session.User_setting().add_user;
                tx_name.Text = _user_View.user_name;
                tx_tel.Text = _user_View.tel;
                tx_adress.Text = _user_View.adress;
                dr_setting.SelectedValue = _user_View.id_setting;
                ch_isstop.Checked = _user_View.is_stop;
                ch_any_Machine.Checked = false;
                ch_rest_pass.Checked = false;
                gv_stores.DataSource=null;
            }
            ch_any_Machine.Visible = Session.User_setting().show_UserAccessMachineName;
        }
        private void SelectStoreUser()
        {
            List<int> selectedIds = new List<int>();
            selectedIds = db.user_access_stores.Where(x =>x.id_user==_user_View.id).Select(x=>x.id_store).ToList();
            foreach (DataGridViewRow row in gv_stores.Rows)
            {
                int rowId = Convert.ToInt32(row.Cells[nameof(gv_id_stors)].Value); // تأكد أن اسم العمود صحيح
                if (selectedIds.Contains(rowId))
                {
                    DataGridViewCheckBoxCell chkCell = (DataGridViewCheckBoxCell)row.Cells[nameof(gv_ch_id_fara)]; // اسم عمود الـ CheckBox
                    chkCell.Value = true; // تحديد الـ CheckBox
                }
            }
        }
        void setdata()
        {
            User.user_name = tx_name.Text.Replace_text();
            User.tel = tx_tel.Text;
            User.adress = tx_adress.Text.Replace_text();

            if (User.id == 0 || ch_rest_pass.Checked)
                User.password = "xxxxxx";
            
            User.id_fara = Session.ConvertInt(dr_id_fara.SelectedValue.ToString());
            User.id_setting = Session.ConvertInt(dr_setting.SelectedValue.ToString());
            User.is_stop = ch_isstop.Checked;
            User.id_user = Session.User_login.id;
            User.DateServer = Session.GetDate();
            User.any_Machine=ch_any_Machine.Checked;
        }
        void setdatause()
        {
            if(User.id != 0) 
            db.deleteAll_user_access_store(User.id);
            List<user_access_store> _user_Access_store = new List<user_access_store>();
            foreach (DataGridViewRow row in gv_stores.Rows)
            {
                if (Convert.ToBoolean(row.Cells[nameof(gv_ch_id_fara)].Value) == true)
                {
                    _user_Access_store.Add(new user_access_store
                    {
                        id_user=User.id,
                        id_store=Convert.ToInt32(row.Cells[nameof(gv_id_stors)].Value)
                    });                   
                }
            }
            db.user_access_stores.InsertAllOnSubmit(_user_Access_store);
            db.SubmitChanges();
        }
        bool valid()
        {
            errorProvider1.Clear();
            int error = 0;
            if (dr_setting.SelectedIndex == -1)
            {
                errorProvider1.SetError(dr_setting, massege.NotNull);
                error++;
            }
            
            if (string.IsNullOrEmpty(tx_name.Text.Trim()))
            {
                errorProvider1.SetError(tx_name, massege.NotNull);
                error++;
            }
            if (string.IsNullOrEmpty(tx_tel.Text.Trim()))
            {
                errorProvider1.SetError(tx_tel, massege.NotNull);
                error++;
            }
            if (dr_id_fara.SelectedIndex == -1)
            {
                errorProvider1.SetError(dr_id_fara, "برجاء اختيار الفرع");
                error++;
            }
            return error == 0;
        }
        private void bt_new_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            updateid = false;
            User = new user();
            getdata();
            tx_name.Focus();
        }
        private void add_marid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F12)
            {
                btn_save.PerformClick();
            }
            if (e.KeyCode == Keys.F2)
            {
                btn_new.PerformClick();
            }

            if (e.KeyCode == Keys.Escape && updateid)
            {
                this.Close();
            }
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl(ActiveControl, true, true, true, true);
                if (ActiveControl is TextBox)
                {
                    TextBox tx = (TextBox)ActiveControl;
                    tx.SelectAll();
                }
            }
        }
        private void bt_save_Click(object sender, EventArgs e)
        {
            if (updateid)
                if (checkUpdate(type_.update, User.DateServer, User.id_user))
                    return;
            if (!valid())
                return;
            setdata();
            if (User.id == 0)
                db.users.InsertOnSubmit(User);

            try
            {
                db.SubmitChanges();
                setdatause();
            }
            catch (SqlException x)
            {
                if (x.Number == 2627)
                {
                    MyMessageBox.showMessage("error ", "يوجد موظف اخر مسجل بنفس الاسم او رقم التليفون", "", MessageBoxButtons.RetryCancel);
                }
                else
                    x.Message.MsgError();
                    //MyMessageBox.showMessage("error ",x.Message.massege.MsgError, "", MessageBoxButtons.RetryCancel);
                return;
            }
            if (updateid)
            {
                this.Close();
                return;
            }
            lb_mas.Text = massege.successfully;
            btn_new.PerformClick();
        }
        private void bt_delete_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.delete, User.DateServer, User.id_user))
                return;
            if (MyMessageBox.showMessage("تاكيد", massege.AskDelete, "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;
            try
            {
                db.users.DeleteOnSubmit(User);
                db.SubmitChanges();
            }
            catch (SqlException x)
            {
                if (x.Number == 547)
                {
                    MyMessageBox.showMessage("خطاء", massege.NotDelete, "", MessageBoxButtons.RetryCancel);
                }
                else
                    MyMessageBox.showMessage("error ", " لم يتم الحذف  ", "", MessageBoxButtons.RetryCancel);
                return;
            }
            this.Close();
        }
        private void ch_rest_pass_CheckedChanged(object sender, EventArgs e)
        {
            if (ch_rest_pass.Checked)
                lb_mas.Text = "سيتم اعاده الباسورد الي الوضع الافتراضي";
            else lb_mas.Text = "";
        }
        private void dr_id_fara_SelectionChangeCommitted(object sender, EventArgs e)
        {
            var _store = Session.GetStoreFara(Session.ConvertInt(dr_id_fara.SelectedValue.ToString()));          
            gv_stores.DataSource = _store;
        }
        private void dr_access_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_print_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.print, User.DateServer, User.id_user))
                return;
        }
    }
}
