﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using tnerhbeauty.Class;

namespace tnerhbeauty
{
    public partial class selct_sick : Form
    {
        client_View _client_View;
        List<client_View> _client_Views = new List<client_View>();
        public selct_sick()
        {
            InitializeComponent();
            DataClasses1DataContext db = new DataClasses1DataContext();
            textBox1_TextChanged(null, null);
            _client_Views = db.client_Views.OrderBy(x => x.name).OrderByDescending(x => x.id).ToList();
            datagrid1.DataSource = _client_Views;
            datagrid1.Columns[nameof(client_View.id)].Visible = false;
            datagrid1.Columns[nameof(client_View.adress)].Visible = false;
            datagrid1.Columns[nameof(client_View.is_stop)].Visible = false;
            datagrid1.Columns[nameof(client_View.DateServer)].Visible = false;
            datagrid1.Columns[nameof(client_View.nots)].Visible = false;
            datagrid1.Columns[nameof(client_View.list_price)].Visible = false;
            datagrid1.Columns[nameof(client_View.Balance)].Visible = false;
            datagrid1.Columns[nameof(client_View.Balance_type)].Visible = false;
            datagrid1.Columns[nameof(client_View.id_user)].Visible = false;
            datagrid1.Columns[nameof(client_View.id_fara)].Visible = false;
            datagrid1.Columns[nameof(client_View.name_fara)].Visible = false;
            datagrid1.Columns[nameof(client_View.user_name)].Visible = false;
            datagrid1.Columns[nameof(client_View.name)].HeaderText = "اسم العميل";
            datagrid1.Columns[nameof(client_View.tel)].HeaderText = "تليفون";
            datagrid1.Columns[nameof(client_View.name_row)].HeaderText = "قائمة الاسعار";
        }
        public client_View GetClient()
        {
           
            return _client_View;
        }
        private void datagrid1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            _client_View = new client_View();
            _client_View = (client_View)datagrid1.Rows[datagrid1.CurrentCell.RowIndex].DataBoundItem;
            GetClient();
            this.Close();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            datagrid1.DataSource = _client_Views.Where(x => x.name.Contains(tx_serch.Text.Replace_text()) || x.tel.Contains(tx_serch.Text)).OrderBy(x => x.name).OrderByDescending(x => x.name.StartsWith(tx_serch.Text)).ToList(); ;          
        }
        private void button2_Click(object sender, EventArgs e)
        {

            this.Close();
        }
        private void selct_sick_Load(object sender, EventArgs e)
        {
            tx_serch.Focus();
        }
        private void selct_prodct_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsWhiteSpace(e.KeyChar)) // إذا كان الإدخال حرفًا أو رقمًا
            {
                if (!tx_serch.Focused) // إذا كان التركيز على حقل النص
                {
                    tx_serch.Focus();
                    //return; // دع السلوك الافتراضي يحدث
                }
                //إضافة الحرف إلى حقل النص
                tx_serch.Text += e.KeyChar;
                tx_serch.SelectionStart = tx_serch.Text.Length; // وضع المؤشر في نهاية النص
                e.Handled = true; // منع المعالجة الافتراضية
            }
        }
        private void tx_serch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up)
            {
                int currentRowIndex = datagrid1.CurrentCell?.RowIndex ?? 0;
                int targetRowIndex = e.KeyCode == Keys.Down ? currentRowIndex + 1 : currentRowIndex - 1;
                if (targetRowIndex >= 0 && targetRowIndex < datagrid1.Rows.Count)
                {
                    datagrid1.CurrentCell = datagrid1.Rows[targetRowIndex].Cells[datagrid1.CurrentCell.ColumnIndex];
                }
                e.Handled = true;
            }
            if (e.KeyCode == Keys.Enter && datagrid1.CurrentCell != null)
            {
                _client_View = new client_View();
                _client_View = (client_View)datagrid1.Rows[datagrid1.CurrentCell.RowIndex].DataBoundItem;
                GetClient();
                this.Close();
            }
        }
    }
}
