﻿namespace tnerhbeauty
{
    partial class all_InvoiceHeader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(all_InvoiceHeader));
            this.dt_date_to = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bt_search = new System.Windows.Forms.Button();
            this.lb_mas = new System.Windows.Forms.Label();
            this.lp_titel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.bt_aladawia = new System.Windows.Forms.Button();
            this.btn_print = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tx_nots = new System.Windows.Forms.TextBox();
            this.tx_name_cient = new System.Windows.Forms.Label();
            this.tx_id = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dr_is_agel = new System.Windows.Forms.ComboBox();
            this.dr_fara = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dr_user = new System.Windows.Forms.ComboBox();
            this.btn_new = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dt_date_from = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.pic_login = new System.Windows.Forms.PictureBox();
            this.gv = new tnerhbeauty.Class.datagrid();
            this.btn_export_exal = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv)).BeginInit();
            this.SuspendLayout();
            // 
            // dt_date_to
            // 
            this.dt_date_to.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dt_date_to.Font = new System.Drawing.Font("Arial", 10.5F, System.Drawing.FontStyle.Bold);
            this.dt_date_to.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dt_date_to.Location = new System.Drawing.Point(794, 52);
            this.dt_date_to.Margin = new System.Windows.Forms.Padding(4);
            this.dt_date_to.Name = "dt_date_to";
            this.dt_date_to.RightToLeftLayout = true;
            this.dt_date_to.Size = new System.Drawing.Size(104, 28);
            this.dt_date_to.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(794, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "الي تاريخ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(1130, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(293, 22);
            this.label3.TabIndex = 7;
            this.label3.Text = "اسم العميل";
            // 
            // bt_search
            // 
            this.bt_search.BackColor = System.Drawing.Color.Purple;
            this.bt_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_search.Dock = System.Windows.Forms.DockStyle.Left;
            this.bt_search.FlatAppearance.BorderSize = 0;
            this.bt_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_search.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.bt_search.ForeColor = System.Drawing.Color.White;
            this.bt_search.Location = new System.Drawing.Point(176, 46);
            this.bt_search.Margin = new System.Windows.Forms.Padding(4);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(93, 34);
            this.bt_search.TabIndex = 55;
            this.bt_search.Text = "بحث";
            this.bt_search.UseVisualStyleBackColor = false;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // lb_mas
            // 
            this.lb_mas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lb_mas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_mas.Font = new System.Drawing.Font("Tahoma", 11.25F);
            this.lb_mas.ForeColor = System.Drawing.Color.White;
            this.lb_mas.Location = new System.Drawing.Point(0, 762);
            this.lb_mas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_mas.Name = "lb_mas";
            this.lb_mas.Size = new System.Drawing.Size(1452, 38);
            this.lb_mas.TabIndex = 64;
            this.lb_mas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_titel
            // 
            this.lp_titel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lp_titel.Dock = System.Windows.Forms.DockStyle.Top;
            this.lp_titel.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_titel.ForeColor = System.Drawing.Color.White;
            this.lp_titel.Image = global::tnerhbeauty.Properties.Resources.Contact_List;
            this.lp_titel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp_titel.Location = new System.Drawing.Point(0, 0);
            this.lp_titel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_titel.Name = "lp_titel";
            this.lp_titel.Size = new System.Drawing.Size(1452, 41);
            this.lp_titel.TabIndex = 66;
            this.lp_titel.Text = "بحث عن بيان اسعار";
            this.lp_titel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button1.BackgroundImage = global::tnerhbeauty.Properties.Resources.close;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(2, 4);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(28, 31);
            this.button1.TabIndex = 61;
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bt_aladawia
            // 
            this.bt_aladawia.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bt_aladawia.BackgroundImage = global::tnerhbeauty.Properties.Resources.find_users;
            this.bt_aladawia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_aladawia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_aladawia.FlatAppearance.BorderSize = 0;
            this.bt_aladawia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.bt_aladawia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.bt_aladawia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_aladawia.Location = new System.Drawing.Point(260, 4);
            this.bt_aladawia.Margin = new System.Windows.Forms.Padding(4);
            this.bt_aladawia.Name = "bt_aladawia";
            this.bt_aladawia.Size = new System.Drawing.Size(29, 31);
            this.bt_aladawia.TabIndex = 60;
            this.bt_aladawia.UseVisualStyleBackColor = false;
            this.bt_aladawia.Click += new System.EventHandler(this.bt_aladawia_Click);
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_print.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_print.FlatAppearance.BorderSize = 0;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(5, 46);
            this.btn_print.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(89, 34);
            this.btn_print.TabIndex = 81;
            this.btn_print.Text = "طباعة";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(661, 20);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 22);
            this.label5.TabIndex = 86;
            this.label5.Text = "ملاحظات";
            // 
            // tx_nots
            // 
            this.tx_nots.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tx_nots.Font = new System.Drawing.Font("Arial", 10.5F, System.Drawing.FontStyle.Bold);
            this.tx_nots.Location = new System.Drawing.Point(661, 52);
            this.tx_nots.Margin = new System.Windows.Forms.Padding(4);
            this.tx_nots.Name = "tx_nots";
            this.tx_nots.Size = new System.Drawing.Size(125, 28);
            this.tx_nots.TabIndex = 85;
            this.tx_nots.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tx_name_cient
            // 
            this.tx_name_cient.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tx_name_cient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tx_name_cient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tx_name_cient.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.tx_name_cient.Location = new System.Drawing.Point(30, 4);
            this.tx_name_cient.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tx_name_cient.Name = "tx_name_cient";
            this.tx_name_cient.Padding = new System.Windows.Forms.Padding(4);
            this.tx_name_cient.Size = new System.Drawing.Size(231, 31);
            this.tx_name_cient.TabIndex = 138;
            this.tx_name_cient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tx_name_cient.Click += new System.EventHandler(this.bt_aladawia_Click);
            // 
            // tx_id
            // 
            this.tx_id.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tx_id.Font = new System.Drawing.Font("Arial", 10.5F, System.Drawing.FontStyle.Bold);
            this.tx_id.Location = new System.Drawing.Point(1018, 52);
            this.tx_id.Margin = new System.Windows.Forms.Padding(4);
            this.tx_id.Name = "tx_id";
            this.tx_id.Size = new System.Drawing.Size(104, 28);
            this.tx_id.TabIndex = 139;
            this.tx_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(1018, 20);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 22);
            this.label4.TabIndex = 140;
            this.label4.Text = "ID";
            // 
            // dr_is_agel
            // 
            this.dr_is_agel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dr_is_agel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_is_agel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_is_agel.FormattingEnabled = true;
            this.dr_is_agel.Location = new System.Drawing.Point(537, 53);
            this.dr_is_agel.Margin = new System.Windows.Forms.Padding(4);
            this.dr_is_agel.Name = "dr_is_agel";
            this.dr_is_agel.Size = new System.Drawing.Size(116, 27);
            this.dr_is_agel.TabIndex = 141;
            // 
            // dr_fara
            // 
            this.dr_fara.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dr_fara.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_fara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_fara.FormattingEnabled = true;
            this.dr_fara.Location = new System.Drawing.Point(413, 53);
            this.dr_fara.Margin = new System.Windows.Forms.Padding(4);
            this.dr_fara.Name = "dr_fara";
            this.dr_fara.Size = new System.Drawing.Size(116, 27);
            this.dr_fara.TabIndex = 142;
            this.dr_fara.SelectionChangeCommitted += new System.EventHandler(this.dr_fara_SelectionChangeCommitted);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 10;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.btn_export_exal, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.dr_user, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_new, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tx_id, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.dr_fara, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.dr_is_agel, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.dt_date_from, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.tx_nots, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dt_date_to, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.bt_search, 8, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_print, 9, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(14, 44);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1427, 84);
            this.tableLayoutPanel1.TabIndex = 143;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // dr_user
            // 
            this.dr_user.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dr_user.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_user.DropDownWidth = 100;
            this.dr_user.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_user.FormattingEnabled = true;
            this.dr_user.Location = new System.Drawing.Point(277, 53);
            this.dr_user.Margin = new System.Windows.Forms.Padding(4);
            this.dr_user.Name = "dr_user";
            this.dr_user.Size = new System.Drawing.Size(128, 27);
            this.dr_user.TabIndex = 154;
            // 
            // btn_new
            // 
            this.btn_new.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_new.BackColor = System.Drawing.Color.Green;
            this.btn_new.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_new.FlatAppearance.BorderSize = 0;
            this.btn_new.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_new.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_new.ForeColor = System.Drawing.Color.White;
            this.btn_new.Location = new System.Drawing.Point(2, 4);
            this.btn_new.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(164, 34);
            this.btn_new.TabIndex = 154;
            this.btn_new.Text = "تحويل الي فاتورة بيع";
            this.btn_new.UseVisualStyleBackColor = false;
            this.btn_new.Visible = false;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.tx_name_cient);
            this.panel1.Controls.Add(this.bt_aladawia);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(1130, 46);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(293, 34);
            this.panel1.TabIndex = 144;
            // 
            // dt_date_from
            // 
            this.dt_date_from.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dt_date_from.Font = new System.Drawing.Font("Arial", 10.5F, System.Drawing.FontStyle.Bold);
            this.dt_date_from.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dt_date_from.Location = new System.Drawing.Point(906, 52);
            this.dt_date_from.Margin = new System.Windows.Forms.Padding(4);
            this.dt_date_from.Name = "dt_date_from";
            this.dt_date_from.RightToLeftLayout = true;
            this.dt_date_from.Size = new System.Drawing.Size(104, 28);
            this.dt_date_from.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(906, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 22);
            this.label2.TabIndex = 6;
            this.label2.Text = "من تاريخ";
            // 
            // pic_login
            // 
            this.pic_login.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pic_login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pic_login.Image = global::tnerhbeauty.Properties.Resources.kOnzy;
            this.pic_login.Location = new System.Drawing.Point(7, 768);
            this.pic_login.Margin = new System.Windows.Forms.Padding(0);
            this.pic_login.Name = "pic_login";
            this.pic_login.Size = new System.Drawing.Size(26, 27);
            this.pic_login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_login.TabIndex = 153;
            this.pic_login.TabStop = false;
            this.pic_login.Visible = false;
            // 
            // gv
            // 
            this.gv.AllowUserToAddRows = false;
            this.gv.AllowUserToDeleteRows = false;
            this.gv.AllowUserToResizeColumns = false;
            this.gv.AllowUserToResizeRows = false;
            this.gv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gv.ColumnHeadersHeight = 30;
            this.gv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv.EnableHeadersVisualStyles = false;
            this.gv.GridColor = System.Drawing.Color.Black;
            this.gv.Location = new System.Drawing.Point(13, 132);
            this.gv.Margin = new System.Windows.Forms.Padding(0);
            this.gv.Name = "gv";
            this.gv.ReadOnly = true;
            this.gv.RowHeadersVisible = false;
            this.gv.RowHeadersWidth = 51;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.gv.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv.RowTemplate.Height = 30;
            this.gv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv.Size = new System.Drawing.Size(1428, 615);
            this.gv.TabIndex = 67;
            this.gv.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_kushf_with_marid_CellDoubleClick);
            // 
            // btn_export_exal
            // 
            this.btn_export_exal.BackColor = System.Drawing.Color.Transparent;
            this.btn_export_exal.BackgroundImage = global::tnerhbeauty.Properties.Resources.excel;
            this.btn_export_exal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_export_exal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_export_exal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_export_exal.FlatAppearance.BorderSize = 0;
            this.btn_export_exal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_export_exal.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_export_exal.Location = new System.Drawing.Point(177, 4);
            this.btn_export_exal.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btn_export_exal.Name = "btn_export_exal";
            this.btn_export_exal.Size = new System.Drawing.Size(91, 34);
            this.btn_export_exal.TabIndex = 80;
            this.btn_export_exal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_export_exal.UseVisualStyleBackColor = false;
            this.btn_export_exal.Click += new System.EventHandler(this.btn_export_exal_Click);
            // 
            // all_InvoiceHeader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1452, 800);
            this.Controls.Add(this.pic_login);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.gv);
            this.Controls.Add(this.lp_titel);
            this.Controls.Add(this.lb_mas);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "all_InvoiceHeader";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Physical Checkup";
            this.Load += new System.EventHandler(this.all_kushufat_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dt_date_to;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_search;
        private System.Windows.Forms.Button bt_aladawia;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lb_mas;
        private System.Windows.Forms.Label lp_titel;
        private Class.datagrid gv;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tx_nots;
        private System.Windows.Forms.Label tx_name_cient;
        private System.Windows.Forms.TextBox tx_id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox dr_is_agel;
        private System.Windows.Forms.ComboBox dr_fara;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker dt_date_from;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pic_login;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.ComboBox dr_user;
        private System.Windows.Forms.Button btn_export_exal;
    }
}