﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using tnerhbeauty.Class;

namespace tnerhbeauty
{
    public partial class selct_prodct : Form
    {
        DataClasses1DataContext db;
        int id = 0;
        product_serch_View _product_serch_View;
        List<product_serch_View> list_product_serch_View = new List<product_serch_View>();
        public selct_prodct()
        {
            InitializeComponent();
            this.KeyPress += new KeyPressEventHandler(selct_prodct_KeyPress);
            //this.KeyDown += new KeyEventHandler(selct_prodct_KeyDown);
            db = new DataClasses1DataContext();
            list_product_serch_View = Session.GETProductSerchWithOutStoreView;
            //list_product_serch_View = db.ExecuteQuery<product_serch_View>("SELECT * FROM ProductSerchWithOutStoreView").ToList();
            datagrid1.DataSource = list_product_serch_View;
            datagrid1.Columns[nameof(product_serch_View.id)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_buy)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_sale_100)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_sale_75)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_sale_vip1)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_sale_vip2)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_1)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_2)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_3)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_4)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_5)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_6)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_7)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_8)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_9)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.price_10)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.fullname)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.is_stop)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.store_id)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.store_name)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.Balance)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.update_price)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.min_mum)].Visible = false;
            datagrid1.Columns[nameof(product_serch_View.code)].HeaderText = "الكود";
            datagrid1.Columns[nameof(product_serch_View.name)].HeaderText = "اسم الصتف";
            datagrid1.Columns[nameof(product_serch_View.price_sale)].HeaderText = "سعر محل";
            datagrid1.Columns[nameof(product_serch_View.price_sale)].Visible = false;
            //datagrid1.Columns[nameof(product_serch_View.code)].Visible = false;
            //datagrid1.Columns[nameof(product_serch_View.name)].Visible = false;
        }
        public product_serch_View retrnval()
        {
            return _product_serch_View;
        }
        private void datagrid1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            _product_serch_View = (product_serch_View)datagrid1.Rows[datagrid1.CurrentCell.RowIndex].DataBoundItem;
            retrnval();
            this.Close();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            datagrid1.DataSource = list_product_serch_View.OrderBy(x => x.name).Where(x => x.name.Contains(tx_serch.Text.Replace_text()) || x.code.Contains(tx_serch.Text)).OrderByDescending(x => x.name.StartsWith(tx_serch.Text.Replace_text())).ToList();           
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void selct_sick_Load(object sender, EventArgs e)
        {
            tx_serch.Focus();
        }
        private void selct_prodct_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetterOrDigit(e.KeyChar) || char.IsWhiteSpace(e.KeyChar)) // إذا كان الإدخال حرفًا أو رقمًا
            {
                if (!tx_serch.Focused) // إذا كان التركيز على حقل النص
                {
                    tx_serch.Focus();
                    //return; // دع السلوك الافتراضي يحدث
                }
                //إضافة الحرف إلى حقل النص
                tx_serch.Text += e.KeyChar;
                tx_serch.SelectionStart = tx_serch.Text.Length; // وضع المؤشر في نهاية النص
                e.Handled = true; // منع المعالجة الافتراضية
            }
        }      
        private void tx_serch_KeyDown(object sender, KeyEventArgs e)
        {
             if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up)
            {
                int currentRowIndex = datagrid1.CurrentCell?.RowIndex ?? 0;
                int targetRowIndex = e.KeyCode == Keys.Down ? currentRowIndex + 1 : currentRowIndex - 1;
                if (targetRowIndex >= 0 && targetRowIndex < datagrid1.Rows.Count)
                {
                    datagrid1.CurrentCell = datagrid1.Rows[targetRowIndex].Cells[datagrid1.CurrentCell.ColumnIndex];
                }
                e.Handled = true;
            }
            if (e.KeyCode == Keys.Enter && datagrid1.CurrentCell != null)
            {
                _product_serch_View = (product_serch_View)datagrid1.Rows[datagrid1.CurrentCell.RowIndex].DataBoundItem;
                retrnval();
                this.Close();
            }
        }
    }
}
