﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ClosedXML.Excel;


namespace tnerhbeauty.Class
{

    public static class Session
    {
        /// <summary>
        /// procedure  تقوم بتشغيل عن طريق اسمه بدون para
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procname"></param>
        /// <returns>ترجع ليست من الاستعلام</returns>
        public static List<T> procedureNoParams<T>(string procname)
        {
            using (var db = new DataClasses1DataContext())
            {
                var query = db.ExecuteQuery<T>("Exec " + procname);
                return query.ToList();
            }
        }
        /// <summary>
        /// procedure  تقوم بتشغيل عن طريق اسمه مع ارسال para
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procname"></param>
        /// <param name="parameters"></param>
        /// <returns>ترجع ليست من الاستعلام</returns>
        public static List<T> procedureDataParams<T>(string procname, Object[] parameters)
        {
            using (var db = new DataClasses1DataContext())
            {
                var query = db.ExecuteQuery<T>("Exec " + procname, parameters);
                return query.ToList();
            }
        }
        /// <summary>
        /// تحويل ListToDataTable
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="items">List المطلوب يحويله</param>
        /// <returns>ترجع DataTable</returns>
        public static DataTable ConvertListToDataTable<T>(this List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties  
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            // Loop through all the properties  
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }

            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows  
                    values[i] = Props[i].GetValue(item, null);
                }
                // Finally add value to datatable  
                dataTable.Rows.Add(values);

            }
            //put a breakpoint here and check datatable of return values  
            return dataTable;
        }
        /// <summary>
        /// تصدير ليست الي اكسل شيت
        /// </summary>
        /// <typeparam name="items">اليست اللي هتتحول الي datatabel</typeparam>
        /// <param name="Worksheet">اسم ملف الاكسل</param>
        /// <returns>تقوم بانشاء ملف اكسل  </returns>
        public static void ExportListToExal<T>(this List<T> items, string Worksheet)
        {
            var props = typeof(T).GetProperties();
            MessageBox.Show(typeof(T).Name); 
            string autosave = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer";
            string path = autosave + @"\" + DateTime.Now.Ticks + " " + Worksheet + ".xlsx";
            if (!Directory.Exists(autosave))
            {
                Directory.CreateDirectory(autosave);
            }
            XLWorkbook wb = new XLWorkbook();
            var workshee = wb.Worksheets.Add(items.ConvertListToDataTable(), "WorksheetName");
            workshee.RightToLeft = true;
            wb.SaveAs(path);
        }
        public static void ExportDataGridViewToExal(this object items, string Worksheet)
        {
            string autosave = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer";
            string path = autosave + @"\" + DateTime.Now.Ticks + " " + Worksheet + ".xlsx";
            if (!Directory.Exists(autosave))
            {
                Directory.CreateDirectory(autosave);
            }
            XLWorkbook wb = new XLWorkbook();
            var workshee = wb.Worksheets.Add((DataTable)items, "WorksheetName");
            workshee.RightToLeft = true;
            wb.SaveAs(path);
        }
        public class ValueAndID
        {
            public int id { get; set; }
            public string name { get; set; }
        }
        private static List<type_cash> type_cash;
        public static List<type_cash> Type_cash_list
        {
            get
            {
                if (type_cash == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        type_cash = db.ExecuteQuery<type_cash>("SELECT * FROM type_cash WHERE  (is_stop = 0) AND (is_hiden = 0)").ToList();
                    }
                }
                return type_cash;
            }
        }
        public static List<ValueAndID> PayMethodsList = new List<ValueAndID>() {
            new ValueAndID() { id = -1, name  ="طريقة الدفع" },
            new ValueAndID() { id = (int)PayMethods.cach, name  ="نقدي" },
            new ValueAndID() { id = (int)PayMethods.agel, name  ="اجل" },
        };
        public static List<ValueAndID> TypeAmountList = new List<ValueAndID>() {
            new ValueAndID() { id = 1, name  ="ايرادات" },
            new ValueAndID() { id = 2, name  ="مصروفات" },
        };
        public enum PayMethods
        {
            cach = 0,
            agel = 1,
            no = 2,
        }
        public static List<ValueAndID> AccsessList = new List<ValueAndID>() {
            new ValueAndID() { id = (int)Accsess.mowazf, name  ="موظف - المخزن الافتراضي فقط" },
            new ValueAndID() { id = (int)Accsess.moderfara, name  ="مدير فرع - موظفين ومخازن الفرع" },
            new ValueAndID() { id = (int)Accsess.moder, name  ="مدير عام - موظفين ومخازن جميع الفروع" },
        };
        public enum Accsess
        {
            mowazf = 0,
            moderfara = 1,
            moder = 2,
        }
        public static List<ValueAndID> AutoUpdatePriceList = new List<ValueAndID>() {
            new ValueAndID() { id = (int)AutoUpdatePrice.Stop, name  ="منع تحديث  سعر الشراء تلقائي" },
            new ValueAndID() { id = (int)AutoUpdatePrice.Auto, name  ="تحديث سعر الشراء تلقائي  " },
            new ValueAndID() { id = (int)AutoUpdatePrice.Ask, name  ="السؤال عن تحديث سعر الشراء" }
        };
        public enum AutoUpdatePrice
        {
            Stop = 0,
            Auto = 1,
            Ask = 2,
        }
        public static company_info companyInfo;
        public static company_info CompanyInfo
        {
            get
            {
                if (companyInfo == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        companyInfo = db.company_infos.FirstOrDefault();
                    }
                }
                return companyInfo;
            }
        }
        private static List<All_account> amount_client_type;
        public static List<All_account> AccountClient
        {
            get
            {
                if (amount_client_type == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        amount_client_type = db.ExecuteQuery<All_account>("SELECT * FROM  All_account WHERE  (type_acount = 2) AND (is_stop = 0)").ToList();
                    }
                }
                return amount_client_type;
            }
        }
        public static List<product_serch_View> ProductsList;
        public static List<product_serch_View> getallprodct
        {
            get
            {
                if (ProductsList == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {

                        ProductsList = db.ExecuteQuery<product_serch_View>("SELECT * FROM product_serch_View ORDER BY name").ToList();

                    }
                }
                return ProductsList;
            }
        }
        public static product_serch_View Get_ProductPyId(int id_product)
        {
            return getallprodct.Where(x => x.id == id_product).FirstOrDefault();
        }
        public static List<product_serch_View> GETProductSerchWithOutStoreView
        {
            get
            {
                List<product_serch_View> _product_serch_View = new List<product_serch_View>(getallprodct.GroupBy(x => x.id).Select(pr => new product_serch_View
                {
                    id = pr.First().id,
                    name = pr.First().name,
                    fullname = pr.First().fullname,
                    price_sale = pr.First().price_sale,
                    code = pr.First().code,
                    Balance = pr.Sum(c => c.Balance),

                })).ToList();
                return _product_serch_View;
            }
        }
        private static List<setting> setting;
        public static List<setting> Setting
        {
            get
            {
                if (setting == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        setting = db.ExecuteQuery<setting>("SELECT * FROM setting").ToList();
                    }
                }
                return setting;
            }
        }
        private static List<fara> fara;
        public static List<fara> Fara
        {
            get
            {
                if (fara == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        fara = db.ExecuteQuery<fara>("SELECT * FROM fara").ToList();
                    }
                }
                return fara;
            }
        }
        public static List<fara> AllFaraWithEmptyrow
        {
            get
            {
                List<fara> faras = new List<fara>(Session.Fara);
                faras.Insert(0, new fara
                {
                    id = 0,
                    name_fara = "كل الفروع"
                });
                return faras;
            }
        }
        private static List<store_View> store;
        public static List<store_View> Store
        {
            get
            {
                if (store == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        store = db.ExecuteQuery<store_View>("SELECT * FROM store_View").ToList();
                    }
                }
                return store;
            }
        }
        public static List<fara> FaraUserLogin
        {
            get
            {
                return Fara.Where(x => x.is_stop == false && x.id == Session.User_login.id_fara).ToList();
            }
        }                
        public static List<user_View> GetUserByFaraId(int id_fara)
        {
            return new List<user_View>(UserList.Where(x => x.id_fara == id_fara));
        }
        public static List<store_View> GetStoreFara(int id_fara)
        {
            using (var db = new DataClasses1DataContext())
            {

                return new List<store_View>(db.store_Views.Where(x => x.id_fara == id_fara));
            }
        }
        private static List<list_price> _list_price;
        public static List<list_price> list_price
        {
            get
            {
                if (_list_price == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        _list_price = db.list_prices.OrderBy(x => x.sort).ToList();
                    }
                }
                return _list_price;
            }
        }
        public static List<list_price> list_priceWithEmptyrow
        {
            get
            {
                List<list_price> stores = new List<list_price>(list_price);
                stores.Insert(0, new list_price
                {
                    id = "0",
                    name_row = ""
                });
                return stores;
            }
        }
        private static List<user_View> _userlist;
        public static List<user_View> UserList
        {
            get
            {
                if (_userlist == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        _userlist = db.ExecuteQuery<user_View>("SELECT * FROM user_View").ToList();
                    }
                }
                return _userlist;
            }
        }
        public static List<user_View> usersfara(int _idfara)
        {
            List<user_View> _users = new List<user_View>(UserList.Where(x => x.id_fara == _idfara && x.is_stop == false));
            _users.Insert(0, new user_View
            {
                id = 0,
                user_name = "جميع موظفين الفرع"
            });
            return _users;
        }
        private static List<client_View> _client_Views;
        public static List<client_View> Client_Views
        {
            get
            {
                if (_client_Views == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        _client_Views = db.ExecuteQuery<client_View>("SELECT * FROM client_View").OrderByDescending(x => x.id).ToList();
                    }
                }
                return _client_Views;
            }
        }
        public static int ConvertInt(string p)
        {
            if (int.TryParse(p, out int result))
                return result;
            return 0;
        }
        public static double ConvertDouble(string p)
        {
            if (double.TryParse(p, out double result))
                return Math.Truncate(result * 100) / 100;
            return 0.00;
        }
        public static decimal Convertdecimal(string p)
        {
            if (decimal.TryParse(p, out decimal result))
                return Math.Truncate(result * 1000) / 1000;
            return 0.000m;
        }
        public static string Replace_text(this string p)
        {
            p = Regex.Replace(p, @"(\W|\.|\[|\]|\\|\||\-|\^|\$|\?|\*|\+|\{|\}|\(|\))", @" ").Trim();
            p = Regex.Replace(p, "عبد ", "عبد");
            p = Regex.Replace(p, "^[ \t\r\n]+|[ \t\r\n]+$", "");
            p = Regex.Replace(p, @"\s+", " ");
            p = Regex.Replace(p, "[إأآ]", "ا");
            p = Regex.Replace(p, "ة", "ه");
            p = Regex.Replace(p, "ؤ", "و");
            p = Regex.Replace(p, "ى", "ي");
            return p.ToString();
        }
        public static Byte[] GetByteFromImage(Image image)
        {
            using (MemoryStream stream = new MemoryStream())
            using (Bitmap bmp = new Bitmap(image))
            {
                bmp.Save(stream, ImageFormat.Jpeg);
                return stream.ToArray();
            }
        }
        public static Image GetImageFromByteArray(Byte[] byteArray)
        {
            try
            {
                using (MemoryStream stream = new MemoryStream(byteArray, false))
                {
                    return Image.FromStream(stream);
                }
            }
            catch (ArgumentException)
            {
                // Log or handle error
                return null;
            }
        }
        public static string GetAllProdcutsale(string from, string to, string serch)
        {
            string s = string.Format(@"
            SELECT product.code, product.name AS product_name,
            SUM(CASE WHEN prodcut_get_View.DateAdd BETWEEN CONVERT(DATETIME, '{0}  00:00:00', 102) AND CONVERT(DATETIME, '{1} 23:59:59',102) THEN prodcut_get_View.ItemQty ELSE 0 END) AS ItemQty, 
            SUM(CASE WHEN prodcut_get_View.DateAdd BETWEEN CONVERT(DATETIME, '{0}  00:00:00', 102) AND CONVERT(DATETIME, '{1} 23:59:59',102) THEN prodcut_get_View.Total ELSE 0 END) AS Total
            FROM product LEFT OUTER JOIN prodcut_get_View  ON product.id = prodcut_get_View.ItemID
            GROUP BY product.id, product.name, product.code 
            HAVING  (product.id LIKE N'{2}')   ORDER BY ItemQty DESC, Total DESC", from, to, serch);
            return s;
        }
        public static string GetAllBlanceProdcut(string from, string to)
        {
            string s = string.Format(@"
            SELECT product.code, product.name AS product_name,
            SUM(CASE WHEN store_log.DateAdd < CONVERT(DATETIME, '{1} 23:59:59',102) THEN store_log.ItemQty_in-store_log.ItemQty_out ELSE 0 END) AS Balance_sabk, 
            SUM(CASE WHEN store_log.DateAdd BETWEEN CONVERT(DATETIME, '{0}  00:00:00', 102) AND CONVERT(DATETIME, '{1} 23:59:59',102) THEN store_log.ItemQty_in ELSE 0 END) AS ItemQty_in, 
            SUM(CASE WHEN store_log.DateAdd BETWEEN CONVERT(DATETIME, '{0}  00:00:00', 102) AND CONVERT(DATETIME, '{1} 23:59:59',102) THEN store_log.ItemQty_out ELSE 0 END) AS ItemQty_out
            FROM dbo.store_log RIGHT OUTER JOIN dbo.product ON dbo.store_log.ItemID = dbo.product.id
            GROUP BY dbo.product.name, dbo.product.code", from, to);
            return s;
        }
        public static void IntializeData<T>(this ComboBox lkp, IEnumerable<T> dataSource, bool add = false)
        {
            lkp.IntializeData(dataSource, "name", "id", add);
        }
        public static void IntializeData<T>(this ComboBox lkp, IEnumerable<T> dataSource, string displayMember, string valueMember, bool add = false)
        {
            List<T> list = dataSource.ToList();
            if (add)
            {
                var emptyItem = Activator.CreateInstance<T>();
                var type = typeof(T);
                var displayProp = type.GetProperty(displayMember);
                var valueProp = type.GetProperty(valueMember);
                if (displayProp != null) displayProp.SetValue(emptyItem, "");
                if (valueProp != null) valueProp.SetValue(emptyItem, 0);
                list.Insert(0, emptyItem);
            }
            lkp.DataSource = list;
            lkp.DisplayMember = displayMember;
            lkp.ValueMember = valueMember;
            //lkp.DataSource = dataSource;
            //lkp.DisplayMember = displayMember;
            //lkp.ValueMember = valueMember;


        }
        public static user_View User_login;
        public static bool _User_login(string tel, string pass)
        {
            bool err = false;
            using (var db = new DataClasses1DataContext())
            {
                var mac = db.UserAccessMachineNames.Where(x => x.macAddress == GetMacAddress()).FirstOrDefault();
                User_login = db.user_Views.Where(x => x.tel == tel && x.password == pass && x.is_stop == false).FirstOrDefault();
                if (User_login != null)
                {
                    if (User_login.any_Machine)
                        err = true;
                    else
                    {
                        if (mac != null&&mac.is_stop!=false)
                            err = true;
                        else
                        {
                            massege.NoMachine.MsgError();
                            err = false;
                        }                        
                    }
                }
                else
                {
                    massege.NoUserLogin.MsgError();
                    err = false;
                }
                if (mac == null)
                {
                    UserAccessMachineName userAccessMachineName = new UserAccessMachineName();
                    userAccessMachineName.id_user_login = User_login?.id ?? 0;
                    userAccessMachineName.macAddress = GetMacAddress();
                    userAccessMachineName.MachineName = Environment.MachineName;
                    userAccessMachineName.UserName = Environment.UserName;
                    userAccessMachineName.Date_login = GetDate();
                    db.UserAccessMachineNames.InsertOnSubmit(userAccessMachineName);
                    db.SubmitChanges();
                }
                else
                {
                    if (mac.id_user_login == 0 && User_login.id!=0)
                    {
                        mac.id_user_login = User_login.id;
                        db.SubmitChanges();
                    }                   
                }
            }          
            return err;
           
        }
        public static setting _setting;
        public static setting User_setting()
        {
            if (_setting == null)
            {
                using (var db = new DataClasses1DataContext())
                {
                    _setting = db.settings.Where(x => x.id == User_login.id_setting).FirstOrDefault();
                }
            }
            return _setting;
        }
        public static DateTime GetDate()
        {
            using (var db = new DataClasses1DataContext())
                return db.ExecuteQuery<DateTime>("SELECT GETDATE()").First();
        }
        public static string zeroToAll(this string s)
        {
            if (s == "0" || s == "-1" || s == "")
                return "%";
            else
                return s;
        }
        public enum type_
        {
            update,
            delete,
            print,

        }
        public static bool checkUpdate(type_ t, DateTime _date, int _id_user)
        {
            bool err = false;
            if (t == type_.update)
            {
                if (User_setting().invoice_update_befor_date == false)
                    if (_date.Date != GetDate().Date)
                    {
                        massege.notUpdateOldDate.MsgError();
                        err = true;
                    }
                if (User_setting().invoice_update_anoter_user == false)
                    if (_id_user != User_login.id)
                    {
                        massege.notUpdateAnthetUser.MsgError();
                        err = true;
                    }
            }
            if (t == type_.delete)
            {
                if (User_setting().invoice_delete_befor_date == false)
                    if (_date.Date != GetDate().Date)
                    {
                        massege.notDeleteOldDate.MsgError();
                        err = true;
                    }
                if (User_setting().invoice_delete_anoter_user == false)
                    if (_id_user != User_login.id)
                    {
                        massege.notDeleteAnthetUser.MsgError();
                        err = true;
                    }

            }
            if (t == type_.print)
            {
                if (User_setting().invoice_print_befor_date == false)
                    if (_date.Date != GetDate().Date)
                    {
                        massege.notPrintOldDate.MsgError();
                        err = true;
                    }
                if (User_setting().invoice_print_anoter_user == false)
                    if (_id_user != User_login.id)
                    {
                        massege.notPrintAnthetUser.MsgError();
                        err = true;
                    }
            }
            return err;
        }
        public static string GetMacAddress()
        {
            string macAddress = string.Empty;
            foreach (var nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
                {
                    macAddress = nic.GetPhysicalAddress().ToString();
                    break;
                }
            }
            return macAddress;
        }
      
    }

}
