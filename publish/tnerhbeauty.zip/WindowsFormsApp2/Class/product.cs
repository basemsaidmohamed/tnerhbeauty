﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.Map.WebForms.BingMaps;
using static tnerhbeauty.Class.Session;

namespace tnerhbeauty.Class
{
    public static class cproduct
    {
        private static DataClasses1DataContext db = new DataClasses1DataContext();
        private static List<store_View> storeUser;
        private static List<fara> faraUser;
        public static string string_ids_store = string.Join(",", StoreUser.Select(x => x.id).ToList());
        public static string string_ids_fara = string.Join(",", FaraUser.Select(x => x.id).ToList());
        public static List<store_View> StoreUser
        {
            get
            {
                if (storeUser == null)
                {
                    if ((Session.Accsess)User_setting().AcssessStore == Session.Accsess.moder)
                    {
                        storeUser = new List<store_View>(Session.Store);                                            
                    }
                    if ((Session.Accsess)User_setting().AcssessStore == Accsess.moderfara)
                    {
                        storeUser = new List<store_View>(Store.Where(x => x.is_stop == false && x.id_fara == User_login.id_fara).ToList());                      
                    }
                    if ((Session.Accsess)User_setting().AcssessStore == Accsess.mowazf)
                    {
                        storeUser= db.ExecuteQuery<store_View>("SELECT id, store_name FROM user_access_store_View WHERE  (id_user = "+ User_login.id + ") AND (is_stop = 0)").ToList();                        
                    }
                    storeUser.Insert(0, new store_View
                    {
                        id = 0,
                        store_name = "اختر"
                    });
                }
               
                return storeUser;
            }
        }
        public static List<fara> FaraUser
        {
            get
            {
                if (faraUser == null)
                {
                    if ((Session.Accsess)User_setting().AcssessStore == Session.Accsess.moder)
                    {
                        faraUser = AllFaraWithEmptyrow;
                    }
                    else
                    {
                        faraUser = FaraUserLogin;
                    }
                }
                return faraUser;
            }
        }      
        public static string StringSerch_product(string tx_serch, string price, string store_id, string Source_Id, string invo)
        {
            string dr = store_id == "0" ? string_ids_store : store_id;
            string Source = Source_Id == "0" || invo == "5" ? "" : $"AND (Source_Id < {Source_Id})";
            return string.Format(@"
            SELECT top (20) product_serch_View.id, product_serch_View.name, product_serch_View.fullname,product_serch_View.{2} as price_sale, product_serch_View.code,
            (SELECT SUM(ItemQty_in - ItemQty_out) AS Expr1
            FROM store_log AS t2
            WHERE (product_serch_View.store_id = store_id) AND (product_serch_View.id = ItemID) {3}) AS Balance, product_serch_View.store_name, product_serch_View.store_id
            FROM product_serch_View INNER JOIN store_log ON product_serch_View.store_id = store_log.store_id AND product_serch_View.id = store_log.ItemID
            WHERE ((product_serch_View.is_stop = 0) AND (product_serch_View.store_id IN ({1}))) and ((name LIKE N'%{0}%') or (code LIKE N'%{0}%') )
            GROUP BY product_serch_View.fullname, product_serch_View.name, product_serch_View.code, product_serch_View.id,product_serch_View.{2}, product_serch_View.store_name, product_serch_View.store_id
            HAVING ((SELECT SUM(ItemQty_in - ItemQty_out) AS Expr1
            FROM store_log AS t2
            WHERE (product_serch_View.store_id = store_id) AND (product_serch_View.id = ItemID) {3}) > 0)
            ORDER BY (CASE WHEN name LIKE N'{0}%' THEN 1 ELSE NULL END) DESC,name
            ", tx_serch.Replace_text(), dr, price, Source);
        }
        public static string StringSerchProductPricebuy(string tx_serch, string price)
        {            
                return string.Format(@"
                SELECT     TOP (20) id, name, fullname,price_buy as price_sale, code,SUM(Balance) as Balance
                FROM       product_serch_View
                WHERE      (is_stop = 0)  
                GROUP BY id, name, fullname, price_buy, code
                HAVING ((name LIKE N'%{0}%') or (code LIKE N'%{0}%') )
                ORDER BY (CASE WHEN name LIKE N'{0}%' THEN 1 ELSE NULL END) DESC,name
                ", tx_serch.Replace_text(), price);               
        }
        public static async Task<List<product_serch_View>> Serch_product(string s, CancellationToken cancellationToken)
        {
            try
            {
                var xx = await Task.Run(() => db.ExecuteQuery<product_serch_View>(s),cancellationToken);              
                return xx.ToList();
            }
            catch (OperationCanceledException)
            {
                // إذا تم إلغاء المهمة
                return new List<product_serch_View>();
            }
            catch 
            {               
                return new List<product_serch_View>();
            }
        }
        static string conn = string.Empty;
        public async static Task<DataTable> ExecuteQuery(string query, SqlParameter[] parameters=null)
        {
            if (conn == string.Empty)
            {
                db = new DataClasses1DataContext();
                conn = db.Connection.ConnectionString;
            }
            using (var connection = new SqlConnection(conn))
            using (var command = new SqlCommand(query, connection))
            using (var adapter = new SqlDataAdapter(command))
            {
                if(parameters != null)
                foreach (var param in parameters)
                {
                    command.Parameters.Add(param);
                }
                var dataTable = new DataTable();
                await Task.Run(() => adapter.Fill(dataTable));
                return dataTable;
            }
        }
        //public async static Task<DataTable> ExecuteQuery(string query)
        //{
        //    if (conn == string.Empty)
        //    {
        //        db = new DataClasses1DataContext();
        //        conn = db.Connection.ConnectionString;
        //    }
        //    using (var connection = new SqlConnection(conn))
        //    using (var command = new SqlCommand(query, connection))
        //    using (var adapter = new SqlDataAdapter(command))
        //    {                
        //        var dataTable = new DataTable();
        //        await Task.Run(() => adapter.Fill(dataTable));
        //        return dataTable;
        //    }
        //}
        public static List<T> ConvertDataGridViewToList<T>(DataGridView dataGridView) where T : new()
        {
           
            var list = new List<T>();

            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (!row.IsNewRow) // تجاهل الصف الجديد الافتراضي
                {
                    T obj = new T();

                    foreach (var prop in typeof(T).GetProperties())
                    {
                        if (dataGridView.Columns.Contains(prop.Name) && row.Cells[prop.Name].Value != null && row.Cells[prop.Name].Value != DBNull.Value)
                        {
                            prop.SetValue(obj, Convert.ChangeType(row.Cells[prop.Name].Value, prop.PropertyType), null);
                        }
                    }

                    list.Add(obj);
                }
            }

            return list;
        }
        public static T ConvertDataGridViewRowToObject<T>(DataGridView dataGridView) where T : new()
        {
            if (dataGridView.CurrentCell == null)
                throw new InvalidOperationException("No row is currently selected.");

            int rowIndex = dataGridView.CurrentCell.RowIndex;

            if (rowIndex < 0 || rowIndex >= dataGridView.Rows.Count)
                throw new IndexOutOfRangeException("Invalid row index.");

            var row = dataGridView.Rows[rowIndex];

            if (row.IsNewRow)
                throw new InvalidOperationException("The selected row is a new row and cannot be converted.");

            T obj = new T();

            foreach (var prop in typeof(T).GetProperties())
            {
                if (dataGridView.Columns.Contains(prop.Name) && row.Cells[prop.Name].Value != null && row.Cells[prop.Name].Value != DBNull.Value)
                {
                    var targetType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                    var value = row.Cells[prop.Name].Value == null || row.Cells[prop.Name].Value == DBNull.Value
                        ? null
                        : Convert.ChangeType(row.Cells[prop.Name].Value, targetType);
                    prop.SetValue(obj, value, null);

                }
            }

            return obj;
        }
        public static async Task<DataTable> GetProductDataAsync(int ItemID,int id,DateTime dt_date_from,DateTime dt_date_to)
        {
            try
            {
                // استعلام SQL
                string query = @"
            SELECT *
            FROM prodcut_get_View
            WHERE
                (@ItemID = 0 OR ItemID = @ItemID)
                AND (@id = 0 OR id_cient = @id)
                AND (CAST(DateServer AS DATE) >= @dt_date_from AND CAST(DateServer AS DATE) <= @dt_date_to)";

                // إعداد المعلمات
                var parameters = new[]
                {
            new SqlParameter("@ItemID", ItemID),
            new SqlParameter("@id", id),
            new SqlParameter("@dt_date_from", dt_date_from.Date),
            new SqlParameter("@dt_date_to", dt_date_to.Date)
        };

                // تنفيذ الاستعلام
                using (var connection = new SqlConnection(db.Connection.ConnectionString))
                using (var command = new SqlCommand(query, connection))
                using (var adapter = new SqlDataAdapter(command))
                {
                    foreach (var param in parameters)
                    {
                        command.Parameters.Add(param);
                    }

                    var dataTable = new DataTable();
                    await Task.Run(() => adapter.Fill(dataTable));
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return null;
            }
        }
        public static async Task<List<product_serch_View>> Find_product(string tx_serch, bool HideZero, bool groub)
        {
            try
            {
                string notaccsesstire = "";
                //if ((Session.Accsess)User_login.ID_access != Session.Accsess.moder)
                //notaccsesstire = "AND (store_id in("+ string_ids_store + "))";
                string text = (!HideZero ? "=" : "");
                string q = "";
                if (groub)
                q = @"SELECT  *  
                FROM       product_serch_View
                WHERE    ((name LIKE N'%{0}%') or (code LIKE N'%{0}%') )  AND (Balance > {1} 0) {2}
                ORDER BY (CASE WHEN name LIKE N'{0}%' THEN 1 ELSE NULL END) DESC,name";
                else
                q = @"SELECT 
    id, 
    fullname, 
    name, 
    code, 
    price_buy, 
    price_sale, 
    price_sale_100, 
    price_sale_75, 
    price_sale_vip2, 
    price_sale_vip1, 
    price_1, 
    price_2, 
    price_3, 
    price_4, 
    price_5, 
    price_6, 
    price_7, 
    price_8, 
    price_9, 
    price_10, 
    update_price, 
    SUM(Balance) AS Balance, 
    min_mum, 
    1 AS store_id, 
    '' AS store_name, 
    is_stop
FROM 
    product_serch_View
WHERE 
    (name LIKE N'%{0}%' OR code LIKE N'%{0}%')
GROUP BY 
    id, 
    fullname, 
    name, 
    code, 
    price_buy, 
    price_sale, 
    price_sale_100, 
    price_sale_75, 
    price_sale_vip2, 
    price_sale_vip1, 
    price_1, 
    price_2, 
    price_3, 
    price_4, 
    price_5, 
    price_6, 
    price_7, 
    price_8, 
    price_9, 
    price_10, 
    update_price, 
    min_mum, 
    is_stop
HAVING 
    SUM(Balance) > {1} 0
ORDER BY 
    CASE WHEN name LIKE N'{0}%' THEN 1 ELSE NULL END DESC, 
    name;";
                string s = string.Format(q, tx_serch.Replace_text(), text, notaccsesstire);                
                var xx = await Task.Run(() => db.ExecuteQuery<product_serch_View>(s));
                return xx.ToList();
            }            
            catch
            {
                return new List<product_serch_View>();
            }
        }
        public static async Task<List<product_serch_View>> Serch_product(string tx_serch, string price, string store_id)
        {
            try
            {
                string dr = store_id == "0" ? string.Join(",", string_ids_store) : store_id;
                string s = string.Format(@"
                SELECT     TOP (20) id, name, fullname, {2} as price_sale, code, Balance, store_name, store_id
                FROM       product_serch_View
                WHERE    ((Balance > 0) AND (is_stop = 0) and store_id IN ({1})) and ((name LIKE N'%{0}%') or (code LIKE N'%{0}%') )
                ORDER BY (CASE WHEN name LIKE N'{0}%' THEN 1 ELSE NULL END) DESC,name
                ", tx_serch.Replace_text(), dr, price);
                //await Task.Run(() => Thread.Sleep(5000));
                var xx = await Task.Run(() => db.ExecuteQuery<product_serch_View>(s));
                return xx.ToList();
            }
            catch
            {
                return new List<product_serch_View>();
            }
        }
        public async static Task<List<product_serch_View>> Serch_product2(string tx_serch, string price, string store_id)
        {
            try
            {
                string dr = store_id == "0" ? string_ids_store : store_id;
                var xx = await Task.Run(() => db.serch_product(tx_serch.Replace_text(), price, dr));
                return xx.ToList();
            }
            catch
            {
                return new List<product_serch_View>();
            }
        }
        //ارصدة الاصناف في المخازن
        public static async Task<DataTable> GetBalnceInstores(string itemID, string store_id, bool HideZero, bool groub)
        {
            //try
            //{
            string query = "";
            if (itemID == "0")
                itemID = "%";
            string text = (!HideZero ? "=" : "");
            string dr = store_id == "0" ? string_ids_store : store_id;
            if (groub)
                query = string.Format(@"
                SELECT ItemID, code, product_name, SUM(Balance) AS Balance, store_id, store_name
                FROM store_log_View
                GROUP BY ItemID, product_name, code, store_id, store_name
                HAVING      (ItemID  LIKE N'{0}') AND store_id IN ({1}) AND (SUM(Balance) >{2} 0) 
                ORDER BY product_name
                ", itemID, dr, text);
            else
                query = string.Format(@"
                SELECT ItemID, code, product_name, SUM(Balance) AS Balance, 0 as store_id,'' as store_name
                FROM store_log_View
                WHERE store_id IN ({1})
                GROUP BY ItemID, product_name, code
                HAVING (ItemID  LIKE N'{0}') AND  (SUM(Balance) >{2} 0) 
                ORDER BY product_name
                ", itemID, dr, text);           
            return await Task.Run(() => ExecuteQuery(query));

           
            //}
            //catch
            //{
            //    return new List<product_serch_View>();
            //}
        }

        public static async Task<List<store_log_Balance_View>> Get_Balance_product_in_out(string ItemID, bool HideZero, string store_id, bool GROUPstore, string date)
        {
            string dr = store_id == "0" ? string_ids_store : store_id;
            string zero = "";
            string query = "";           
            if (ItemID == "" || ItemID == "0")
                ItemID = "%";
            zero = (!HideZero ? "=" : "");
            zero = HideZero ? "and  (ISNULL(SUM(CASE WHEN (store_id IN (" + dr + ")) THEN ISNULL(ItemQty_in -ItemQty_out , 0.000) END), 0.000) <> 0)" : "";

            if (GROUPstore == false)
                query = String.Format(
                @"SELECT ItemID,code, product_name,
                ISNULL(SUM(CASE WHEN DateAdd <  '{3}' AND (store_id IN ({1}))  THEN ItemQty_in - ItemQty_out END), 0.000) AS Balance_sabk, 
                ISNULL(SUM(CASE WHEN DateAdd >= '{3}' AND (store_id IN ({1}))  THEN ItemQty_in END), 0.000) AS ItemQty_in, 
                ISNULL(SUM(CASE WHEN DateAdd >= '{3}' AND (store_id IN ({1}))  THEN ItemQty_out END), 0.000) AS ItemQty_out, 
                ISNULL(SUM(CASE WHEN                      (store_id IN ({1}))  THEN ItemQty_in - ItemQty_out END), 0.000) AS Balance, '' AS store_name 
                FROM        store_log_View
                GROUP BY ItemID, code, product_name
                HAVING     (ItemID LIKE '{0}') 
                AND(
                ISNULL(SUM(CASE WHEN DateAdd <  '{3}' AND (store_id IN ({1}))  THEN ItemQty_in - ItemQty_out END), 0.000) +
                ISNULL(SUM(CASE WHEN DateAdd >= '{3}' AND (store_id IN ({1}))  THEN ItemQty_in END), 0.000)  +
                ISNULL(SUM(CASE WHEN DateAdd >= '{3}' AND (store_id IN ({1}))  THEN ItemQty_out END), 0.000) +
                ISNULL(SUM(CASE WHEN                      (store_id IN ({1}))  THEN ItemQty_in - ItemQty_out END), 0.000) <> 0
                ){2}
                ORDER BY ItemID",
                ItemID, dr, zero, date);

            if (GROUPstore == true)
                query = String.Format(
                @"SELECT ItemID,code, product_name,
                ISNULL(SUM(CASE WHEN DateAdd <  '{3}' AND (store_id IN ({1}))   THEN ItemQty_in - ItemQty_out END), 0.000) AS Balance_sabk, 
                ISNULL(SUM(CASE WHEN DateAdd >= '{3}' AND (store_id IN ({1}))   THEN ItemQty_in END), 0.000) AS ItemQty_in, 
                ISNULL(SUM(CASE WHEN DateAdd >= '{3}' AND (store_id IN ({1}))   THEN ItemQty_out END), 0.000) AS ItemQty_out, 
                ISNULL(SUM(CASE WHEN                      (store_id IN ({1}))   THEN ItemQty_in - ItemQty_out END), 0.000) AS Balance, store_name 
                FROM        store_log_View
                GROUP BY ItemID, code, product_name,store_name
                HAVING     (ItemID LIKE '{0}')
                AND(
                ISNULL(SUM(CASE WHEN DateAdd <  '{3}' AND (store_id IN ({1}))  THEN ItemQty_in - ItemQty_out END), 0.000) +
                ISNULL(SUM(CASE WHEN DateAdd >= '{3}' AND (store_id IN ({1}))  THEN ItemQty_in END), 0.000)  +
                ISNULL(SUM(CASE WHEN DateAdd >= '{3}' AND (store_id IN ({1}))  THEN ItemQty_out END), 0.000) +
                ISNULL(SUM(CASE WHEN                      (store_id IN ({1}))  THEN ItemQty_in - ItemQty_out END), 0.000) <> 0
                ){2}
                ORDER BY ItemID",
                ItemID, dr, zero, date);
            var xx = await Task.Run(() => db.ExecuteQuery<store_log_Balance_View>(query));
            return xx.ToList();

        }
        public static async Task<DataTable> Get_kasf_hesab_product(string ItemID, string store_id, string DateFrom, string DateTo)
        {
            string dr = store_id == "0" ? string_ids_store : store_id;
            string query = "";
            if (ItemID == "" || ItemID == "0")
                ItemID = "%";
            query = String.Format(@"
                SELECT ItemID,  DateAdd, Source_Id, Balance_sabk, ItemQty_in, ItemQty_out, Balance,  nots
                FROM dbo.kasf_hesab_product_view
                WHERE ItemID LIKE '{0}' AND (store_id IN ({1})) AND (CAST(DateAdd as date) between '{2}' and '{3}') 
                ORDER BY Source_Id
                ",
            ItemID, dr, DateFrom, DateTo);
            return await Task.Run(() => ExecuteQuery(query));

        }
        //public static async Task<List<kasf_hesab_product_view>> Get_kasf_hesab_product(string ItemID, string store_id, string DateFrom, string DateTo)
        //{
        //    string dr = store_id == "0" ? string_ids_store : store_id;
        //    string query = "";
        //    if (ItemID == "" || ItemID == "0")
        //        ItemID = "%";
        //    query = String.Format(@"
        //        SELECT ItemID, code, product_name, DateAdd, Source_Id, Balance_sabk, ItemQty_in, ItemQty_out, Balance, store_id,store_name, nots
        //        FROM dbo.kasf_hesab_product_view
        //        WHERE ItemID LIKE '{0}' AND (store_id IN ({1})) AND (CAST(DateAdd as date) between '{2}' and '{3}') 
        //        ORDER BY Source_Id
        //        ",
        //    ItemID, dr, DateFrom, DateTo);
        //    var xx = await Task.Run(() => db.ExecuteQuery<kasf_hesab_product_view>(query));
        //    return xx.ToList();
        //}
    }
}



