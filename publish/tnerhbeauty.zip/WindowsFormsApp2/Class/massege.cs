﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tnerhbeauty.Class
{
    public static class massege
    {
        
        public static string  title = "تنبيه";
        public static string  notDeleteOldDate = "ليس لديك صلاحيات حذف بيان بتاريخ سابقا";
        public static string  notUpdateOldDate = "ليس لديك صلاحيات تعديل بيان بتاريخ سابقا";
        public static string  notPrintOldDate = "ليس لديك صلاحيات طباعة بيان بتاريخ سابقا";
        public static string  notDeleteAnthetUser = "ليس لديك صلاحيات حذف بيان موظف اخر";
        public static string  notUpdateAnthetUser = "ليس لديك صلاحيات تعديل بيان موظف اخر";
        public static string  notPrintAnthetUser = "ليس لديك صلاحيات طباعة بيان موظف اخر";
        public static string  ExptionAnthetTime = "برجاء المحاولة لاحقا";
        public static string  successfully = "تم حفظ البيانات بنجاح";
        public static string  NotSave = "لم يتم الحفظ";
        public static string  NotNull = "حقل اجباري";
        public static string  AskDelete = "هل تريد حذف البيان ... ؟";
        public static string  NotDelete = "لا يمكن حذف البيان ربما توجد عمليات مسجلة ... !";
        public static string  Notduplica = "لا يمكن تكرار نفس البيان";
        public static string  NoMachine = "هذا الجهاز ليس لدية صلاحية برجاء الرجوع لمدير النظام";
        public static string  NoUserLogin = "اسم المستخدم او كلمة المرور خطاء";
        public static void MsgError(this string s)
        {
            MyMessageBox.showMessage(title, s, "", MessageBoxButtons.RetryCancel);
        }
        public static void Msgsucsses(this string s)
        {
            MyMessageBox.showMessage(title, s, "", MessageBoxButtons.OK);
        }
        public static void Msgwarning(this string s)
        {
            MyMessageBox.showMessage(title, s, "", MessageBoxButtons.YesNo);
        }
    }
    
    
}
