﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using static tnerhbeauty.Class.Session;

namespace tnerhbeauty.Class
{
    public static class invoice
    {
        private static DataClasses1DataContext db = new DataClasses1DataContext();
        private static List<invoice_type> listInvoiceType;
        public static List<invoice_type> ListInvoiceType
        {
            get
            {
                if (listInvoiceType == null)
                {
                    using (var db = new DataClasses1DataContext())
                    {
                        listInvoiceType = db.invoice_types.ToList();
                    }
                }
                return listInvoiceType;
            }
        }
        public static invoice_type GetInvoiceType(int id)
        {
            return ListInvoiceType.Where(x => x.id == id).FirstOrDefault();
        }      
        public enum type_qty
        {
            Qty_OF = 0,
            Qty_in = 1,
            Qty_out = 2,
            QtyToStor = 3,
        }
        public async static Task<List<client_View>> SerchClientView(string tx_serch)
        {
            try
            {
                string s = string.Format(@"
                SELECT * FROM client_View
                WHERE ((name LIKE N'%{0}%') or (tel LIKE N'%{0}%') )
                ORDER BY (CASE WHEN name LIKE N'{0}%' THEN 1 ELSE NULL END) DESC,name
                ", tx_serch.Replace_text());
                var xx = await Task.Run(() => db.ExecuteQuery<client_View>(s));
                return (List<client_View>)(xx.ToList());
            }
            catch
            {
                return new List<client_View>();
            }
        }
        public static async Task<List<InvoiceHeaderView>> Serch_Invoice(string id, string id_cient, string id_invoice_type, string Notes, string is_agel, string id_user, string id_fara, string DateAddFrom, string DateAddTo)
        {
            try
            {
                if (id == "")
                    id = "%";
                if (id_cient == "0")
                    id_cient = "%";
                if (is_agel == "-1")
                    is_agel = "%";
                if (id_user == "0")
                    id_user = "%";
                if (id_fara == "0")
                    id_fara = cproduct.string_ids_fara;
                string s = string.Format(@"
                SELECT * FROM InvoiceHeaderView WHERE
                    (id like '{8}')
                AND (id_cient like '{0}')
                AND (id_invoice_type in ({1}))
                AND (Notes   like '%{2}%')
                AND (is_agel like '{3}')
                AND (id_user like '{4}')
                AND (id_fara in ({5}))
                AND ((CAST(DateServer as date) between '{6}' and '{7}') )
                ORDER BY id DESC
                ", id_cient, id_invoice_type, Notes.Replace_text(), is_agel, id_user, id_fara, DateAddFrom, DateAddTo, id);
                var xx = await Task.Run(() => db.ExecuteQuery<InvoiceHeaderView>(s));
                return xx.ToList();
            }
            catch
            {
                return new List<InvoiceHeaderView>();
            }
        }
        public static bool ChekAndDeleteStoreAndAmount(int invoiceHeaderid)
        {
            var results = db.ChekAndDeleteStoreAndAmount2(invoiceHeaderid);
            if (Session.ConvertInt(results.ReturnValue.ToString()) == 1)
                return true;
            else
            {
                string ids = string.Join("\n", results.Select(x => x.mas).ToArray());
                MyMessageBox.showMessage("لا يمكن تعديل الفاتورة الي مسودة رصيد سالب", ids, "", MessageBoxButtons.RetryCancel);
                return false;
            }
        }
        public static void DeleteStoreAndAmount(int invoiceHeaderid)
        {
            db.DeleteStoreAndAmount(invoiceHeaderid);
        }
        public static bool deleteInvoice(int invoiceHeaderid)
        {
            if (MyMessageBox.showMessage("هل انت متاكد", massege.AskDelete, "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return false;
            var results = db.deleteInvoiceHeaderANDamount_client(invoiceHeaderid);
            if (Session.ConvertInt(results.ReturnValue.ToString()) == 1)
                return true;
            else
            {
                string ids = string.Join("\n", results.Select(x => x.mas).ToArray());
                MyMessageBox.showMessage("لا يمكن حذف الفاتورة رصيد سالب", ids, "", MessageBoxButtons.RetryCancel);
                return false;
            }
        }
        public enum invoice_name
        {
            invoice_pay = 1,
            invoice_sale,
            invoice_to_store,
            invoice_pay_from_store,
            Invoice_nots,
            invoice_taswet_edafa,
            invoice_taswiat_khasm,
            invoice_return_to_supplier,
            invoice_return_from_client,
            invoice_broken,
        }
        //public static async Task<bool> dddd(int invoiceHeaderid)
        //{
        //    return await Task.Run(() => Convert.ToBoolean( db.DeleteStoreAndAmount(invoiceHeaderid)));
        //}
        public async static Task<string> GetReturn(string ItemID, string id_cient, string id_invoice_type)
        {
            try
            {
                string inv = "";
                if (Convert.ToInt16(id_invoice_type) == (int)invoice_name.invoice_return_from_client)
                {
                    inv = "1";
                }
                if (Convert.ToInt16(id_invoice_type) == (int)invoice_name.invoice_return_to_supplier)
                {
                    inv = "2";
                }
                if (inv == "")
                    return null;
                string s = string.Format(@"SELECT TOP (1) * FROM GetProductReturnView
                WHERE (ItemID = {0}) AND (id_cient = {1}) AND (id_invoice_type = {2})
                ORDER BY id DESC", ItemID, id_cient, inv);
                GetProductReturnView pro = await Task.Run(() => db.ExecuteQuery<GetProductReturnView>(s).FirstOrDefault());

                if (pro == null)
                    return "لم تتم عملية شراء ";
                string mas = "";
                mas = "اخر بيانات فاتورة شراء" + " - ";
                mas += "فاتورة رقم" + " " + pro.InvoiceHeaderID.ToString() + " ";
                mas += "بسعر" + " " + pro.Price.ToString() + " ";
                mas += "الكمية" + " " + pro.ItemQty.ToString() + " ";
                mas += "الاجمالي" + " " + pro.Total.ToString() + " ";
                mas += "بتاريح" + " " + pro.DateServer.ToString("yyyy/MM/dd"); ;

                return mas;
            }
            catch
            {
                return null;
            }
        }
       


    }
}
