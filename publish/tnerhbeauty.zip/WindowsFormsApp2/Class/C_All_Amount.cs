﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tnerhbeauty.Class
{
    public class C_All_Amount
    {
        private static DataClasses1DataContext db = new DataClasses1DataContext();
        public static async Task<List<AllAmount_View>> ReportEndDayDitals(string id_user, string id_fara, string DateAddFrom, string DateAddTo)
        {
            try
            {
                if (id_user == "0")
                    id_user = "%";
                if (id_fara == "0")
                    id_fara = cproduct.string_ids_fara;
                string s = string.Format(@"
                SELECT     type_name, amount , cash_name,name_fara,user_name,type_amount
                FROM        dbo.AllAmount_View
                WHERE      (id_fara in ({0})) AND (id_user like '{1}') and (CAST(DateServer AS date) BETWEEN '{2}' AND '{3}')             
                ", id_fara, id_user, DateAddFrom, DateAddTo);
                var xx = await Task.Run(() => db.ExecuteQuery<AllAmount_View>(s));
                return xx.ToList();
            }
            catch
            {
                return new List<AllAmount_View>();
            }
        }
        public static async Task<List<AllAmount_View>> ReportEndDaynocash(string id_user, string id_fara, string DateAddFrom, string DateAddTo)
        {
            try
            {
                if (id_user == "0")
                    id_user = "%";
                if (id_fara == "0")
                    id_fara = cproduct.string_ids_fara;
                string s = string.Format(@"
                SELECT     type_name, SUM(amount) AS amount , COUNT(amount) AS count, type_amount
                FROM        dbo.AllAmount_View
                WHERE     (CAST(DateServer AS date) BETWEEN '{2}' AND '{3}')AND (id_fara in ({0})) AND (id_user like '{1}') 
                GROUP BY type_name,  type_amount
                
                ", id_fara, id_user, DateAddFrom, DateAddTo);
                var xx = await Task.Run(() => db.ExecuteQuery<AllAmount_View>(s));
                return xx.ToList();
            }
            catch
            {
                return new List<AllAmount_View>();
            }
        }
        public static async Task<List<AllAmount_View>> ReportEndDay(string id_user, string id_fara, string DateAddFrom, string DateAddTo)
        {
            try
            {
                if (id_user == "0")
                    id_user = "%";
                if (id_fara == "0")
                    id_fara = cproduct.string_ids_fara;
                string s = string.Format(@"
                SELECT     type_name, SUM(amount) AS amount , COUNT(amount) AS count,id_cash, cash_name ,type_amount
                FROM        dbo.AllAmount_View
                WHERE     (CAST(DateServer AS date) BETWEEN '{2}' AND '{3}')AND (id_fara in ({0})) AND (id_user like '{1}') 
                GROUP BY type_name, id_cash, cash_name,type_amount
                
                ", id_fara, id_user, DateAddFrom, DateAddTo);
                var xx = await Task.Run(() => db.ExecuteQuery<AllAmount_View>(s));
                return xx.ToList();
            }
            catch
            {
                return new List<AllAmount_View>();
            }
        }
        public static async Task<List<AllAmount_View>> SumEndDay(string id_user, string id_fara, string DateAddFrom, string DateAddTo, string amount)
        {
            try
            {
                if (id_user == "0")
                    id_user = "%";
                if (id_fara == "0")
                    id_fara = cproduct.string_ids_fara;
                string s = string.Format(@"
                SELECT     id_cash,SUM(amount) AS amount, COUNT(amount) AS count, cash_name
                FROM        dbo.AllAmount_View
                WHERE     (CAST(DateServer AS date) BETWEEN '{2}' AND '{3}')AND (id_fara in ({0})) AND (id_user like '{1}') AND type_amount = {4}
                GROUP BY id_cash, cash_name
                
                ", id_fara, id_user, DateAddFrom, DateAddTo, amount);
                var xx = await Task.Run(() => db.ExecuteQuery<AllAmount_View>(s));
                return xx.ToList();
            }
            catch
            {
                return new List<AllAmount_View>();
            }
        }
        public static async Task<List<AllAmount_View>> SerchAllAmount(string id_user, string id_fara, string DateAddFrom, string DateAddTo, string type_amount, string id_account, string id_cash, string nots)
        {
            try
            {
                if (id_fara == "0")
                    id_fara = cproduct.string_ids_fara;
                string s = string.Format(@"
                SELECT   top(100) *
                FROM        dbo.AllAmount_View
                WHERE      (Source_Id = 0) AND (id_fara in ({0})) AND (id_user like '{1}') and (CAST(DateServer AS date) BETWEEN '{2}' AND '{3}') AND type_amount like '{4}' AND id_account  like '{5}'  AND id_cash  like '{6}' AND nots  like '%{7}%'      
                ", id_fara, id_user.zeroToAll(), DateAddFrom, DateAddTo, type_amount.zeroToAll(), id_account.zeroToAll(), id_cash.zeroToAll(), nots.zeroToAll());
                var xx = await Task.Run(() => db.ExecuteQuery<AllAmount_View>(s));
                return xx.ToList();
            }
            catch
            {
                return new List<AllAmount_View>();
            }
        }

    }

}
