﻿namespace tnerhbeauty.Class
{
    public class mas
    {
        public string NotAccess() => "ليس لديك صلاحيات لتنفيذ هذا الاجراء";

    }
}
