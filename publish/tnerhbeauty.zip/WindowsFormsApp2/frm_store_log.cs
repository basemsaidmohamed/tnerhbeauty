﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;

namespace tnerhbeauty
{
    public partial class frm_store_log : Form
    {
        DataClasses1DataContext db;
        public frm_store_log()
        {
            InitializeComponent();
        }
        kasf_hesab_product_view kasf_hesab_product_view;
        private void all_kushufat_Load(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            dr_store.IntializeData(cproduct.StoreUser, nameof(store.store_name), nameof(store.id));

            gv.DataSource = new List<kasf_hesab_product_view>();
            gv.Columns[nameof(kasf_hesab_product_view.store_id)].Visible = false;
            gv.Columns[nameof(kasf_hesab_product_view.ItemID)].Visible = false;
            //gv.Columns[nameof(kasf_hesab_product_view.Source_Id)].Visible = false;
            gv.Columns[nameof(kasf_hesab_product_view.Source_Id)].HeaderText = "بيان رقم";
            gv.Columns[nameof(kasf_hesab_product_view.code)].HeaderText = "كود الصنف";
            gv.Columns[nameof(kasf_hesab_product_view.product_name)].HeaderText = "  اسم الصنف";
            gv.Columns[nameof(kasf_hesab_product_view.ItemQty_in)].HeaderText = "وارد";
            gv.Columns[nameof(kasf_hesab_product_view.ItemQty_out)].HeaderText = "صادر";
            gv.Columns[nameof(kasf_hesab_product_view.Balance)].HeaderText = "الرصيد";
            gv.Columns[nameof(kasf_hesab_product_view.DateAdd)].HeaderText = "تاريخ";
            gv.Columns[nameof(kasf_hesab_product_view.nots)].HeaderText = "ملاحظات";
            gv.Columns[nameof(kasf_hesab_product_view.nots)].FillWeight = 150;
            gv.Columns[nameof(kasf_hesab_product_view.Balance_sabk)].HeaderText = "رصيد سابق";
            gv.Columns[nameof(kasf_hesab_product_view.store_name)].HeaderText = "المخزن";
           
        }
        string p_name_client = "";
        string p_prodct = "";
        string p_date_from = "";

        bool valid()
        {
            //ErrorProvider errorProvider1 = new ErrorProvider();
            errorProvider1.Clear();
            int error = 0;
            if (string.IsNullOrWhiteSpace(tx_prodct.Text))
            {
                errorProvider1.SetError(tx_prodct, massege.NotNull);
                error++;
            }

            if (dr_store.SelectedValue.ToString()=="0")
            {
                errorProvider1.SetError(dr_store, massege.NotNull);
                error++;
            }
            
            return error == 0;
        }
        private void bt_search_Click(object sender, EventArgs e)
        {
            if(valid())           
            getdata();
           
        }
        public async void getdata()
        {
           
            DataTable dt =new DataTable();
            pic_login.Visible = true;
            bt_search.Enabled=false;           
            dt = await cproduct.Get_kasf_hesab_product(ItemID.ToString(), dr_store.SelectedValue.ToString(), dt_date_from.Value.ToString("yyyy/MM/dd"), dt_date_to.Value.ToString("yyyy/MM/dd"));
            gv.DataSource = dt;
            pic_login.Visible = false;
            bt_search.Enabled = true;
            
            var _Balance_sabk = dt.AsEnumerable().Sum(x => x.Field<decimal>(nameof(kasf_hesab_product_view.Balance_sabk))).ToString("0.000");
            var amount_in = dt.AsEnumerable().Sum(x => x.Field<decimal>(nameof(kasf_hesab_product_view.ItemQty_in))).ToString("0.000");
            var amount_out = dt.AsEnumerable().Sum(x => x.Field<decimal>(nameof(kasf_hesab_product_view.ItemQty_out))).ToString("0.000");
            var Balance = dt.AsEnumerable().Sum(x => x.Field<decimal>(nameof(kasf_hesab_product_view.Balance))).ToString("0.000");
            //var _Balance_sabk = qq.Sum(x => (decimal?)x.Balance_sabk) ?? 0;
            //var amount_in = qq.Sum(x => (decimal?)x.ItemQty_in) ?? 0;
            //var amount_out = qq.Sum(x => (decimal?)x.ItemQty_out) ?? 0;
            //var Balance = qq.Sum(x => (decimal?)x.Balance) ?? 0;
            lb_Balance_sabk.Text = "0.000";
            lp_total.Text = "0.000";
            lp_amunt_out.Text = amount_out;
            lp_amunt_in.Text = amount_in;
            lp_count.Text = dt.Rows.Count.ToString();
            if (dt != null && ItemID != 0 && dt.Rows.Count != 0)
            {
                lb_Balance_sabk.Text = dt.AsEnumerable().FirstOrDefault()?[nameof(kasf_hesab_product_view.Balance_sabk)].ToString();
                lp_total.Text = dt.AsEnumerable().LastOrDefault()?[nameof(kasf_hesab_product_view.Balance)].ToString();
            }
            p_date_from = dt_date_from.Value.ToString();
            p_prodct = tx_prodct.Text;
        }
        int ItemID = 0;
        private void bt_product_Click(object sender, EventArgs e)
        {
            selct_prodct _selct_prodct = new selct_prodct();
            _selct_prodct.ShowDialog();
            product_serch_View prod = _selct_prodct.retrnval();
            if (prod != null)
            {
                ItemID = prod.id;
                tx_prodct.Text = prod.fullname;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ItemID = 0;
            tx_prodct.Text = "";
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0)
                return;
            List<ReportParameter> para = new List<ReportParameter>();
            para.Add(new ReportParameter("p_date_from", p_date_from));
            para.Add(new ReportParameter("p_dt_date_to", p_date_from));
            para.Add(new ReportParameter("p_name_client", p_name_client));
            para.Add(new ReportParameter("p_prodct", p_prodct));
            para.Add(new ReportParameter("p_report_name", "كشف حساب صنف"));
            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("store_log_View", gv.DataSource),
            };
            frm_show_report _Report = new frm_show_report(para, "frm_store_log", ReportDataSource, true);
            _Report.Show();
        }

        private void btn_export_exal_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0) return;
            lb_mas.Text = "  جاري انشاء ملف الاكسيل ...";           
            gv.DataSource.ExportDataGridViewToExal(" كشف حساب صنف " + tx_prodct.Text);
            lb_mas.Text = @"تم حفظ الملف  \" + Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer" + @"\" + DateTime.Now.Ticks + "Response.xlsx" + "";
        }
    }
}

























//List<store_log_Balance_View> Store_log_Balance_View = new List<store_log_Balance_View>();

//var qq = db.store_log_Balance_Views.GroupBy(x => x.ItemID).Select(cl => new store_log_Balance_View
//{

//    ItemID = cl.First().ItemID,
//    code = cl.First().code,
//    product_name = cl.First().product_name,
//    Balance_sabk = (decimal?)cl.Where(x => x.DateAdd.Date < dt_date_from.Value.Date).Sum(x => (decimal?)x.ItemQty_in - (decimal?)x.ItemQty_out) ?? 0,
//    ItemQty_in = (decimal?)cl.Where(x => (x.DateAdd.Date >= dt_date_from.Value.Date) && (x.DateAdd.Date <= dt_date_to.Value.Date)).Sum(x => x.ItemQty_in) ?? 0,
//    ItemQty_out = (decimal?)cl.Where(x => (x.DateAdd.Date >= dt_date_from.Value.Date) && (x.DateAdd.Date <= dt_date_to.Value.Date)).Sum(x => x.ItemQty_out) ?? 0,
//    Balance = (decimal?)cl.Where(x => x.DateAdd.Date < dt_date_to.Value).Sum(x => x.ItemQty_in - x.ItemQty_out) ?? 0,
//}).ToList();

//gv.DataSource = qq;