﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;

namespace tnerhbeauty
{
    public partial class frm_All_Amount : Form
    {
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;  // Turn on WS_EX_COMPOSITED
                return cp;
            }
        }
        public frm_All_Amount()
        {
            InitializeComponent();
        }
        private void all_kushufat_Load(object sender, EventArgs e)
        {

            dr_fara.IntializeData(cproduct.FaraUser, nameof(fara.name_fara), nameof(fara.id));
            dr_fara.SelectedValue = Session.User_login.id_fara;
            dr_fara_SelectedIndexChanged(null, null);
            dr_selct_report.SelectedIndex = 0;
            gv_in.AutoGenerateColumns = false;
            gv_out.AutoGenerateColumns = false;
            datagrid1.AutoGenerateColumns = false;
            gv_total_in.AutoGenerateColumns = false;
            gv_total_out.AutoGenerateColumns = false;
            getdata();
        }
        decimal amount_in = 0;
        decimal amount_out = 0;
        public async void getdata()
        {
            lb_mas.Text = "";
            amount_in = 0;
            amount_out = 0;
            pic_login.Visible = true;
            List<AllAmount_View> q = new List<AllAmount_View>();
            List<AllAmount_View> q_in = new List<AllAmount_View>();
            List<AllAmount_View> q_out = new List<AllAmount_View>();
            if (dr_selct_report.SelectedIndex == 0)
            {
                q = await C_All_Amount.ReportEndDaynocash(dr_user.SelectedValue.ToString(), dr_fara.SelectedValue.ToString(), dt_date_from.Value.Date.ToString("yyyy/MM/dd"), dt_date_to.Value.Date.ToString("yyyy/MM/dd"));
            }
            if (dr_selct_report.SelectedIndex == 1)
            {
                q = await C_All_Amount.ReportEndDay(dr_user.SelectedValue.ToString(), dr_fara.SelectedValue.ToString(), dt_date_from.Value.Date.ToString("yyyy/MM/dd"), dt_date_to.Value.Date.ToString("yyyy/MM/dd"));
            }
            if (dr_selct_report.SelectedIndex == 2)
            {
                q = await C_All_Amount.ReportEndDayDitals(dr_user.SelectedValue.ToString(), dr_fara.SelectedValue.ToString(), dt_date_from.Value.Date.ToString("yyyy/MM/dd"), dt_date_to.Value.Date.ToString("yyyy/MM/dd"));
            }
            gv_in.DataSource = q.Where(x => x.type_amount == 1).ToList();
            gv_out.DataSource = q.Where(x => x.type_amount == 2).ToList();
            datagrid1.DataSource = q.Where(x => x.type_amount == 0).ToList();
            gv_total_in.DataSource = q_in = await C_All_Amount.SumEndDay(dr_user.SelectedValue.ToString(), dr_fara.SelectedValue.ToString(), dt_date_from.Value.Date.ToString("yyyy/MM/dd"), dt_date_to.Value.Date.ToString("yyyy/MM/dd"), "1");
            gv_total_out.DataSource = q_out = await C_All_Amount.SumEndDay(dr_user.SelectedValue.ToString(), dr_fara.SelectedValue.ToString(), dt_date_from.Value.Date.ToString("yyyy/MM/dd"), dt_date_to.Value.Date.ToString("yyyy/MM/dd"), "2");

            amount_in = q_in.Where(x => x.id_cash == (int)Session.PayMethods.cach).Sum(x => x.amount);
            amount_out = q_out.Where(x => x.id_cash == (int)Session.PayMethods.cach).Sum(x => x.amount);

            lb_mas.Text = "صافي الاجمالي النقدي" + " " + amount_in.ToString() + " " + "-" + " " + amount_out.ToString() + " " + "=" + " " + (amount_in - amount_out).ToString("0.00");
            p_date_from = dt_date_from.Value.ToString();
            p_date_to = dt_date_to.Value.ToString();
            NewMethod();
            pic_login.Visible = false;
        }

        private void NewMethod()
        {

            bool user_fara = false, cash = false, count = false;
            if (dr_selct_report.SelectedIndex == 0)
            {
                user_fara = false;
                cash = false;
                count = true;
            }

            if (dr_selct_report.SelectedIndex == 1)
            {
                user_fara = false;
                cash = true;
                count = true;
            }
            if (dr_selct_report.SelectedIndex == 2)
            {
                user_fara = true;
                cash = true;
                count = false;
            }

            gv_in_name_fara.Visible =
            gv_out_name_fara.Visible =
            gv_0_name_fara.Visible =
            gv_in_user_name.Visible =
            gv_out_user_name.Visible =
            gv_0_user_name.Visible = user_fara;

            gv_in_cash_name.Visible =
            gv_out_cash_name.Visible =
            gv_0_cash_name.Visible = cash;

            gv_in_count.Visible =
            gv_out_count.Visible =
            gv_0_count.Visible = count;

            gv_in.CurrentCell = null;
            gv_out.CurrentCell = null;
            gv_total_in.CurrentCell = null;
            gv_total_out.CurrentCell = null;
            datagrid1.CurrentCell = null;
        }

        string p_date_from;
        string p_date_to;
        private void bt_search_Click(object sender, EventArgs e)
        {
            getdata();
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (gv_in.RowCount == 0)
                return;

            List<ReportParameter> para = new List<ReportParameter>();
            para.Add(new ReportParameter("p_date_from", p_date_from));
            para.Add(new ReportParameter("p_dt_date_to", p_date_to));
            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("InvoiceHeaderView", gv_in.DataSource),
            };
            frm_show_report _Report = new frm_show_report(para, "all_InvoiceHeader", ReportDataSource, true);
            _Report.Show();
        }
        private void dr_fara_SelectedIndexChanged(object sender, EventArgs e)
        {
            dr_user.IntializeData(Session.usersfara(Session.ConvertInt(dr_fara.SelectedValue.ToString())), nameof(user.user_name), nameof(user.id));

            dr_user.SelectedValue = Session.User_login.id;
            dr_user.Enabled = dr_fara.Enabled = !((Session.Accsess)Session.User_setting().AcssessStore == Session.Accsess.mowazf);

            if (dr_user.SelectedIndex == -1)
                dr_user.SelectedIndex = 0;

        }
    }
}
