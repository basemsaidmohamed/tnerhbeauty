﻿namespace tnerhbeauty
{
    partial class all_prodcut_get
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(all_prodcut_get));
            this.dt_date_from = new System.Windows.Forms.DateTimePicker();
            this.dt_date_to = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bt_search = new System.Windows.Forms.Button();
            this.lb_mas = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.bt_product = new System.Windows.Forms.Button();
            this.lp_titel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.bt_serch_client = new System.Windows.Forms.Button();
            this.btn_print = new System.Windows.Forms.Button();
            this.tx_name_cient = new System.Windows.Forms.Label();
            this.tx_prodct = new System.Windows.Forms.Label();
            this.dr_report = new System.Windows.Forms.ComboBox();
            this.dr_type = new System.Windows.Forms.ComboBox();
            this.dr_fara = new System.Windows.Forms.ComboBox();
            this.dr_user = new System.Windows.Forms.ComboBox();
            this.gv = new tnerhbeauty.Class.datagrid();
            this.tb = new System.Windows.Forms.TableLayoutPanel();
            this.lp_Net_ItemQty = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lp_ItemQty_in = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lp_ItemQty_out = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lp_Price_in = new System.Windows.Forms.Label();
            this.lp_Price_out = new System.Windows.Forms.Label();
            this.lp_Net_price = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gv)).BeginInit();
            this.tb.SuspendLayout();
            this.SuspendLayout();
            // 
            // dt_date_from
            // 
            this.dt_date_from.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.dt_date_from.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dt_date_from.Location = new System.Drawing.Point(492, 86);
            this.dt_date_from.Margin = new System.Windows.Forms.Padding(4);
            this.dt_date_from.Name = "dt_date_from";
            this.dt_date_from.RightToLeftLayout = true;
            this.dt_date_from.Size = new System.Drawing.Size(126, 26);
            this.dt_date_from.TabIndex = 2;
            // 
            // dt_date_to
            // 
            this.dt_date_to.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.dt_date_to.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dt_date_to.Location = new System.Drawing.Point(623, 86);
            this.dt_date_to.Margin = new System.Windows.Forms.Padding(4);
            this.dt_date_to.Name = "dt_date_to";
            this.dt_date_to.RightToLeftLayout = true;
            this.dt_date_to.Size = new System.Drawing.Size(125, 26);
            this.dt_date_to.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(623, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "الي تاريخ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(489, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 22);
            this.label2.TabIndex = 6;
            this.label2.Text = "من تاريخ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(11, 58);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 22);
            this.label3.TabIndex = 7;
            this.label3.Text = "اسم العميل";
            // 
            // bt_search
            // 
            this.bt_search.BackColor = System.Drawing.Color.Purple;
            this.bt_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_search.FlatAppearance.BorderSize = 0;
            this.bt_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_search.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.bt_search.ForeColor = System.Drawing.Color.White;
            this.bt_search.Location = new System.Drawing.Point(1359, 78);
            this.bt_search.Margin = new System.Windows.Forms.Padding(4);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(69, 36);
            this.bt_search.TabIndex = 55;
            this.bt_search.Text = "بحث";
            this.bt_search.UseVisualStyleBackColor = false;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // lb_mas
            // 
            this.lb_mas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lb_mas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_mas.Font = new System.Drawing.Font("Tahoma", 11.25F);
            this.lb_mas.ForeColor = System.Drawing.Color.White;
            this.lb_mas.Location = new System.Drawing.Point(0, 762);
            this.lb_mas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_mas.Name = "lb_mas";
            this.lb_mas.Size = new System.Drawing.Size(1657, 38);
            this.lb_mas.TabIndex = 64;
            this.lb_mas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(250, 58);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 22);
            this.label4.TabIndex = 69;
            this.label4.Text = "الصنف";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button2.BackgroundImage = global::tnerhbeauty.Properties.Resources.close;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(248, 81);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(28, 31);
            this.button2.TabIndex = 71;
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // bt_product
            // 
            this.bt_product.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bt_product.BackgroundImage = global::tnerhbeauty.Properties.Resources.cubes;
            this.bt_product.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_product.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_product.FlatAppearance.BorderSize = 0;
            this.bt_product.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.bt_product.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.bt_product.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_product.Location = new System.Drawing.Point(458, 81);
            this.bt_product.Margin = new System.Windows.Forms.Padding(0);
            this.bt_product.Name = "bt_product";
            this.bt_product.Size = new System.Drawing.Size(29, 31);
            this.bt_product.TabIndex = 70;
            this.bt_product.UseVisualStyleBackColor = false;
            this.bt_product.Click += new System.EventHandler(this.bt_product_Click);
            // 
            // lp_titel
            // 
            this.lp_titel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lp_titel.Dock = System.Windows.Forms.DockStyle.Top;
            this.lp_titel.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_titel.ForeColor = System.Drawing.Color.White;
            this.lp_titel.Image = global::tnerhbeauty.Properties.Resources.search_page;
            this.lp_titel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp_titel.Location = new System.Drawing.Point(0, 0);
            this.lp_titel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_titel.Name = "lp_titel";
            this.lp_titel.Size = new System.Drawing.Size(1657, 41);
            this.lp_titel.TabIndex = 66;
            this.lp_titel.Text = "تقرير حركات العملاء والاصناف";
            this.lp_titel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button1.BackgroundImage = global::tnerhbeauty.Properties.Resources.close;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(12, 81);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(28, 31);
            this.button1.TabIndex = 61;
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bt_serch_client
            // 
            this.bt_serch_client.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bt_serch_client.BackgroundImage = global::tnerhbeauty.Properties.Resources.find_users;
            this.bt_serch_client.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_serch_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_serch_client.FlatAppearance.BorderSize = 0;
            this.bt_serch_client.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.bt_serch_client.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.bt_serch_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_serch_client.Location = new System.Drawing.Point(214, 81);
            this.bt_serch_client.Margin = new System.Windows.Forms.Padding(0);
            this.bt_serch_client.Name = "bt_serch_client";
            this.bt_serch_client.Size = new System.Drawing.Size(29, 31);
            this.bt_serch_client.TabIndex = 60;
            this.bt_serch_client.UseVisualStyleBackColor = false;
            this.bt_serch_client.Click += new System.EventHandler(this.bt_serch_client_Click);
            // 
            // btn_print
            // 
            this.btn_print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_print.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_print.FlatAppearance.BorderSize = 0;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(1572, 78);
            this.btn_print.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(76, 34);
            this.btn_print.TabIndex = 80;
            this.btn_print.Text = "طباعة";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // tx_name_cient
            // 
            this.tx_name_cient.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tx_name_cient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tx_name_cient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tx_name_cient.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.tx_name_cient.Location = new System.Drawing.Point(37, 81);
            this.tx_name_cient.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tx_name_cient.Name = "tx_name_cient";
            this.tx_name_cient.Padding = new System.Windows.Forms.Padding(4);
            this.tx_name_cient.Size = new System.Drawing.Size(177, 31);
            this.tx_name_cient.TabIndex = 139;
            this.tx_name_cient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tx_name_cient.Click += new System.EventHandler(this.bt_serch_client_Click);
            // 
            // tx_prodct
            // 
            this.tx_prodct.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tx_prodct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tx_prodct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tx_prodct.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.tx_prodct.Location = new System.Drawing.Point(276, 81);
            this.tx_prodct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tx_prodct.Name = "tx_prodct";
            this.tx_prodct.Padding = new System.Windows.Forms.Padding(4);
            this.tx_prodct.Size = new System.Drawing.Size(183, 31);
            this.tx_prodct.TabIndex = 140;
            this.tx_prodct.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tx_prodct.Click += new System.EventHandler(this.bt_product_Click);
            // 
            // dr_report
            // 
            this.dr_report.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_report.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.dr_report.FormattingEnabled = true;
            this.dr_report.Items.AddRange(new object[] {
            "تقرير تفصيلي الكميات والأسعار ",
            "تقرير  اجمالي  الكميات والأسعار الصنف والعميل",
            "تقرير إجمالي الكميات والأسعار حسب الصنف",
            "تقرير إجمالي الكميات والأسعار حسب العميل"});
            this.dr_report.Location = new System.Drawing.Point(756, 85);
            this.dr_report.Margin = new System.Windows.Forms.Padding(4);
            this.dr_report.Name = "dr_report";
            this.dr_report.Size = new System.Drawing.Size(212, 27);
            this.dr_report.TabIndex = 143;
            // 
            // dr_type
            // 
            this.dr_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_type.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.dr_type.FormattingEnabled = true;
            this.dr_type.Items.AddRange(new object[] {
            "",
            "بيان اسعار",
            "مشتريات",
            "تحويل من مخزن الي مخزن",
            "بيان اسعار من المخزن للعميل",
            "مسودة",
            "تسوية اضافة رصيد",
            "تسوية خصم رصيد",
            "مرتجع الي المصنع",
            "مرتجع من العميل"});
            this.dr_type.Location = new System.Drawing.Point(971, 85);
            this.dr_type.Margin = new System.Windows.Forms.Padding(4);
            this.dr_type.Name = "dr_type";
            this.dr_type.Size = new System.Drawing.Size(120, 27);
            this.dr_type.TabIndex = 144;
            // 
            // dr_fara
            // 
            this.dr_fara.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_fara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_fara.FormattingEnabled = true;
            this.dr_fara.Location = new System.Drawing.Point(1099, 85);
            this.dr_fara.Margin = new System.Windows.Forms.Padding(4);
            this.dr_fara.Name = "dr_fara";
            this.dr_fara.Size = new System.Drawing.Size(116, 27);
            this.dr_fara.TabIndex = 145;
            this.dr_fara.SelectionChangeCommitted += new System.EventHandler(this.dr_fara_SelectionChangeCommitted);
            // 
            // dr_user
            // 
            this.dr_user.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_user.DropDownWidth = 100;
            this.dr_user.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_user.FormattingEnabled = true;
            this.dr_user.Location = new System.Drawing.Point(1223, 85);
            this.dr_user.Margin = new System.Windows.Forms.Padding(4);
            this.dr_user.Name = "dr_user";
            this.dr_user.Size = new System.Drawing.Size(128, 27);
            this.dr_user.TabIndex = 155;
            // 
            // gv
            // 
            this.gv.AllowUserToAddRows = false;
            this.gv.AllowUserToDeleteRows = false;
            this.gv.AllowUserToResizeColumns = false;
            this.gv.AllowUserToResizeRows = false;
            this.gv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gv.ColumnHeadersHeight = 30;
            this.gv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv.EnableHeadersVisualStyles = false;
            this.gv.GridColor = System.Drawing.Color.Black;
            this.gv.Location = new System.Drawing.Point(12, 124);
            this.gv.Margin = new System.Windows.Forms.Padding(0);
            this.gv.Name = "gv";
            this.gv.ReadOnly = true;
            this.gv.RowHeadersVisible = false;
            this.gv.RowHeadersWidth = 51;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.gv.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv.RowTemplate.Height = 30;
            this.gv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv.Size = new System.Drawing.Size(1636, 532);
            this.gv.TabIndex = 67;
            this.gv.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_kushf_with_marid_CellDoubleClick);
            // 
            // tb
            // 
            this.tb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tb.ColumnCount = 4;
            this.tb.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.629315F));
            this.tb.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.12356F));
            this.tb.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.12356F));
            this.tb.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.12356F));
            this.tb.Controls.Add(this.lp_Net_ItemQty, 3, 1);
            this.tb.Controls.Add(this.label13, 3, 0);
            this.tb.Controls.Add(this.lp_ItemQty_in, 1, 1);
            this.tb.Controls.Add(this.label12, 2, 0);
            this.tb.Controls.Add(this.lp_ItemQty_out, 2, 1);
            this.tb.Controls.Add(this.label11, 1, 0);
            this.tb.Controls.Add(this.lp_Price_in, 1, 2);
            this.tb.Controls.Add(this.lp_Price_out, 2, 2);
            this.tb.Controls.Add(this.lp_Net_price, 3, 2);
            this.tb.Controls.Add(this.label15, 0, 1);
            this.tb.Controls.Add(this.label14, 0, 2);
            this.tb.Location = new System.Drawing.Point(15, 660);
            this.tb.Margin = new System.Windows.Forms.Padding(4);
            this.tb.Name = "tb";
            this.tb.RowCount = 3;
            this.tb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tb.Size = new System.Drawing.Size(707, 98);
            this.tb.TabIndex = 156;
            // 
            // lp_Net_ItemQty
            // 
            this.lp_Net_ItemQty.AutoSize = true;
            this.lp_Net_ItemQty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_Net_ItemQty.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_Net_ItemQty.Location = new System.Drawing.Point(4, 32);
            this.lp_Net_ItemQty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_Net_ItemQty.Name = "lp_Net_ItemQty";
            this.lp_Net_ItemQty.Size = new System.Drawing.Size(207, 32);
            this.lp_Net_ItemQty.TabIndex = 159;
            this.lp_Net_ItemQty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(4, 0);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(207, 32);
            this.label13.TabIndex = 157;
            this.label13.Text = "الصافي";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_ItemQty_in
            // 
            this.lp_ItemQty_in.AutoSize = true;
            this.lp_ItemQty_in.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_ItemQty_in.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_ItemQty_in.Location = new System.Drawing.Point(431, 32);
            this.lp_ItemQty_in.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_ItemQty_in.Name = "lp_ItemQty_in";
            this.lp_ItemQty_in.Size = new System.Drawing.Size(204, 32);
            this.lp_ItemQty_in.TabIndex = 91;
            this.lp_ItemQty_in.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(219, 0);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(204, 32);
            this.label12.TabIndex = 87;
            this.label12.Text = "مبيعات";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_ItemQty_out
            // 
            this.lp_ItemQty_out.AutoSize = true;
            this.lp_ItemQty_out.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_ItemQty_out.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_ItemQty_out.Location = new System.Drawing.Point(219, 32);
            this.lp_ItemQty_out.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_ItemQty_out.Name = "lp_ItemQty_out";
            this.lp_ItemQty_out.Size = new System.Drawing.Size(204, 32);
            this.lp_ItemQty_out.TabIndex = 85;
            this.lp_ItemQty_out.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(431, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(204, 32);
            this.label11.TabIndex = 89;
            this.label11.Text = "مشتريات";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_Price_in
            // 
            this.lp_Price_in.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_Price_in.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_Price_in.Location = new System.Drawing.Point(431, 64);
            this.lp_Price_in.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_Price_in.Name = "lp_Price_in";
            this.lp_Price_in.Size = new System.Drawing.Size(204, 34);
            this.lp_Price_in.TabIndex = 158;
            this.lp_Price_in.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_Price_out
            // 
            this.lp_Price_out.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_Price_out.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_Price_out.Location = new System.Drawing.Point(219, 64);
            this.lp_Price_out.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_Price_out.Name = "lp_Price_out";
            this.lp_Price_out.Size = new System.Drawing.Size(204, 34);
            this.lp_Price_out.TabIndex = 86;
            this.lp_Price_out.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_Net_price
            // 
            this.lp_Net_price.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_Net_price.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_Net_price.Location = new System.Drawing.Point(4, 64);
            this.lp_Net_price.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_Net_price.Name = "lp_Net_price";
            this.lp_Net_price.Size = new System.Drawing.Size(207, 34);
            this.lp_Net_price.TabIndex = 89;
            this.lp_Net_price.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(643, 32);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 32);
            this.label15.TabIndex = 88;
            this.label15.Text = "الكميات";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(643, 64);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 34);
            this.label14.TabIndex = 158;
            this.label14.Text = "القيمة";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.BackColor = System.Drawing.Color.Purple;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = global::tnerhbeauty.Properties.Resources.excel;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(1432, 78);
            this.button3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(136, 36);
            this.button3.TabIndex = 158;
            this.button3.Text = "تصدير اكسيل";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // all_prodcut_get
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1657, 800);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tb);
            this.Controls.Add(this.dr_user);
            this.Controls.Add(this.dr_fara);
            this.Controls.Add(this.dr_type);
            this.Controls.Add(this.dr_report);
            this.Controls.Add(this.tx_prodct);
            this.Controls.Add(this.tx_name_cient);
            this.Controls.Add(this.btn_print);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.bt_product);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gv);
            this.Controls.Add(this.lp_titel);
            this.Controls.Add(this.lb_mas);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bt_serch_client);
            this.Controls.Add(this.bt_search);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dt_date_to);
            this.Controls.Add(this.dt_date_from);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "all_prodcut_get";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.all_kushufat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gv)).EndInit();
            this.tb.ResumeLayout(false);
            this.tb.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dt_date_from;
        private System.Windows.Forms.DateTimePicker dt_date_to;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_search;
        private System.Windows.Forms.Button bt_serch_client;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lb_mas;
        private System.Windows.Forms.Label lp_titel;
        private Class.datagrid gv;
       
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button bt_product;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.Label tx_name_cient;
        private System.Windows.Forms.Label tx_prodct;
        private System.Windows.Forms.ComboBox dr_report;
        private System.Windows.Forms.ComboBox dr_type;
        private System.Windows.Forms.ComboBox dr_fara;
        private System.Windows.Forms.ComboBox dr_user;
        private System.Windows.Forms.TableLayoutPanel tb;
        private System.Windows.Forms.Label lp_ItemQty_in;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lp_Net_price;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lp_ItemQty_out;
        private System.Windows.Forms.Label lp_Price_out;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lp_Price_in;
        private System.Windows.Forms.Label lp_Net_ItemQty;
        private System.Windows.Forms.Button button3;
    }
}