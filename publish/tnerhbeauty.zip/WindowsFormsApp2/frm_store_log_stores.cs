﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;

namespace tnerhbeauty
{
    public partial class frm_store_log_stores : Form
    {
        //DataClasses1DataContext db;
        public frm_store_log_stores()
        {
            InitializeComponent();
        }
        store_log_View _store_log_View;
        private void all_kushufat_Load(object sender, EventArgs e)
        {
            //db = new DataClasses1DataContext();

            dr_store.IntializeData(cproduct.StoreUser, nameof(store.store_name), nameof(store.id));
            getdata();
            gv.DataSource = new List<store_log_View>();
            gv.Columns[nameof(_store_log_View.id)].Visible = false;
            gv.Columns[nameof(_store_log_View.store_id)].Visible = false;
            gv.Columns[nameof(_store_log_View.ItemID)].Visible = false;
            gv.Columns[nameof(_store_log_View.id_type)].Visible = false;
            gv.Columns[nameof(_store_log_View.Source_Id)].Visible = false;
            gv.Columns[nameof(_store_log_View.user_name)].Visible = false;
            gv.Columns[nameof(_store_log_View.name_invoice_type)].Visible = false;
            gv.Columns[nameof(_store_log_View.ItemQty_in)].Visible = false;
            gv.Columns[nameof(_store_log_View.ItemQty_out)].Visible = false;
            gv.Columns[nameof(_store_log_View.DateAdd)].Visible = false;
            gv.Columns[nameof(_store_log_View.DateAdd)].Visible = false;
            gv.Columns[nameof(_store_log_View.nots)].Visible = false;

            gv.Columns[nameof(_store_log_View.code)].HeaderText = "كود الصنف";
            gv.Columns[nameof(_store_log_View.product_name)].HeaderText = "  اسم الصنف";

            gv.Columns[nameof(_store_log_View.Balance)].HeaderText = "الرصيد";

            gv.Columns[nameof(_store_log_View.store_name)].HeaderText = "المخزن";






        }


        string p_name_client = "";
        string p_prodct = "";
        string p_date_from;


        private void bt_search_Click(object sender, EventArgs e)
        {
            getdata();
        }
        public async void getdata()
        {
            pic_login.Visible = true;
            bt_search.Enabled = false;
            //List<store_log_View> n = await cproduct.GetBalnceInstores(ItemID.ToString(), dr_store.SelectedValue.ToString(), ch_zero.Checked, ch_store.Checked);
            gv.DataSource = await cproduct.GetBalnceInstores(ItemID.ToString(), dr_store.SelectedValue.ToString(), ch_zero.Checked, ch_store.Checked);            
            DataTable dt = (DataTable)gv.DataSource;
            lb_mas.Text = dt.AsEnumerable().Sum(x => x.Field<decimal>(nameof(_store_log_View.Balance))).ToString("0.000"); // إجمالي الكميات
            pic_login.Visible = false;
            bt_search.Enabled = true;
        }


        int ItemID = 0;
        private void bt_product_Click(object sender, EventArgs e)
        {
            selct_prodct _selct_prodct = new selct_prodct();
            _selct_prodct.ShowDialog();
            product_serch_View prod = _selct_prodct.retrnval();
            if (prod != null)
            {
                ItemID = prod.id;
                tx_prodct.Text = prod.fullname;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ItemID = 0;
            tx_prodct.Text = "";
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0)
                return;
            List<ReportParameter> para = new List<ReportParameter>();
            para.Add(new ReportParameter("p_date_from", p_date_from));
            para.Add(new ReportParameter("p_dt_date_to", p_date_from));
            para.Add(new ReportParameter("p_name_client", p_name_client));
            para.Add(new ReportParameter("p_prodct", p_prodct));
            para.Add(new ReportParameter("p_report_name", lp_titel.Text));
            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("store_log_View", gv.DataSource),
            };
            frm_show_report _Report = new frm_show_report(para, "frm_store_log_stores", ReportDataSource, true);
            _Report.Show();
        }

        private void btn_export_exal_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0) return;
            lb_mas.Text = "  جاري انشاء ملف الاكسيل ...";           
            gv.DataSource.ExportDataGridViewToExal(" ارصدة الاصناف في المخازن " + tx_prodct.Text+" "+dr_store.Text);
            lb_mas.Text = @"تم حفظ الملف  \" + Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer" + @"\" + DateTime.Now.Ticks + "Response.xlsx" + "";
        }
    }
}

























//List<store_log_Balance_View> Store_log_Balance_View = new List<store_log_Balance_View>();

//var qq = db.store_log_Balance_Views.GroupBy(x => x.ItemID).Select(cl => new store_log_Balance_View
//{

//    ItemID = cl.First().ItemID,
//    code = cl.First().code,
//    product_name = cl.First().product_name,
//    Balance_sabk = (decimal?)cl.Where(x => x.DateAdd.Date < dt_date_from.Value.Date).Sum(x => (decimal?)x.ItemQty_in - (decimal?)x.ItemQty_out) ?? 0,
//    ItemQty_in = (decimal?)cl.Where(x => (x.DateAdd.Date >= dt_date_from.Value.Date) && (x.DateAdd.Date <= dt_date_to.Value.Date)).Sum(x => x.ItemQty_in) ?? 0,
//    ItemQty_out = (decimal?)cl.Where(x => (x.DateAdd.Date >= dt_date_from.Value.Date) && (x.DateAdd.Date <= dt_date_to.Value.Date)).Sum(x => x.ItemQty_out) ?? 0,
//    Balance = (decimal?)cl.Where(x => x.DateAdd.Date < dt_date_to.Value).Sum(x => x.ItemQty_in - x.ItemQty_out) ?? 0,
//}).ToList();

//gv.DataSource = qq;