﻿namespace tnerhbeauty
{
    partial class add_setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label adressLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label telLabel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label label15;
            System.Windows.Forms.Label label16;
            System.Windows.Forms.Label label17;
            System.Windows.Forms.Label label18;
            System.Windows.Forms.Label label23;
            System.Windows.Forms.Label label24;
            System.Windows.Forms.Label label25;
            System.Windows.Forms.Label label34;
            System.Windows.Forms.Label label41;
            System.Windows.Forms.Label label42;
            System.Windows.Forms.Label label43;
            System.Windows.Forms.Label label26;
            System.Windows.Forms.Label label27;
            System.Windows.Forms.Label label28;
            System.Windows.Forms.Label label44;
            System.Windows.Forms.Label label45;
            System.Windows.Forms.Label label51;
            System.Windows.Forms.Label label52;
            System.Windows.Forms.Label label55;
            System.Windows.Forms.Label label56;
            System.Windows.Forms.Label label57;
            System.Windows.Forms.Label label46;
            System.Windows.Forms.Label label47;
            System.Windows.Forms.Label label48;
            System.Windows.Forms.Label label58;
            System.Windows.Forms.Label label59;
            System.Windows.Forms.Label label60;
            System.Windows.Forms.Label label61;
            System.Windows.Forms.Label label62;
            System.Windows.Forms.Label label63;
            System.Windows.Forms.Label label35;
            System.Windows.Forms.Label label29;
            System.Windows.Forms.Label label30;
            System.Windows.Forms.Label label31;
            System.Windows.Forms.Label label75;
            System.Windows.Forms.Label label53;
            System.Windows.Forms.Label label54;
            System.Windows.Forms.Label label67;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(add_setting));
            this.tx_name = new System.Windows.Forms.TextBox();
            this.lb_mas = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btn_new = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_delete_invoice_broken = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_broken = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_broken = new System.Windows.Forms.CheckBox();
            this.ch_show_invoice_broken = new System.Windows.Forms.CheckBox();
            this.label68 = new System.Windows.Forms.Label();
            this.ch_Extra_invoice_return_from_client = new System.Windows.Forms.CheckBox();
            this.ch_Extra_invoice_return_to_supplier = new System.Windows.Forms.CheckBox();
            this.ch_Extra_invoice_sale = new System.Windows.Forms.CheckBox();
            this.ch_Extra_invoice_pay = new System.Windows.Forms.CheckBox();
            this.ch_Discount_invoice_return_from_client = new System.Windows.Forms.CheckBox();
            this.ch_Discount_invoice_return_to_supplier = new System.Windows.Forms.CheckBox();
            this.ch_Discount_invoice_sale = new System.Windows.Forms.CheckBox();
            this.ch_Discount_invoice_pay = new System.Windows.Forms.CheckBox();
            this.ch_Discount_item_invoice_return_from_client = new System.Windows.Forms.CheckBox();
            this.ch_Discount_item_invoice_return_to_supplier = new System.Windows.Forms.CheckBox();
            this.ch_Discount_item_invoice_sale = new System.Windows.Forms.CheckBox();
            this.ch_Discount_item_invoice_pay = new System.Windows.Forms.CheckBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.ch_delete_invoice_to_store = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_to_store = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_to_store = new System.Windows.Forms.CheckBox();
            this.ch_show_invoice_to_store = new System.Windows.Forms.CheckBox();
            this.ch_delete_invoice_sale = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_sale = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_sale = new System.Windows.Forms.CheckBox();
            this.ch_show_invoice_sale = new System.Windows.Forms.CheckBox();
            this.ch_delete_invoice_pay = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_pay = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_pay = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ch_show_invoice_pay = new System.Windows.Forms.CheckBox();
            this.ch_show_invoice_pay_from_store = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_pay_from_store = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_pay_from_store = new System.Windows.Forms.CheckBox();
            this.ch_delete_invoice_pay_from_store = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_return_to_supplier = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_taswet_edafa = new System.Windows.Forms.CheckBox();
            this.ch_show_invoice_taswet_edafa = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_return_from_client = new System.Windows.Forms.CheckBox();
            this.ch_add_invoice_taswiat_khasm = new System.Windows.Forms.CheckBox();
            this.ch_show_invoice_return_to_supplier = new System.Windows.Forms.CheckBox();
            this.ch_show_invoice_return_from_client = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_return_to_supplier = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_taswiat_khasm = new System.Windows.Forms.CheckBox();
            this.ch_delete_invoice_return_to_supplier = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_return_from_client = new System.Windows.Forms.CheckBox();
            this.ch_update_invoice_taswet_edafa = new System.Windows.Forms.CheckBox();
            this.ch_delete_invoice_return_from_client = new System.Windows.Forms.CheckBox();
            this.ch_delete_invoice_taswet_edafa = new System.Windows.Forms.CheckBox();
            this.ch_show_invoice_taswiat_khasm = new System.Windows.Forms.CheckBox();
            this.ch_delete_invoice_taswiat_khasm = new System.Windows.Forms.CheckBox();
            this.ch_show_product = new System.Windows.Forms.CheckBox();
            this.ch_add_product = new System.Windows.Forms.CheckBox();
            this.ch_update_product = new System.Windows.Forms.CheckBox();
            this.ch_delete_product = new System.Windows.Forms.CheckBox();
            this.ch_update_price_producut = new System.Windows.Forms.CheckBox();
            this.ch_update_price_producut_exal = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_show_Price_mabeat_product = new System.Windows.Forms.CheckBox();
            this.ch_report_mabeat_product = new System.Windows.Forms.CheckBox();
            this.ch_store_in_and_out = new System.Windows.Forms.CheckBox();
            this.ch_blance_in_storses = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.ch_kashf_hesab_prodct = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_up_product_min_mum = new System.Windows.Forms.CheckBox();
            this.ch_kashf_hesab_client = new System.Windows.Forms.CheckBox();
            this.ch_delete_amount_client = new System.Windows.Forms.CheckBox();
            this.ch_update_amount_client = new System.Windows.Forms.CheckBox();
            this.ch_add_amount_client = new System.Windows.Forms.CheckBox();
            this.ch_show_amount_client = new System.Windows.Forms.CheckBox();
            this.ch_delete_client = new System.Windows.Forms.CheckBox();
            this.ch_update_client = new System.Windows.Forms.CheckBox();
            this.ch_add_client = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.ch_show_client = new System.Windows.Forms.CheckBox();
            this.ch_delete_fara = new System.Windows.Forms.CheckBox();
            this.ch_update_fara = new System.Windows.Forms.CheckBox();
            this.ch_add_fara = new System.Windows.Forms.CheckBox();
            this.ch_show_fara = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_delete_All_account = new System.Windows.Forms.CheckBox();
            this.ch_update_All_account = new System.Windows.Forms.CheckBox();
            this.ch_add_All_account = new System.Windows.Forms.CheckBox();
            this.ch_show_All_account = new System.Windows.Forms.CheckBox();
            this.ch_delete_type_cash = new System.Windows.Forms.CheckBox();
            this.ch_update_type_cash = new System.Windows.Forms.CheckBox();
            this.ch_add_type_cash = new System.Windows.Forms.CheckBox();
            this.ch_show_type_cash = new System.Windows.Forms.CheckBox();
            this.ch_delete_store = new System.Windows.Forms.CheckBox();
            this.ch_delete_setting = new System.Windows.Forms.CheckBox();
            this.ch_update_store = new System.Windows.Forms.CheckBox();
            this.ch_update_setting = new System.Windows.Forms.CheckBox();
            this.ch_add_setting = new System.Windows.Forms.CheckBox();
            this.ch_show_store = new System.Windows.Forms.CheckBox();
            this.ch_show_setting = new System.Windows.Forms.CheckBox();
            this.ch_delete_user = new System.Windows.Forms.CheckBox();
            this.ch_update_user = new System.Windows.Forms.CheckBox();
            this.ch_add_user = new System.Windows.Forms.CheckBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.ch_show_user = new System.Windows.Forms.CheckBox();
            this.ch_add_store = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_print = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ch_update_company = new System.Windows.Forms.CheckBox();
            this.ch_all = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_invoice_agel = new System.Windows.Forms.CheckBox();
            this.ch_invoice_chang_price = new System.Windows.Forms.CheckBox();
            this.ch_invoice_show_Balance_client = new System.Windows.Forms.CheckBox();
            this.ch_invoice_chang_list_price_client = new System.Windows.Forms.CheckBox();
            this.ch_invoice_date = new System.Windows.Forms.CheckBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.ch_invoice_print = new System.Windows.Forms.CheckBox();
            this.ch_invoice_print_anoter_user = new System.Windows.Forms.CheckBox();
            this.ch_invoice_print_befor_date = new System.Windows.Forms.CheckBox();
            this.ch_invoice_delete_anoter_user = new System.Windows.Forms.CheckBox();
            this.ch_invoice_update_anoter_user = new System.Windows.Forms.CheckBox();
            this.ch_invoice_update_befor_date = new System.Windows.Forms.CheckBox();
            this.ch_invoice_delete_befor_date = new System.Windows.Forms.CheckBox();
            this.label64 = new System.Windows.Forms.Label();
            this.dr_invoice_AutoUpdatePrice = new System.Windows.Forms.ComboBox();
            this.ch_report_all_amount = new System.Windows.Forms.CheckBox();
            this.dr_AcssessStore = new System.Windows.Forms.ComboBox();
            this.ch_show_UserAccessMachineName = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.ch_delete_amount = new System.Windows.Forms.CheckBox();
            this.ch_update_amount = new System.Windows.Forms.CheckBox();
            this.ch_add_amount = new System.Windows.Forms.CheckBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.ch_show_amount = new System.Windows.Forms.CheckBox();
            this.lp_titel = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.maridBindingSource = new System.Windows.Forms.BindingSource(this.components);
            adressLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            telLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            label23 = new System.Windows.Forms.Label();
            label24 = new System.Windows.Forms.Label();
            label25 = new System.Windows.Forms.Label();
            label34 = new System.Windows.Forms.Label();
            label41 = new System.Windows.Forms.Label();
            label42 = new System.Windows.Forms.Label();
            label43 = new System.Windows.Forms.Label();
            label26 = new System.Windows.Forms.Label();
            label27 = new System.Windows.Forms.Label();
            label28 = new System.Windows.Forms.Label();
            label44 = new System.Windows.Forms.Label();
            label45 = new System.Windows.Forms.Label();
            label51 = new System.Windows.Forms.Label();
            label52 = new System.Windows.Forms.Label();
            label55 = new System.Windows.Forms.Label();
            label56 = new System.Windows.Forms.Label();
            label57 = new System.Windows.Forms.Label();
            label46 = new System.Windows.Forms.Label();
            label47 = new System.Windows.Forms.Label();
            label48 = new System.Windows.Forms.Label();
            label58 = new System.Windows.Forms.Label();
            label59 = new System.Windows.Forms.Label();
            label60 = new System.Windows.Forms.Label();
            label61 = new System.Windows.Forms.Label();
            label62 = new System.Windows.Forms.Label();
            label63 = new System.Windows.Forms.Label();
            label35 = new System.Windows.Forms.Label();
            label29 = new System.Windows.Forms.Label();
            label30 = new System.Windows.Forms.Label();
            label31 = new System.Windows.Forms.Label();
            label75 = new System.Windows.Forms.Label();
            label53 = new System.Windows.Forms.Label();
            label54 = new System.Windows.Forms.Label();
            label67 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maridBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // adressLabel
            // 
            adressLabel.AutoSize = true;
            adressLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            adressLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            adressLabel.Location = new System.Drawing.Point(320, 122);
            adressLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            adressLabel.Name = "adressLabel";
            adressLabel.Size = new System.Drawing.Size(234, 27);
            adressLabel.TabIndex = 1;
            adressLabel.Text = "فاتورة بيان اسعار من المخزن";
            adressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            nameLabel.Location = new System.Drawing.Point(21, 56);
            nameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(89, 24);
            nameLabel.TabIndex = 17;
            nameLabel.Text = "اسم النموذج";
            // 
            // telLabel
            // 
            telLabel.AutoSize = true;
            telLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            telLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            telLabel.Location = new System.Drawing.Point(320, 38);
            telLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            telLabel.Name = "telLabel";
            telLabel.Size = new System.Drawing.Size(234, 27);
            telLabel.TabIndex = 23;
            telLabel.Text = "فاتورة بيان اسعار";
            telLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = System.Windows.Forms.DockStyle.Fill;
            label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.Location = new System.Drawing.Point(320, 94);
            label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(234, 27);
            label1.TabIndex = 81;
            label1.Text = "فاتورة تحويل من مخزن الي مخزن";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = System.Windows.Forms.DockStyle.Fill;
            label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.Location = new System.Drawing.Point(320, 66);
            label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(234, 27);
            label2.TabIndex = 82;
            label2.Text = "فاتورة المشتريات";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Dock = System.Windows.Forms.DockStyle.Fill;
            label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label8.Location = new System.Drawing.Point(55, 217);
            label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(237, 35);
            label8.TabIndex = 88;
            label8.Text = "زيادة وخفض اسعار الاصناف";
            label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Dock = System.Windows.Forms.DockStyle.Fill;
            label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label9.Location = new System.Drawing.Point(55, 253);
            label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(237, 41);
            label9.TabIndex = 89;
            label9.Text = "تحديث اسعار الاصناف اكسل";
            label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Dock = System.Windows.Forms.DockStyle.Fill;
            label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label15.Location = new System.Drawing.Point(55, 37);
            label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(237, 35);
            label15.TabIndex = 23;
            label15.Text = "كشف حساب صنف";
            label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Dock = System.Windows.Forms.DockStyle.Fill;
            label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label16.Location = new System.Drawing.Point(55, 73);
            label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(237, 35);
            label16.TabIndex = 82;
            label16.Text = "ارصده الاصناف و حد الطلب";
            label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Dock = System.Windows.Forms.DockStyle.Fill;
            label17.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label17.Location = new System.Drawing.Point(55, 109);
            label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(237, 35);
            label17.TabIndex = 81;
            label17.Text = "حركة الاصناف الواردة والصادرة";
            label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Dock = System.Windows.Forms.DockStyle.Fill;
            label18.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label18.Location = new System.Drawing.Point(55, 145);
            label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(237, 35);
            label18.TabIndex = 1;
            label18.Text = "تقرير حركات العملاء والاصناف";
            label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Dock = System.Windows.Forms.DockStyle.Fill;
            label23.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label23.Location = new System.Drawing.Point(191, 43);
            label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label23.Name = "label23";
            label23.Size = new System.Drawing.Size(204, 41);
            label23.TabIndex = 23;
            label23.Text = "العملاء";
            label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Dock = System.Windows.Forms.DockStyle.Fill;
            label24.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label24.Location = new System.Drawing.Point(191, 85);
            label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label24.Name = "label24";
            label24.Size = new System.Drawing.Size(204, 41);
            label24.TabIndex = 82;
            label24.Text = "دفعات العملاء";
            label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Dock = System.Windows.Forms.DockStyle.Fill;
            label25.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label25.Location = new System.Drawing.Point(191, 127);
            label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label25.Name = "label25";
            label25.Size = new System.Drawing.Size(204, 41);
            label25.TabIndex = 81;
            label25.Text = "كشف حساب عميل";
            label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Dock = System.Windows.Forms.DockStyle.Fill;
            label34.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label34.Location = new System.Drawing.Point(191, 67);
            label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label34.Name = "label34";
            label34.Size = new System.Drawing.Size(204, 21);
            label34.TabIndex = 23;
            label34.Text = "الفروع";
            label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Dock = System.Windows.Forms.DockStyle.Fill;
            label41.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label41.Location = new System.Drawing.Point(191, 23);
            label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label41.Name = "label41";
            label41.Size = new System.Drawing.Size(204, 21);
            label41.TabIndex = 23;
            label41.Text = "الموظفين";
            label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Dock = System.Windows.Forms.DockStyle.Fill;
            label42.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label42.Location = new System.Drawing.Point(191, 45);
            label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label42.Name = "label42";
            label42.Size = new System.Drawing.Size(204, 21);
            label42.TabIndex = 82;
            label42.Text = "صلاحيات الموظفين";
            label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label43
            // 
            label43.AutoSize = true;
            label43.Dock = System.Windows.Forms.DockStyle.Fill;
            label43.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label43.Location = new System.Drawing.Point(55, 22);
            label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label43.Name = "label43";
            label43.Size = new System.Drawing.Size(238, 21);
            label43.TabIndex = 23;
            label43.Text = "تعديل بيانات الشركة";
            label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Dock = System.Windows.Forms.DockStyle.Fill;
            label26.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label26.Location = new System.Drawing.Point(191, 253);
            label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label26.Name = "label26";
            label26.Size = new System.Drawing.Size(204, 41);
            label26.TabIndex = 106;
            label26.Text = "الاصناف";
            label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Dock = System.Windows.Forms.DockStyle.Fill;
            label27.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label27.Location = new System.Drawing.Point(320, 150);
            label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label27.Name = "label27";
            label27.Size = new System.Drawing.Size(234, 27);
            label27.TabIndex = 111;
            label27.Text = "فاتورة مرتجع الي المصنع";
            label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Dock = System.Windows.Forms.DockStyle.Fill;
            label28.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label28.Location = new System.Drawing.Point(320, 178);
            label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label28.Name = "label28";
            label28.Size = new System.Drawing.Size(234, 27);
            label28.TabIndex = 112;
            label28.Text = "فاتورة مرتجع من العميل";
            label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Dock = System.Windows.Forms.DockStyle.Fill;
            label44.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label44.Location = new System.Drawing.Point(320, 206);
            label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label44.Name = "label44";
            label44.Size = new System.Drawing.Size(234, 27);
            label44.TabIndex = 113;
            label44.Text = "فاتورة تسوية اضافة";
            label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Dock = System.Windows.Forms.DockStyle.Fill;
            label45.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label45.Location = new System.Drawing.Point(320, 234);
            label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label45.Name = "label45";
            label45.Size = new System.Drawing.Size(234, 27);
            label45.TabIndex = 114;
            label45.Text = "فاتورة تسوية خصم";
            label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.Dock = System.Windows.Forms.DockStyle.Fill;
            label51.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label51.Location = new System.Drawing.Point(51, 51);
            label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label51.Name = "label51";
            label51.Size = new System.Drawing.Size(504, 24);
            label51.TabIndex = 23;
            label51.Text = "السماح بتعديل تاريح الفاتورة";
            label51.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label52
            // 
            label52.AutoSize = true;
            label52.Dock = System.Windows.Forms.DockStyle.Fill;
            label52.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label52.Location = new System.Drawing.Point(51, 151);
            label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label52.Name = "label52";
            label52.Size = new System.Drawing.Size(504, 24);
            label52.TabIndex = 157;
            label52.Text = "عرض رصيد العميل";
            label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label55
            // 
            label55.AutoSize = true;
            label55.Dock = System.Windows.Forms.DockStyle.Fill;
            label55.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label55.Location = new System.Drawing.Point(51, 126);
            label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label55.Name = "label55";
            label55.Size = new System.Drawing.Size(504, 24);
            label55.TabIndex = 160;
            label55.Text = "السماح بتغير قائمة الاسعار المخصص للعميل";
            label55.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label56
            // 
            label56.AutoSize = true;
            label56.Dock = System.Windows.Forms.DockStyle.Fill;
            label56.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label56.Location = new System.Drawing.Point(51, 101);
            label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label56.Name = "label56";
            label56.Size = new System.Drawing.Size(504, 24);
            label56.TabIndex = 160;
            label56.Text = "السماح تغير سعر البيع ";
            label56.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label57
            // 
            label57.AutoSize = true;
            label57.Dock = System.Windows.Forms.DockStyle.Bottom;
            label57.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label57.Location = new System.Drawing.Point(51, 76);
            label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label57.Name = "label57";
            label57.Size = new System.Drawing.Size(504, 24);
            label57.TabIndex = 161;
            label57.Text = "السماح بطباعة الفاتورة ";
            label57.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Dock = System.Windows.Forms.DockStyle.Fill;
            label46.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label46.Location = new System.Drawing.Point(51, 26);
            label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label46.Name = "label46";
            label46.Size = new System.Drawing.Size(504, 24);
            label46.TabIndex = 157;
            label46.Text = "السماح بالبيع اجل";
            label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label47.Location = new System.Drawing.Point(1071, 63);
            label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label47.Name = "label47";
            label47.Size = new System.Drawing.Size(197, 24);
            label47.TabIndex = 157;
            label47.Text = "السماح بتعديل تاريح الفاتورة";
            label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            label47.Visible = false;
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Dock = System.Windows.Forms.DockStyle.Fill;
            label48.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label48.Location = new System.Drawing.Point(51, 25);
            label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label48.Name = "label48";
            label48.Size = new System.Drawing.Size(242, 23);
            label48.TabIndex = 158;
            label48.Text = "السماح بتعديل بيان بتاريخ سابق";
            label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label58
            // 
            label58.AutoSize = true;
            label58.Dock = System.Windows.Forms.DockStyle.Fill;
            label58.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label58.Location = new System.Drawing.Point(51, 73);
            label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label58.Name = "label58";
            label58.Size = new System.Drawing.Size(242, 23);
            label58.TabIndex = 158;
            label58.Text = "السماح بحذف بيان بتاريخ سابق";
            label58.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label59
            // 
            label59.AutoSize = true;
            label59.Dock = System.Windows.Forms.DockStyle.Fill;
            label59.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label59.Location = new System.Drawing.Point(51, 49);
            label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label59.Name = "label59";
            label59.Size = new System.Drawing.Size(242, 23);
            label59.TabIndex = 160;
            label59.Text = "السماح بتعديل بيان لموظف اخر";
            label59.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label60
            // 
            label60.AutoSize = true;
            label60.Dock = System.Windows.Forms.DockStyle.Fill;
            label60.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label60.Location = new System.Drawing.Point(51, 97);
            label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label60.Name = "label60";
            label60.Size = new System.Drawing.Size(242, 23);
            label60.TabIndex = 159;
            label60.Text = "السماح بحذف بيان موظف اخر";
            label60.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label61
            // 
            label61.AutoSize = true;
            label61.Dock = System.Windows.Forms.DockStyle.Fill;
            label61.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label61.Location = new System.Drawing.Point(51, 145);
            label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label61.Name = "label61";
            label61.Size = new System.Drawing.Size(242, 30);
            label61.TabIndex = 162;
            label61.Text = "السماح بطباعة بيان موظف اخر";
            label61.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label62
            // 
            label62.AutoSize = true;
            label62.Dock = System.Windows.Forms.DockStyle.Fill;
            label62.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label62.Location = new System.Drawing.Point(51, 121);
            label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label62.Name = "label62";
            label62.Size = new System.Drawing.Size(242, 23);
            label62.TabIndex = 161;
            label62.Text = "السماح بطباعة بيان بتاريخ سابق";
            label62.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label63
            // 
            label63.AutoSize = true;
            label63.Dock = System.Windows.Forms.DockStyle.Fill;
            label63.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label63.Location = new System.Drawing.Point(191, 21);
            label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label63.Name = "label63";
            label63.Size = new System.Drawing.Size(204, 20);
            label63.TabIndex = 23;
            label63.Text = "تقرير العمليات اليومية";
            label63.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Dock = System.Windows.Forms.DockStyle.Fill;
            label35.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label35.Location = new System.Drawing.Point(191, 89);
            label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label35.Name = "label35";
            label35.Size = new System.Drawing.Size(204, 21);
            label35.TabIndex = 82;
            label35.Text = "المخازن";
            label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Dock = System.Windows.Forms.DockStyle.Fill;
            label29.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label29.Location = new System.Drawing.Point(191, 111);
            label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label29.Name = "label29";
            label29.Size = new System.Drawing.Size(204, 21);
            label29.TabIndex = 163;
            label29.Text = "طرق دفع";
            label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Dock = System.Windows.Forms.DockStyle.Fill;
            label30.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label30.Location = new System.Drawing.Point(191, 133);
            label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label30.Name = "label30";
            label30.Size = new System.Drawing.Size(204, 21);
            label30.TabIndex = 163;
            label30.Text = "انشاء حساب";
            label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Dock = System.Windows.Forms.DockStyle.Fill;
            label31.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label31.Location = new System.Drawing.Point(191, 211);
            label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label31.Name = "label31";
            label31.Size = new System.Drawing.Size(204, 41);
            label31.TabIndex = 163;
            label31.Text = "تحديث حد الطلب من الاكسل";
            label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label75
            // 
            label75.AutoSize = true;
            label75.Dock = System.Windows.Forms.DockStyle.Fill;
            label75.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label75.Location = new System.Drawing.Point(191, 42);
            label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label75.Name = "label75";
            label75.Size = new System.Drawing.Size(204, 19);
            label75.TabIndex = 23;
            label75.Text = "ايرادات ومصروفات";
            label75.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label53
            // 
            label53.AutoSize = true;
            label53.Dock = System.Windows.Forms.DockStyle.Fill;
            label53.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label53.Location = new System.Drawing.Point(320, 262);
            label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label53.Name = "label53";
            label53.Size = new System.Drawing.Size(234, 32);
            label53.TabIndex = 165;
            label53.Text = "فاتورة هالك";
            label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.Dock = System.Windows.Forms.DockStyle.Fill;
            label54.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label54.Location = new System.Drawing.Point(55, 181);
            label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label54.Name = "label54";
            label54.Size = new System.Drawing.Size(237, 35);
            label54.TabIndex = 165;
            label54.Text = "عرض سعر الصنف تقرير حركات العملاء";
            label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tx_name
            // 
            this.tx_name.BackColor = System.Drawing.Color.White;
            this.tx_name.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.maridBindingSource, "name", true));
            this.tx_name.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_name.Location = new System.Drawing.Point(105, 52);
            this.tx_name.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tx_name.Name = "tx_name";
            this.tx_name.Size = new System.Drawing.Size(256, 27);
            this.tx_name.TabIndex = 0;
            // 
            // lb_mas
            // 
            this.lb_mas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lb_mas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_mas.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mas.ForeColor = System.Drawing.Color.White;
            this.lb_mas.Location = new System.Drawing.Point(0, 761);
            this.lb_mas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_mas.Name = "lb_mas";
            this.lb_mas.Size = new System.Drawing.Size(1358, 34);
            this.lb_mas.TabIndex = 37;
            this.lb_mas.Text = "F12 = SAVE ; F2  NEW  ;  DELETE = DELETE ; CTRL +P = PRINT";
            this.lb_mas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_save
            // 
            this.btn_save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_save.BackColor = System.Drawing.Color.Purple;
            this.btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(272, 3);
            this.btn_save.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(86, 29);
            this.btn_save.TabIndex = 12;
            this.btn_save.Text = "حفظ";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Visible = false;
            this.btn_save.Click += new System.EventHandler(this.bt_save_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider1.ContainerControl = this;
            // 
            // btn_new
            // 
            this.btn_new.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_new.BackColor = System.Drawing.Color.Green;
            this.btn_new.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_new.FlatAppearance.BorderSize = 0;
            this.btn_new.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_new.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_new.ForeColor = System.Drawing.Color.White;
            this.btn_new.Location = new System.Drawing.Point(182, 3);
            this.btn_new.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(86, 29);
            this.btn_new.TabIndex = 38;
            this.btn_new.Text = "جديد";
            this.btn_new.UseVisualStyleBackColor = false;
            this.btn_new.Visible = false;
            this.btn_new.Click += new System.EventHandler(this.bt_new_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_delete.BackColor = System.Drawing.Color.Crimson;
            this.btn_delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(92, 3);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(86, 29);
            this.btn_delete.TabIndex = 40;
            this.btn_delete.Text = "حذف";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Visible = false;
            this.btn_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_broken, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_broken, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_broken, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_broken, 1, 9);
            this.tableLayoutPanel1.Controls.Add(label53, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label68, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.ch_Extra_invoice_return_from_client, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_Extra_invoice_return_to_supplier, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_Extra_invoice_sale, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_Extra_invoice_pay, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.ch_Discount_invoice_return_from_client, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_Discount_invoice_return_to_supplier, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_Discount_invoice_sale, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_Discount_invoice_pay, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.ch_Discount_item_invoice_return_from_client, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_Discount_item_invoice_return_to_supplier, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_Discount_item_invoice_sale, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_Discount_item_invoice_pay, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.label66, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.label65, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_to_store, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_to_store, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_to_store, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_to_store, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_sale, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_sale, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_sale, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_sale, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_pay, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_pay, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_pay, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 4, 0);
            this.tableLayoutPanel1.Controls.Add(telLabel, 0, 1);
            this.tableLayoutPanel1.Controls.Add(label2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(label1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(adressLabel, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_pay, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_pay_from_store, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_pay_from_store, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_pay_from_store, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_pay_from_store, 4, 4);
            this.tableLayoutPanel1.Controls.Add(label27, 0, 5);
            this.tableLayoutPanel1.Controls.Add(label28, 0, 6);
            this.tableLayoutPanel1.Controls.Add(label44, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_return_to_supplier, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_taswet_edafa, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_taswet_edafa, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_return_from_client, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_add_invoice_taswiat_khasm, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_return_to_supplier, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_return_from_client, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_return_to_supplier, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_taswiat_khasm, 2, 8);
            this.tableLayoutPanel1.Controls.Add(label45, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_return_to_supplier, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_return_from_client, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_update_invoice_taswet_edafa, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_return_from_client, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_taswet_edafa, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.ch_show_invoice_taswiat_khasm, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.ch_delete_invoice_taswiat_khasm, 4, 8);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(10, 28);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.86643F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.681508F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(557, 295);
            this.tableLayoutPanel1.TabIndex = 83;
            // 
            // ch_delete_invoice_broken
            // 
            this.ch_delete_invoice_broken.AutoSize = true;
            this.ch_delete_invoice_broken.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_broken.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_broken.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_broken.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_broken.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_broken.Location = new System.Drawing.Point(133, 265);
            this.ch_delete_invoice_broken.Name = "ch_delete_invoice_broken";
            this.ch_delete_invoice_broken.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_broken.Size = new System.Drawing.Size(36, 26);
            this.ch_delete_invoice_broken.TabIndex = 165;
            this.ch_delete_invoice_broken.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_broken.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_broken.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_broken
            // 
            this.ch_update_invoice_broken.AutoSize = true;
            this.ch_update_invoice_broken.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_broken.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_broken.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_broken.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_broken.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_broken.Location = new System.Drawing.Point(176, 265);
            this.ch_update_invoice_broken.Name = "ch_update_invoice_broken";
            this.ch_update_invoice_broken.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_broken.Size = new System.Drawing.Size(37, 26);
            this.ch_update_invoice_broken.TabIndex = 165;
            this.ch_update_invoice_broken.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_broken.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_broken.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_broken
            // 
            this.ch_add_invoice_broken.AutoSize = true;
            this.ch_add_invoice_broken.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_broken.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_broken.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_broken.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_broken.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_broken.Location = new System.Drawing.Point(220, 265);
            this.ch_add_invoice_broken.Name = "ch_add_invoice_broken";
            this.ch_add_invoice_broken.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_broken.Size = new System.Drawing.Size(42, 26);
            this.ch_add_invoice_broken.TabIndex = 165;
            this.ch_add_invoice_broken.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_broken.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_broken.UseVisualStyleBackColor = true;
            // 
            // ch_show_invoice_broken
            // 
            this.ch_show_invoice_broken.AutoSize = true;
            this.ch_show_invoice_broken.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_broken.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_broken.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_broken.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_broken.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_broken.Location = new System.Drawing.Point(269, 265);
            this.ch_show_invoice_broken.Name = "ch_show_invoice_broken";
            this.ch_show_invoice_broken.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_invoice_broken.Size = new System.Drawing.Size(45, 26);
            this.ch_show_invoice_broken.TabIndex = 165;
            this.ch_show_invoice_broken.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_broken.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_invoice_broken.UseVisualStyleBackColor = true;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.Color.Black;
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.White;
            this.label68.Location = new System.Drawing.Point(1, 1);
            this.label68.Margin = new System.Windows.Forms.Padding(0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(42, 36);
            this.label68.TabIndex = 159;
            this.label68.Text = "اضافة مبلغ";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_Extra_invoice_return_from_client
            // 
            this.ch_Extra_invoice_return_from_client.AutoSize = true;
            this.ch_Extra_invoice_return_from_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Extra_invoice_return_from_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Extra_invoice_return_from_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Extra_invoice_return_from_client.FlatAppearance.BorderSize = 0;
            this.ch_Extra_invoice_return_from_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Extra_invoice_return_from_client.Location = new System.Drawing.Point(4, 181);
            this.ch_Extra_invoice_return_from_client.Name = "ch_Extra_invoice_return_from_client";
            this.ch_Extra_invoice_return_from_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Extra_invoice_return_from_client.Size = new System.Drawing.Size(36, 21);
            this.ch_Extra_invoice_return_from_client.TabIndex = 159;
            this.ch_Extra_invoice_return_from_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Extra_invoice_return_from_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Extra_invoice_return_from_client.UseVisualStyleBackColor = true;
            // 
            // ch_Extra_invoice_return_to_supplier
            // 
            this.ch_Extra_invoice_return_to_supplier.AutoSize = true;
            this.ch_Extra_invoice_return_to_supplier.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Extra_invoice_return_to_supplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Extra_invoice_return_to_supplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Extra_invoice_return_to_supplier.FlatAppearance.BorderSize = 0;
            this.ch_Extra_invoice_return_to_supplier.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Extra_invoice_return_to_supplier.Location = new System.Drawing.Point(4, 153);
            this.ch_Extra_invoice_return_to_supplier.Name = "ch_Extra_invoice_return_to_supplier";
            this.ch_Extra_invoice_return_to_supplier.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Extra_invoice_return_to_supplier.Size = new System.Drawing.Size(36, 21);
            this.ch_Extra_invoice_return_to_supplier.TabIndex = 159;
            this.ch_Extra_invoice_return_to_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Extra_invoice_return_to_supplier.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Extra_invoice_return_to_supplier.UseVisualStyleBackColor = true;
            // 
            // ch_Extra_invoice_sale
            // 
            this.ch_Extra_invoice_sale.AutoSize = true;
            this.ch_Extra_invoice_sale.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Extra_invoice_sale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Extra_invoice_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Extra_invoice_sale.FlatAppearance.BorderSize = 0;
            this.ch_Extra_invoice_sale.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Extra_invoice_sale.Location = new System.Drawing.Point(4, 69);
            this.ch_Extra_invoice_sale.Name = "ch_Extra_invoice_sale";
            this.ch_Extra_invoice_sale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Extra_invoice_sale.Size = new System.Drawing.Size(36, 21);
            this.ch_Extra_invoice_sale.TabIndex = 159;
            this.ch_Extra_invoice_sale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Extra_invoice_sale.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Extra_invoice_sale.UseVisualStyleBackColor = true;
            // 
            // ch_Extra_invoice_pay
            // 
            this.ch_Extra_invoice_pay.AutoSize = true;
            this.ch_Extra_invoice_pay.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Extra_invoice_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Extra_invoice_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Extra_invoice_pay.FlatAppearance.BorderSize = 0;
            this.ch_Extra_invoice_pay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Extra_invoice_pay.Location = new System.Drawing.Point(4, 41);
            this.ch_Extra_invoice_pay.Name = "ch_Extra_invoice_pay";
            this.ch_Extra_invoice_pay.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Extra_invoice_pay.Size = new System.Drawing.Size(36, 21);
            this.ch_Extra_invoice_pay.TabIndex = 159;
            this.ch_Extra_invoice_pay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Extra_invoice_pay.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Extra_invoice_pay.UseVisualStyleBackColor = true;
            // 
            // ch_Discount_invoice_return_from_client
            // 
            this.ch_Discount_invoice_return_from_client.AutoSize = true;
            this.ch_Discount_invoice_return_from_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_invoice_return_from_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Discount_invoice_return_from_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Discount_invoice_return_from_client.FlatAppearance.BorderSize = 0;
            this.ch_Discount_invoice_return_from_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Discount_invoice_return_from_client.Location = new System.Drawing.Point(47, 181);
            this.ch_Discount_invoice_return_from_client.Name = "ch_Discount_invoice_return_from_client";
            this.ch_Discount_invoice_return_from_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Discount_invoice_return_from_client.Size = new System.Drawing.Size(36, 21);
            this.ch_Discount_invoice_return_from_client.TabIndex = 159;
            this.ch_Discount_invoice_return_from_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_invoice_return_from_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Discount_invoice_return_from_client.UseVisualStyleBackColor = true;
            // 
            // ch_Discount_invoice_return_to_supplier
            // 
            this.ch_Discount_invoice_return_to_supplier.AutoSize = true;
            this.ch_Discount_invoice_return_to_supplier.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_invoice_return_to_supplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Discount_invoice_return_to_supplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Discount_invoice_return_to_supplier.FlatAppearance.BorderSize = 0;
            this.ch_Discount_invoice_return_to_supplier.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Discount_invoice_return_to_supplier.Location = new System.Drawing.Point(47, 153);
            this.ch_Discount_invoice_return_to_supplier.Name = "ch_Discount_invoice_return_to_supplier";
            this.ch_Discount_invoice_return_to_supplier.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Discount_invoice_return_to_supplier.Size = new System.Drawing.Size(36, 21);
            this.ch_Discount_invoice_return_to_supplier.TabIndex = 159;
            this.ch_Discount_invoice_return_to_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_invoice_return_to_supplier.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Discount_invoice_return_to_supplier.UseVisualStyleBackColor = true;
            // 
            // ch_Discount_invoice_sale
            // 
            this.ch_Discount_invoice_sale.AutoSize = true;
            this.ch_Discount_invoice_sale.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_invoice_sale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Discount_invoice_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Discount_invoice_sale.FlatAppearance.BorderSize = 0;
            this.ch_Discount_invoice_sale.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Discount_invoice_sale.Location = new System.Drawing.Point(47, 69);
            this.ch_Discount_invoice_sale.Name = "ch_Discount_invoice_sale";
            this.ch_Discount_invoice_sale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Discount_invoice_sale.Size = new System.Drawing.Size(36, 21);
            this.ch_Discount_invoice_sale.TabIndex = 159;
            this.ch_Discount_invoice_sale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_invoice_sale.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Discount_invoice_sale.UseVisualStyleBackColor = true;
            // 
            // ch_Discount_invoice_pay
            // 
            this.ch_Discount_invoice_pay.AutoSize = true;
            this.ch_Discount_invoice_pay.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_invoice_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Discount_invoice_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Discount_invoice_pay.FlatAppearance.BorderSize = 0;
            this.ch_Discount_invoice_pay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Discount_invoice_pay.Location = new System.Drawing.Point(47, 41);
            this.ch_Discount_invoice_pay.Name = "ch_Discount_invoice_pay";
            this.ch_Discount_invoice_pay.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Discount_invoice_pay.Size = new System.Drawing.Size(36, 21);
            this.ch_Discount_invoice_pay.TabIndex = 159;
            this.ch_Discount_invoice_pay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_invoice_pay.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Discount_invoice_pay.UseVisualStyleBackColor = true;
            // 
            // ch_Discount_item_invoice_return_from_client
            // 
            this.ch_Discount_item_invoice_return_from_client.AutoSize = true;
            this.ch_Discount_item_invoice_return_from_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_item_invoice_return_from_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Discount_item_invoice_return_from_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Discount_item_invoice_return_from_client.FlatAppearance.BorderSize = 0;
            this.ch_Discount_item_invoice_return_from_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Discount_item_invoice_return_from_client.Location = new System.Drawing.Point(90, 181);
            this.ch_Discount_item_invoice_return_from_client.Name = "ch_Discount_item_invoice_return_from_client";
            this.ch_Discount_item_invoice_return_from_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Discount_item_invoice_return_from_client.Size = new System.Drawing.Size(36, 21);
            this.ch_Discount_item_invoice_return_from_client.TabIndex = 159;
            this.ch_Discount_item_invoice_return_from_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_item_invoice_return_from_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Discount_item_invoice_return_from_client.UseVisualStyleBackColor = true;
            // 
            // ch_Discount_item_invoice_return_to_supplier
            // 
            this.ch_Discount_item_invoice_return_to_supplier.AutoSize = true;
            this.ch_Discount_item_invoice_return_to_supplier.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_item_invoice_return_to_supplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Discount_item_invoice_return_to_supplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Discount_item_invoice_return_to_supplier.FlatAppearance.BorderSize = 0;
            this.ch_Discount_item_invoice_return_to_supplier.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Discount_item_invoice_return_to_supplier.Location = new System.Drawing.Point(90, 153);
            this.ch_Discount_item_invoice_return_to_supplier.Name = "ch_Discount_item_invoice_return_to_supplier";
            this.ch_Discount_item_invoice_return_to_supplier.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Discount_item_invoice_return_to_supplier.Size = new System.Drawing.Size(36, 21);
            this.ch_Discount_item_invoice_return_to_supplier.TabIndex = 159;
            this.ch_Discount_item_invoice_return_to_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_item_invoice_return_to_supplier.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Discount_item_invoice_return_to_supplier.UseVisualStyleBackColor = true;
            // 
            // ch_Discount_item_invoice_sale
            // 
            this.ch_Discount_item_invoice_sale.AutoSize = true;
            this.ch_Discount_item_invoice_sale.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_item_invoice_sale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Discount_item_invoice_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Discount_item_invoice_sale.FlatAppearance.BorderSize = 0;
            this.ch_Discount_item_invoice_sale.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Discount_item_invoice_sale.Location = new System.Drawing.Point(90, 69);
            this.ch_Discount_item_invoice_sale.Name = "ch_Discount_item_invoice_sale";
            this.ch_Discount_item_invoice_sale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Discount_item_invoice_sale.Size = new System.Drawing.Size(36, 21);
            this.ch_Discount_item_invoice_sale.TabIndex = 159;
            this.ch_Discount_item_invoice_sale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_item_invoice_sale.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Discount_item_invoice_sale.UseVisualStyleBackColor = true;
            // 
            // ch_Discount_item_invoice_pay
            // 
            this.ch_Discount_item_invoice_pay.AutoSize = true;
            this.ch_Discount_item_invoice_pay.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_item_invoice_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_Discount_item_invoice_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_Discount_item_invoice_pay.FlatAppearance.BorderSize = 0;
            this.ch_Discount_item_invoice_pay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_Discount_item_invoice_pay.Location = new System.Drawing.Point(90, 41);
            this.ch_Discount_item_invoice_pay.Name = "ch_Discount_item_invoice_pay";
            this.ch_Discount_item_invoice_pay.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_Discount_item_invoice_pay.Size = new System.Drawing.Size(36, 21);
            this.ch_Discount_item_invoice_pay.TabIndex = 159;
            this.ch_Discount_item_invoice_pay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_Discount_item_invoice_pay.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_Discount_item_invoice_pay.UseVisualStyleBackColor = true;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.Black;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.White;
            this.label66.Location = new System.Drawing.Point(44, 1);
            this.label66.Margin = new System.Windows.Forms.Padding(0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(42, 36);
            this.label66.TabIndex = 159;
            this.label66.Text = "خصم فاتورة";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.Color.Black;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label65.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.White;
            this.label65.Location = new System.Drawing.Point(87, 1);
            this.label65.Margin = new System.Windows.Forms.Padding(0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(42, 36);
            this.label65.TabIndex = 159;
            this.label65.Text = "خصم صنف";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_delete_invoice_to_store
            // 
            this.ch_delete_invoice_to_store.AutoSize = true;
            this.ch_delete_invoice_to_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_to_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_to_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_to_store.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_to_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_to_store.Location = new System.Drawing.Point(133, 97);
            this.ch_delete_invoice_to_store.Name = "ch_delete_invoice_to_store";
            this.ch_delete_invoice_to_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_to_store.Size = new System.Drawing.Size(36, 21);
            this.ch_delete_invoice_to_store.TabIndex = 101;
            this.ch_delete_invoice_to_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_to_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_to_store.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_to_store
            // 
            this.ch_update_invoice_to_store.AutoSize = true;
            this.ch_update_invoice_to_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_to_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_to_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_to_store.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_to_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_to_store.Location = new System.Drawing.Point(176, 97);
            this.ch_update_invoice_to_store.Name = "ch_update_invoice_to_store";
            this.ch_update_invoice_to_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_to_store.Size = new System.Drawing.Size(37, 21);
            this.ch_update_invoice_to_store.TabIndex = 100;
            this.ch_update_invoice_to_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_to_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_to_store.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_to_store
            // 
            this.ch_add_invoice_to_store.AutoSize = true;
            this.ch_add_invoice_to_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_to_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_to_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_to_store.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_to_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_to_store.Location = new System.Drawing.Point(220, 97);
            this.ch_add_invoice_to_store.Name = "ch_add_invoice_to_store";
            this.ch_add_invoice_to_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_to_store.Size = new System.Drawing.Size(42, 21);
            this.ch_add_invoice_to_store.TabIndex = 99;
            this.ch_add_invoice_to_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_to_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_to_store.UseVisualStyleBackColor = true;
            // 
            // ch_show_invoice_to_store
            // 
            this.ch_show_invoice_to_store.AutoSize = true;
            this.ch_show_invoice_to_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_to_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_to_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_to_store.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_to_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_to_store.Location = new System.Drawing.Point(269, 97);
            this.ch_show_invoice_to_store.Name = "ch_show_invoice_to_store";
            this.ch_show_invoice_to_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_invoice_to_store.Size = new System.Drawing.Size(45, 21);
            this.ch_show_invoice_to_store.TabIndex = 98;
            this.ch_show_invoice_to_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_to_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_invoice_to_store.UseVisualStyleBackColor = true;
            // 
            // ch_delete_invoice_sale
            // 
            this.ch_delete_invoice_sale.AutoSize = true;
            this.ch_delete_invoice_sale.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_sale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_sale.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_sale.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_sale.Location = new System.Drawing.Point(133, 69);
            this.ch_delete_invoice_sale.Name = "ch_delete_invoice_sale";
            this.ch_delete_invoice_sale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_sale.Size = new System.Drawing.Size(36, 21);
            this.ch_delete_invoice_sale.TabIndex = 97;
            this.ch_delete_invoice_sale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_sale.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_sale.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_sale
            // 
            this.ch_update_invoice_sale.AutoSize = true;
            this.ch_update_invoice_sale.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_sale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_sale.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_sale.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_sale.Location = new System.Drawing.Point(176, 69);
            this.ch_update_invoice_sale.Name = "ch_update_invoice_sale";
            this.ch_update_invoice_sale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_sale.Size = new System.Drawing.Size(37, 21);
            this.ch_update_invoice_sale.TabIndex = 96;
            this.ch_update_invoice_sale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_sale.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_sale.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_sale
            // 
            this.ch_add_invoice_sale.AutoSize = true;
            this.ch_add_invoice_sale.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_sale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_sale.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_sale.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_sale.Location = new System.Drawing.Point(220, 69);
            this.ch_add_invoice_sale.Name = "ch_add_invoice_sale";
            this.ch_add_invoice_sale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_sale.Size = new System.Drawing.Size(42, 21);
            this.ch_add_invoice_sale.TabIndex = 95;
            this.ch_add_invoice_sale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_sale.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_sale.UseVisualStyleBackColor = true;
            // 
            // ch_show_invoice_sale
            // 
            this.ch_show_invoice_sale.AutoSize = true;
            this.ch_show_invoice_sale.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_sale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_sale.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_sale.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_sale.Location = new System.Drawing.Point(269, 69);
            this.ch_show_invoice_sale.Name = "ch_show_invoice_sale";
            this.ch_show_invoice_sale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_invoice_sale.Size = new System.Drawing.Size(45, 21);
            this.ch_show_invoice_sale.TabIndex = 94;
            this.ch_show_invoice_sale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_sale.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_invoice_sale.UseVisualStyleBackColor = true;
            // 
            // ch_delete_invoice_pay
            // 
            this.ch_delete_invoice_pay.AutoSize = true;
            this.ch_delete_invoice_pay.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_pay.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_pay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_pay.Location = new System.Drawing.Point(133, 41);
            this.ch_delete_invoice_pay.Name = "ch_delete_invoice_pay";
            this.ch_delete_invoice_pay.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_pay.Size = new System.Drawing.Size(36, 21);
            this.ch_delete_invoice_pay.TabIndex = 93;
            this.ch_delete_invoice_pay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_pay.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_pay.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_pay
            // 
            this.ch_update_invoice_pay.AutoSize = true;
            this.ch_update_invoice_pay.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_pay.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_pay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_pay.Location = new System.Drawing.Point(176, 41);
            this.ch_update_invoice_pay.Name = "ch_update_invoice_pay";
            this.ch_update_invoice_pay.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_pay.Size = new System.Drawing.Size(37, 21);
            this.ch_update_invoice_pay.TabIndex = 92;
            this.ch_update_invoice_pay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_pay.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_pay.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_pay
            // 
            this.ch_add_invoice_pay.AutoSize = true;
            this.ch_add_invoice_pay.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_pay.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_pay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_pay.Location = new System.Drawing.Point(220, 41);
            this.ch_add_invoice_pay.Name = "ch_add_invoice_pay";
            this.ch_add_invoice_pay.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_pay.Size = new System.Drawing.Size(42, 21);
            this.ch_add_invoice_pay.TabIndex = 91;
            this.ch_add_invoice_pay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_pay.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_pay.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(318, 1);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(238, 36);
            this.label3.TabIndex = 83;
            this.label3.Text = "الصلاحية";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(266, 1);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 36);
            this.label4.TabIndex = 84;
            this.label4.Text = "عرض";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Black;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(217, 1);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 36);
            this.label5.TabIndex = 85;
            this.label5.Text = "اضافة";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Black;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(173, 1);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 36);
            this.label7.TabIndex = 87;
            this.label7.Text = "تعديل";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(130, 1);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 36);
            this.label6.TabIndex = 86;
            this.label6.Text = "حذف";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_show_invoice_pay
            // 
            this.ch_show_invoice_pay.AutoSize = true;
            this.ch_show_invoice_pay.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_pay.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_pay.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_pay.Location = new System.Drawing.Point(267, 38);
            this.ch_show_invoice_pay.Margin = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.ch_show_invoice_pay.Name = "ch_show_invoice_pay";
            this.ch_show_invoice_pay.Size = new System.Drawing.Size(50, 27);
            this.ch_show_invoice_pay.TabIndex = 90;
            this.ch_show_invoice_pay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_pay.UseVisualStyleBackColor = false;
            // 
            // ch_show_invoice_pay_from_store
            // 
            this.ch_show_invoice_pay_from_store.AutoSize = true;
            this.ch_show_invoice_pay_from_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_pay_from_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_pay_from_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_pay_from_store.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_pay_from_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_pay_from_store.Location = new System.Drawing.Point(269, 125);
            this.ch_show_invoice_pay_from_store.Name = "ch_show_invoice_pay_from_store";
            this.ch_show_invoice_pay_from_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_invoice_pay_from_store.Size = new System.Drawing.Size(45, 21);
            this.ch_show_invoice_pay_from_store.TabIndex = 107;
            this.ch_show_invoice_pay_from_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_pay_from_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_invoice_pay_from_store.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_pay_from_store
            // 
            this.ch_add_invoice_pay_from_store.AutoSize = true;
            this.ch_add_invoice_pay_from_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_pay_from_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_pay_from_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_pay_from_store.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_pay_from_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_pay_from_store.Location = new System.Drawing.Point(220, 125);
            this.ch_add_invoice_pay_from_store.Name = "ch_add_invoice_pay_from_store";
            this.ch_add_invoice_pay_from_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_pay_from_store.Size = new System.Drawing.Size(42, 21);
            this.ch_add_invoice_pay_from_store.TabIndex = 108;
            this.ch_add_invoice_pay_from_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_pay_from_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_pay_from_store.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_pay_from_store
            // 
            this.ch_update_invoice_pay_from_store.AutoSize = true;
            this.ch_update_invoice_pay_from_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_pay_from_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_pay_from_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_pay_from_store.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_pay_from_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_pay_from_store.Location = new System.Drawing.Point(176, 125);
            this.ch_update_invoice_pay_from_store.Name = "ch_update_invoice_pay_from_store";
            this.ch_update_invoice_pay_from_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_pay_from_store.Size = new System.Drawing.Size(37, 21);
            this.ch_update_invoice_pay_from_store.TabIndex = 109;
            this.ch_update_invoice_pay_from_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_pay_from_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_pay_from_store.UseVisualStyleBackColor = true;
            // 
            // ch_delete_invoice_pay_from_store
            // 
            this.ch_delete_invoice_pay_from_store.AutoSize = true;
            this.ch_delete_invoice_pay_from_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_pay_from_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_pay_from_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_pay_from_store.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_pay_from_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_pay_from_store.Location = new System.Drawing.Point(133, 125);
            this.ch_delete_invoice_pay_from_store.Name = "ch_delete_invoice_pay_from_store";
            this.ch_delete_invoice_pay_from_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_pay_from_store.Size = new System.Drawing.Size(36, 21);
            this.ch_delete_invoice_pay_from_store.TabIndex = 110;
            this.ch_delete_invoice_pay_from_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_pay_from_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_pay_from_store.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_return_to_supplier
            // 
            this.ch_add_invoice_return_to_supplier.AutoSize = true;
            this.ch_add_invoice_return_to_supplier.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_return_to_supplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_return_to_supplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_return_to_supplier.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_return_to_supplier.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_return_to_supplier.Location = new System.Drawing.Point(220, 153);
            this.ch_add_invoice_return_to_supplier.Name = "ch_add_invoice_return_to_supplier";
            this.ch_add_invoice_return_to_supplier.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_return_to_supplier.Size = new System.Drawing.Size(42, 21);
            this.ch_add_invoice_return_to_supplier.TabIndex = 117;
            this.ch_add_invoice_return_to_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_return_to_supplier.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_return_to_supplier.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_taswet_edafa
            // 
            this.ch_add_invoice_taswet_edafa.AutoSize = true;
            this.ch_add_invoice_taswet_edafa.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_taswet_edafa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_taswet_edafa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_taswet_edafa.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_taswet_edafa.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_taswet_edafa.Location = new System.Drawing.Point(220, 209);
            this.ch_add_invoice_taswet_edafa.Name = "ch_add_invoice_taswet_edafa";
            this.ch_add_invoice_taswet_edafa.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_taswet_edafa.Size = new System.Drawing.Size(42, 21);
            this.ch_add_invoice_taswet_edafa.TabIndex = 121;
            this.ch_add_invoice_taswet_edafa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_taswet_edafa.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_taswet_edafa.UseVisualStyleBackColor = true;
            // 
            // ch_show_invoice_taswet_edafa
            // 
            this.ch_show_invoice_taswet_edafa.AutoSize = true;
            this.ch_show_invoice_taswet_edafa.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_taswet_edafa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_taswet_edafa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_taswet_edafa.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_taswet_edafa.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_taswet_edafa.Location = new System.Drawing.Point(269, 209);
            this.ch_show_invoice_taswet_edafa.Name = "ch_show_invoice_taswet_edafa";
            this.ch_show_invoice_taswet_edafa.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_invoice_taswet_edafa.Size = new System.Drawing.Size(45, 21);
            this.ch_show_invoice_taswet_edafa.TabIndex = 118;
            this.ch_show_invoice_taswet_edafa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_taswet_edafa.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_invoice_taswet_edafa.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_return_from_client
            // 
            this.ch_add_invoice_return_from_client.AutoSize = true;
            this.ch_add_invoice_return_from_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_return_from_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_return_from_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_return_from_client.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_return_from_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_return_from_client.Location = new System.Drawing.Point(220, 181);
            this.ch_add_invoice_return_from_client.Name = "ch_add_invoice_return_from_client";
            this.ch_add_invoice_return_from_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_return_from_client.Size = new System.Drawing.Size(42, 21);
            this.ch_add_invoice_return_from_client.TabIndex = 119;
            this.ch_add_invoice_return_from_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_return_from_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_return_from_client.UseVisualStyleBackColor = true;
            // 
            // ch_add_invoice_taswiat_khasm
            // 
            this.ch_add_invoice_taswiat_khasm.AutoSize = true;
            this.ch_add_invoice_taswiat_khasm.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_taswiat_khasm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_invoice_taswiat_khasm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_invoice_taswiat_khasm.FlatAppearance.BorderSize = 0;
            this.ch_add_invoice_taswiat_khasm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_invoice_taswiat_khasm.Location = new System.Drawing.Point(220, 237);
            this.ch_add_invoice_taswiat_khasm.Name = "ch_add_invoice_taswiat_khasm";
            this.ch_add_invoice_taswiat_khasm.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_invoice_taswiat_khasm.Size = new System.Drawing.Size(42, 21);
            this.ch_add_invoice_taswiat_khasm.TabIndex = 120;
            this.ch_add_invoice_taswiat_khasm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_invoice_taswiat_khasm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_invoice_taswiat_khasm.UseVisualStyleBackColor = true;
            // 
            // ch_show_invoice_return_to_supplier
            // 
            this.ch_show_invoice_return_to_supplier.AutoSize = true;
            this.ch_show_invoice_return_to_supplier.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_return_to_supplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_return_to_supplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_return_to_supplier.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_return_to_supplier.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_return_to_supplier.Location = new System.Drawing.Point(269, 153);
            this.ch_show_invoice_return_to_supplier.Name = "ch_show_invoice_return_to_supplier";
            this.ch_show_invoice_return_to_supplier.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_invoice_return_to_supplier.Size = new System.Drawing.Size(45, 21);
            this.ch_show_invoice_return_to_supplier.TabIndex = 122;
            this.ch_show_invoice_return_to_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_return_to_supplier.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_invoice_return_to_supplier.UseVisualStyleBackColor = true;
            // 
            // ch_show_invoice_return_from_client
            // 
            this.ch_show_invoice_return_from_client.AutoSize = true;
            this.ch_show_invoice_return_from_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_return_from_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_return_from_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_return_from_client.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_return_from_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_return_from_client.Location = new System.Drawing.Point(269, 181);
            this.ch_show_invoice_return_from_client.Name = "ch_show_invoice_return_from_client";
            this.ch_show_invoice_return_from_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_invoice_return_from_client.Size = new System.Drawing.Size(45, 21);
            this.ch_show_invoice_return_from_client.TabIndex = 124;
            this.ch_show_invoice_return_from_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_return_from_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_invoice_return_from_client.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_return_to_supplier
            // 
            this.ch_update_invoice_return_to_supplier.AutoSize = true;
            this.ch_update_invoice_return_to_supplier.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_return_to_supplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_return_to_supplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_return_to_supplier.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_return_to_supplier.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_return_to_supplier.Location = new System.Drawing.Point(176, 153);
            this.ch_update_invoice_return_to_supplier.Name = "ch_update_invoice_return_to_supplier";
            this.ch_update_invoice_return_to_supplier.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_return_to_supplier.Size = new System.Drawing.Size(37, 21);
            this.ch_update_invoice_return_to_supplier.TabIndex = 123;
            this.ch_update_invoice_return_to_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_return_to_supplier.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_return_to_supplier.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_taswiat_khasm
            // 
            this.ch_update_invoice_taswiat_khasm.AutoSize = true;
            this.ch_update_invoice_taswiat_khasm.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_taswiat_khasm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_taswiat_khasm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_taswiat_khasm.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_taswiat_khasm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_taswiat_khasm.Location = new System.Drawing.Point(176, 237);
            this.ch_update_invoice_taswiat_khasm.Name = "ch_update_invoice_taswiat_khasm";
            this.ch_update_invoice_taswiat_khasm.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_taswiat_khasm.Size = new System.Drawing.Size(37, 21);
            this.ch_update_invoice_taswiat_khasm.TabIndex = 116;
            this.ch_update_invoice_taswiat_khasm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_taswiat_khasm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_taswiat_khasm.UseVisualStyleBackColor = true;
            // 
            // ch_delete_invoice_return_to_supplier
            // 
            this.ch_delete_invoice_return_to_supplier.AutoSize = true;
            this.ch_delete_invoice_return_to_supplier.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_return_to_supplier.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_return_to_supplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_return_to_supplier.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_return_to_supplier.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_return_to_supplier.Location = new System.Drawing.Point(133, 153);
            this.ch_delete_invoice_return_to_supplier.Name = "ch_delete_invoice_return_to_supplier";
            this.ch_delete_invoice_return_to_supplier.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_return_to_supplier.Size = new System.Drawing.Size(36, 21);
            this.ch_delete_invoice_return_to_supplier.TabIndex = 125;
            this.ch_delete_invoice_return_to_supplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_return_to_supplier.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_return_to_supplier.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_return_from_client
            // 
            this.ch_update_invoice_return_from_client.AutoSize = true;
            this.ch_update_invoice_return_from_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_return_from_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_return_from_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_return_from_client.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_return_from_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_return_from_client.Location = new System.Drawing.Point(176, 181);
            this.ch_update_invoice_return_from_client.Name = "ch_update_invoice_return_from_client";
            this.ch_update_invoice_return_from_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_return_from_client.Size = new System.Drawing.Size(37, 21);
            this.ch_update_invoice_return_from_client.TabIndex = 115;
            this.ch_update_invoice_return_from_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_return_from_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_return_from_client.UseVisualStyleBackColor = true;
            // 
            // ch_update_invoice_taswet_edafa
            // 
            this.ch_update_invoice_taswet_edafa.AutoSize = true;
            this.ch_update_invoice_taswet_edafa.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_taswet_edafa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_invoice_taswet_edafa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_invoice_taswet_edafa.FlatAppearance.BorderSize = 0;
            this.ch_update_invoice_taswet_edafa.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_invoice_taswet_edafa.Location = new System.Drawing.Point(176, 209);
            this.ch_update_invoice_taswet_edafa.Name = "ch_update_invoice_taswet_edafa";
            this.ch_update_invoice_taswet_edafa.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_invoice_taswet_edafa.Size = new System.Drawing.Size(37, 21);
            this.ch_update_invoice_taswet_edafa.TabIndex = 127;
            this.ch_update_invoice_taswet_edafa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_invoice_taswet_edafa.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_invoice_taswet_edafa.UseVisualStyleBackColor = true;
            // 
            // ch_delete_invoice_return_from_client
            // 
            this.ch_delete_invoice_return_from_client.AutoSize = true;
            this.ch_delete_invoice_return_from_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_return_from_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_return_from_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_return_from_client.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_return_from_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_return_from_client.Location = new System.Drawing.Point(133, 181);
            this.ch_delete_invoice_return_from_client.Name = "ch_delete_invoice_return_from_client";
            this.ch_delete_invoice_return_from_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_return_from_client.Size = new System.Drawing.Size(36, 21);
            this.ch_delete_invoice_return_from_client.TabIndex = 132;
            this.ch_delete_invoice_return_from_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_return_from_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_return_from_client.UseVisualStyleBackColor = true;
            // 
            // ch_delete_invoice_taswet_edafa
            // 
            this.ch_delete_invoice_taswet_edafa.AutoSize = true;
            this.ch_delete_invoice_taswet_edafa.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_taswet_edafa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_taswet_edafa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_taswet_edafa.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_taswet_edafa.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_taswet_edafa.Location = new System.Drawing.Point(133, 209);
            this.ch_delete_invoice_taswet_edafa.Name = "ch_delete_invoice_taswet_edafa";
            this.ch_delete_invoice_taswet_edafa.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_taswet_edafa.Size = new System.Drawing.Size(36, 21);
            this.ch_delete_invoice_taswet_edafa.TabIndex = 130;
            this.ch_delete_invoice_taswet_edafa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_taswet_edafa.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_taswet_edafa.UseVisualStyleBackColor = true;
            // 
            // ch_show_invoice_taswiat_khasm
            // 
            this.ch_show_invoice_taswiat_khasm.AutoSize = true;
            this.ch_show_invoice_taswiat_khasm.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_taswiat_khasm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_invoice_taswiat_khasm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_invoice_taswiat_khasm.FlatAppearance.BorderSize = 0;
            this.ch_show_invoice_taswiat_khasm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_invoice_taswiat_khasm.Location = new System.Drawing.Point(269, 237);
            this.ch_show_invoice_taswiat_khasm.Name = "ch_show_invoice_taswiat_khasm";
            this.ch_show_invoice_taswiat_khasm.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_invoice_taswiat_khasm.Size = new System.Drawing.Size(45, 21);
            this.ch_show_invoice_taswiat_khasm.TabIndex = 131;
            this.ch_show_invoice_taswiat_khasm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_invoice_taswiat_khasm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_invoice_taswiat_khasm.UseVisualStyleBackColor = true;
            // 
            // ch_delete_invoice_taswiat_khasm
            // 
            this.ch_delete_invoice_taswiat_khasm.AutoSize = true;
            this.ch_delete_invoice_taswiat_khasm.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_taswiat_khasm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_invoice_taswiat_khasm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_invoice_taswiat_khasm.FlatAppearance.BorderSize = 0;
            this.ch_delete_invoice_taswiat_khasm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_invoice_taswiat_khasm.Location = new System.Drawing.Point(133, 237);
            this.ch_delete_invoice_taswiat_khasm.Name = "ch_delete_invoice_taswiat_khasm";
            this.ch_delete_invoice_taswiat_khasm.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_invoice_taswiat_khasm.Size = new System.Drawing.Size(36, 21);
            this.ch_delete_invoice_taswiat_khasm.TabIndex = 126;
            this.ch_delete_invoice_taswiat_khasm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_invoice_taswiat_khasm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_invoice_taswiat_khasm.UseVisualStyleBackColor = true;
            // 
            // ch_show_product
            // 
            this.ch_show_product.AutoSize = true;
            this.ch_show_product.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_product.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_product.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_product.FlatAppearance.BorderSize = 0;
            this.ch_show_product.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_product.Location = new System.Drawing.Point(140, 256);
            this.ch_show_product.Name = "ch_show_product";
            this.ch_show_product.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_product.Size = new System.Drawing.Size(45, 35);
            this.ch_show_product.TabIndex = 102;
            this.ch_show_product.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_product.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_product.UseVisualStyleBackColor = true;
            // 
            // ch_add_product
            // 
            this.ch_add_product.AutoSize = true;
            this.ch_add_product.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_product.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_product.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_product.FlatAppearance.BorderSize = 0;
            this.ch_add_product.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_product.Location = new System.Drawing.Point(91, 256);
            this.ch_add_product.Name = "ch_add_product";
            this.ch_add_product.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_product.Size = new System.Drawing.Size(42, 35);
            this.ch_add_product.TabIndex = 103;
            this.ch_add_product.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_product.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_product.UseVisualStyleBackColor = true;
            // 
            // ch_update_product
            // 
            this.ch_update_product.AutoSize = true;
            this.ch_update_product.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_product.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_product.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_product.FlatAppearance.BorderSize = 0;
            this.ch_update_product.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_product.Location = new System.Drawing.Point(47, 256);
            this.ch_update_product.Name = "ch_update_product";
            this.ch_update_product.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_product.Size = new System.Drawing.Size(37, 35);
            this.ch_update_product.TabIndex = 104;
            this.ch_update_product.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_product.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_product.UseVisualStyleBackColor = true;
            // 
            // ch_delete_product
            // 
            this.ch_delete_product.AutoSize = true;
            this.ch_delete_product.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_product.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_product.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_product.FlatAppearance.BorderSize = 0;
            this.ch_delete_product.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_product.Location = new System.Drawing.Point(4, 256);
            this.ch_delete_product.Name = "ch_delete_product";
            this.ch_delete_product.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_product.Size = new System.Drawing.Size(36, 35);
            this.ch_delete_product.TabIndex = 105;
            this.ch_delete_product.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_product.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_product.UseVisualStyleBackColor = true;
            // 
            // ch_update_price_producut
            // 
            this.ch_update_price_producut.AutoSize = true;
            this.ch_update_price_producut.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_price_producut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_price_producut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_price_producut.FlatAppearance.BorderSize = 0;
            this.ch_update_price_producut.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_price_producut.Location = new System.Drawing.Point(4, 220);
            this.ch_update_price_producut.Name = "ch_update_price_producut";
            this.ch_update_price_producut.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_price_producut.Size = new System.Drawing.Size(45, 29);
            this.ch_update_price_producut.TabIndex = 108;
            this.ch_update_price_producut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_price_producut.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_price_producut.UseVisualStyleBackColor = true;
            // 
            // ch_update_price_producut_exal
            // 
            this.ch_update_price_producut_exal.AutoSize = true;
            this.ch_update_price_producut_exal.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_price_producut_exal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_price_producut_exal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_price_producut_exal.FlatAppearance.BorderSize = 0;
            this.ch_update_price_producut_exal.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_price_producut_exal.Location = new System.Drawing.Point(4, 256);
            this.ch_update_price_producut_exal.Name = "ch_update_price_producut_exal";
            this.ch_update_price_producut_exal.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_price_producut_exal.Size = new System.Drawing.Size(45, 35);
            this.ch_update_price_producut_exal.TabIndex = 112;
            this.ch_update_price_producut_exal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_price_producut_exal.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_price_producut_exal.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(15, 87);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10, 5, 10, 10);
            this.groupBox1.Size = new System.Drawing.Size(577, 333);
            this.groupBox1.TabIndex = 85;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "الفواتير والاصناف";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel2);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Location = new System.Drawing.Point(608, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(10, 5, 10, 10);
            this.groupBox2.Size = new System.Drawing.Size(315, 333);
            this.groupBox2.TabIndex = 86;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "تقرير حركة  الاصناف";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.ch_show_Price_mabeat_product, 1, 5);
            this.tableLayoutPanel2.Controls.Add(label54, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.ch_report_mabeat_product, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.ch_store_in_and_out, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.ch_blance_in_storses, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label11, 1, 0);
            this.tableLayoutPanel2.Controls.Add(label15, 0, 1);
            this.tableLayoutPanel2.Controls.Add(label16, 0, 2);
            this.tableLayoutPanel2.Controls.Add(label17, 0, 3);
            this.tableLayoutPanel2.Controls.Add(label18, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.ch_kashf_hesab_prodct, 1, 1);
            this.tableLayoutPanel2.Controls.Add(label8, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.ch_update_price_producut, 1, 6);
            this.tableLayoutPanel2.Controls.Add(label9, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.ch_update_price_producut_exal, 1, 7);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(10, 28);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 8;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(295, 295);
            this.tableLayoutPanel2.TabIndex = 83;
            // 
            // ch_show_Price_mabeat_product
            // 
            this.ch_show_Price_mabeat_product.AutoSize = true;
            this.ch_show_Price_mabeat_product.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_Price_mabeat_product.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_Price_mabeat_product.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_Price_mabeat_product.FlatAppearance.BorderSize = 0;
            this.ch_show_Price_mabeat_product.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_Price_mabeat_product.Location = new System.Drawing.Point(4, 184);
            this.ch_show_Price_mabeat_product.Name = "ch_show_Price_mabeat_product";
            this.ch_show_Price_mabeat_product.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_Price_mabeat_product.Size = new System.Drawing.Size(45, 29);
            this.ch_show_Price_mabeat_product.TabIndex = 165;
            this.ch_show_Price_mabeat_product.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_Price_mabeat_product.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_Price_mabeat_product.UseVisualStyleBackColor = true;
            // 
            // ch_report_mabeat_product
            // 
            this.ch_report_mabeat_product.AutoSize = true;
            this.ch_report_mabeat_product.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_report_mabeat_product.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_report_mabeat_product.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_report_mabeat_product.FlatAppearance.BorderSize = 0;
            this.ch_report_mabeat_product.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_report_mabeat_product.Location = new System.Drawing.Point(4, 148);
            this.ch_report_mabeat_product.Name = "ch_report_mabeat_product";
            this.ch_report_mabeat_product.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_report_mabeat_product.Size = new System.Drawing.Size(45, 29);
            this.ch_report_mabeat_product.TabIndex = 102;
            this.ch_report_mabeat_product.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_report_mabeat_product.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_report_mabeat_product.UseVisualStyleBackColor = true;
            // 
            // ch_store_in_and_out
            // 
            this.ch_store_in_and_out.AutoSize = true;
            this.ch_store_in_and_out.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_store_in_and_out.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_store_in_and_out.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_store_in_and_out.FlatAppearance.BorderSize = 0;
            this.ch_store_in_and_out.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_store_in_and_out.Location = new System.Drawing.Point(4, 112);
            this.ch_store_in_and_out.Name = "ch_store_in_and_out";
            this.ch_store_in_and_out.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_store_in_and_out.Size = new System.Drawing.Size(45, 29);
            this.ch_store_in_and_out.TabIndex = 98;
            this.ch_store_in_and_out.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_store_in_and_out.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_store_in_and_out.UseVisualStyleBackColor = true;
            // 
            // ch_blance_in_storses
            // 
            this.ch_blance_in_storses.AutoSize = true;
            this.ch_blance_in_storses.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_blance_in_storses.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_blance_in_storses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_blance_in_storses.FlatAppearance.BorderSize = 0;
            this.ch_blance_in_storses.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_blance_in_storses.Location = new System.Drawing.Point(4, 76);
            this.ch_blance_in_storses.Name = "ch_blance_in_storses";
            this.ch_blance_in_storses.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_blance_in_storses.Size = new System.Drawing.Size(45, 29);
            this.ch_blance_in_storses.TabIndex = 94;
            this.ch_blance_in_storses.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_blance_in_storses.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_blance_in_storses.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Black;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(53, 1);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(241, 35);
            this.label10.TabIndex = 83;
            this.label10.Text = "الصلاحية";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(1, 1);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 35);
            this.label11.TabIndex = 84;
            this.label11.Text = "عرض";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_kashf_hesab_prodct
            // 
            this.ch_kashf_hesab_prodct.AutoSize = true;
            this.ch_kashf_hesab_prodct.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_kashf_hesab_prodct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_kashf_hesab_prodct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_kashf_hesab_prodct.FlatAppearance.BorderSize = 0;
            this.ch_kashf_hesab_prodct.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_kashf_hesab_prodct.Location = new System.Drawing.Point(4, 40);
            this.ch_kashf_hesab_prodct.Name = "ch_kashf_hesab_prodct";
            this.ch_kashf_hesab_prodct.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_kashf_hesab_prodct.Size = new System.Drawing.Size(45, 29);
            this.ch_kashf_hesab_prodct.TabIndex = 90;
            this.ch_kashf_hesab_prodct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_kashf_hesab_prodct.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_kashf_hesab_prodct.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel3);
            this.groupBox3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Red;
            this.groupBox3.Location = new System.Drawing.Point(929, 87);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(10, 5, 10, 10);
            this.groupBox3.Size = new System.Drawing.Size(418, 333);
            this.groupBox3.TabIndex = 87;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "العملاء";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSize = true;
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.ch_up_product_min_mum, 3, 5);
            this.tableLayoutPanel3.Controls.Add(label31, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.ch_kashf_hesab_client, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.ch_delete_amount_client, 4, 2);
            this.tableLayoutPanel3.Controls.Add(this.ch_update_amount_client, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.ch_add_amount_client, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.ch_show_amount_client, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.ch_delete_client, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.ch_update_client, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.ch_add_client, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label13, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label14, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label21, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.label22, 4, 0);
            this.tableLayoutPanel3.Controls.Add(label23, 0, 1);
            this.tableLayoutPanel3.Controls.Add(label24, 0, 2);
            this.tableLayoutPanel3.Controls.Add(label25, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.ch_show_client, 1, 1);
            this.tableLayoutPanel3.Controls.Add(label26, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.ch_show_product, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.ch_add_product, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.ch_update_product, 3, 6);
            this.tableLayoutPanel3.Controls.Add(this.ch_delete_product, 4, 6);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(10, 28);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 7;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(398, 295);
            this.tableLayoutPanel3.TabIndex = 83;
            // 
            // ch_up_product_min_mum
            // 
            this.ch_up_product_min_mum.AutoSize = true;
            this.ch_up_product_min_mum.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_up_product_min_mum.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_up_product_min_mum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_up_product_min_mum.FlatAppearance.BorderSize = 0;
            this.ch_up_product_min_mum.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_up_product_min_mum.Location = new System.Drawing.Point(47, 214);
            this.ch_up_product_min_mum.Name = "ch_up_product_min_mum";
            this.ch_up_product_min_mum.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_up_product_min_mum.Size = new System.Drawing.Size(37, 35);
            this.ch_up_product_min_mum.TabIndex = 163;
            this.ch_up_product_min_mum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_up_product_min_mum.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_up_product_min_mum.UseVisualStyleBackColor = true;
            // 
            // ch_kashf_hesab_client
            // 
            this.ch_kashf_hesab_client.AutoSize = true;
            this.ch_kashf_hesab_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_kashf_hesab_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_kashf_hesab_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_kashf_hesab_client.FlatAppearance.BorderSize = 0;
            this.ch_kashf_hesab_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_kashf_hesab_client.Location = new System.Drawing.Point(140, 130);
            this.ch_kashf_hesab_client.Name = "ch_kashf_hesab_client";
            this.ch_kashf_hesab_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_kashf_hesab_client.Size = new System.Drawing.Size(45, 35);
            this.ch_kashf_hesab_client.TabIndex = 98;
            this.ch_kashf_hesab_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_kashf_hesab_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_kashf_hesab_client.UseVisualStyleBackColor = true;
            // 
            // ch_delete_amount_client
            // 
            this.ch_delete_amount_client.AutoSize = true;
            this.ch_delete_amount_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_amount_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_amount_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_amount_client.FlatAppearance.BorderSize = 0;
            this.ch_delete_amount_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_amount_client.Location = new System.Drawing.Point(4, 88);
            this.ch_delete_amount_client.Name = "ch_delete_amount_client";
            this.ch_delete_amount_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_amount_client.Size = new System.Drawing.Size(36, 35);
            this.ch_delete_amount_client.TabIndex = 97;
            this.ch_delete_amount_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_amount_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_amount_client.UseVisualStyleBackColor = true;
            // 
            // ch_update_amount_client
            // 
            this.ch_update_amount_client.AutoSize = true;
            this.ch_update_amount_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_amount_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_amount_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_amount_client.FlatAppearance.BorderSize = 0;
            this.ch_update_amount_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_amount_client.Location = new System.Drawing.Point(47, 88);
            this.ch_update_amount_client.Name = "ch_update_amount_client";
            this.ch_update_amount_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_amount_client.Size = new System.Drawing.Size(37, 35);
            this.ch_update_amount_client.TabIndex = 96;
            this.ch_update_amount_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_amount_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_amount_client.UseVisualStyleBackColor = true;
            // 
            // ch_add_amount_client
            // 
            this.ch_add_amount_client.AutoSize = true;
            this.ch_add_amount_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_amount_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_amount_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_amount_client.FlatAppearance.BorderSize = 0;
            this.ch_add_amount_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_amount_client.Location = new System.Drawing.Point(91, 88);
            this.ch_add_amount_client.Name = "ch_add_amount_client";
            this.ch_add_amount_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_amount_client.Size = new System.Drawing.Size(42, 35);
            this.ch_add_amount_client.TabIndex = 95;
            this.ch_add_amount_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_amount_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_amount_client.UseVisualStyleBackColor = true;
            // 
            // ch_show_amount_client
            // 
            this.ch_show_amount_client.AutoSize = true;
            this.ch_show_amount_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_amount_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_amount_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_amount_client.FlatAppearance.BorderSize = 0;
            this.ch_show_amount_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_amount_client.Location = new System.Drawing.Point(140, 88);
            this.ch_show_amount_client.Name = "ch_show_amount_client";
            this.ch_show_amount_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_amount_client.Size = new System.Drawing.Size(45, 35);
            this.ch_show_amount_client.TabIndex = 94;
            this.ch_show_amount_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_amount_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_amount_client.UseVisualStyleBackColor = true;
            // 
            // ch_delete_client
            // 
            this.ch_delete_client.AutoSize = true;
            this.ch_delete_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_client.FlatAppearance.BorderSize = 0;
            this.ch_delete_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_client.Location = new System.Drawing.Point(4, 46);
            this.ch_delete_client.Name = "ch_delete_client";
            this.ch_delete_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_client.Size = new System.Drawing.Size(36, 35);
            this.ch_delete_client.TabIndex = 93;
            this.ch_delete_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_client.UseVisualStyleBackColor = true;
            // 
            // ch_update_client
            // 
            this.ch_update_client.AutoSize = true;
            this.ch_update_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_client.FlatAppearance.BorderSize = 0;
            this.ch_update_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_client.Location = new System.Drawing.Point(47, 46);
            this.ch_update_client.Name = "ch_update_client";
            this.ch_update_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_client.Size = new System.Drawing.Size(37, 35);
            this.ch_update_client.TabIndex = 92;
            this.ch_update_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_client.UseVisualStyleBackColor = true;
            // 
            // ch_add_client
            // 
            this.ch_add_client.AutoSize = true;
            this.ch_add_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_client.FlatAppearance.BorderSize = 0;
            this.ch_add_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_client.Location = new System.Drawing.Point(91, 46);
            this.ch_add_client.Name = "ch_add_client";
            this.ch_add_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_client.Size = new System.Drawing.Size(42, 35);
            this.ch_add_client.TabIndex = 91;
            this.ch_add_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_client.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Black;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(189, 1);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(208, 41);
            this.label12.TabIndex = 83;
            this.label12.Text = "الصلاحية";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Black;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(137, 1);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 41);
            this.label13.TabIndex = 84;
            this.label13.Text = "عرض";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Black;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(88, 1);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 41);
            this.label14.TabIndex = 85;
            this.label14.Text = "اضافة";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Black;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(44, 1);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 41);
            this.label21.TabIndex = 87;
            this.label21.Text = "تعديل";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Black;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(1, 1);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(42, 41);
            this.label22.TabIndex = 86;
            this.label22.Text = "حذف";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_show_client
            // 
            this.ch_show_client.AutoSize = true;
            this.ch_show_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_client.FlatAppearance.BorderSize = 0;
            this.ch_show_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_client.Location = new System.Drawing.Point(140, 46);
            this.ch_show_client.Name = "ch_show_client";
            this.ch_show_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_client.Size = new System.Drawing.Size(45, 35);
            this.ch_show_client.TabIndex = 90;
            this.ch_show_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_client.UseVisualStyleBackColor = true;
            // 
            // ch_delete_fara
            // 
            this.ch_delete_fara.AutoSize = true;
            this.ch_delete_fara.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_fara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_fara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_fara.FlatAppearance.BorderSize = 0;
            this.ch_delete_fara.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_fara.Location = new System.Drawing.Point(4, 70);
            this.ch_delete_fara.Name = "ch_delete_fara";
            this.ch_delete_fara.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_fara.Size = new System.Drawing.Size(36, 15);
            this.ch_delete_fara.TabIndex = 93;
            this.ch_delete_fara.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_fara.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_fara.UseVisualStyleBackColor = true;
            // 
            // ch_update_fara
            // 
            this.ch_update_fara.AutoSize = true;
            this.ch_update_fara.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_fara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_fara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_fara.FlatAppearance.BorderSize = 0;
            this.ch_update_fara.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_fara.Location = new System.Drawing.Point(47, 70);
            this.ch_update_fara.Name = "ch_update_fara";
            this.ch_update_fara.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_fara.Size = new System.Drawing.Size(37, 15);
            this.ch_update_fara.TabIndex = 92;
            this.ch_update_fara.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_fara.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_fara.UseVisualStyleBackColor = true;
            // 
            // ch_add_fara
            // 
            this.ch_add_fara.AutoSize = true;
            this.ch_add_fara.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_fara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_fara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_fara.FlatAppearance.BorderSize = 0;
            this.ch_add_fara.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_fara.Location = new System.Drawing.Point(91, 70);
            this.ch_add_fara.Name = "ch_add_fara";
            this.ch_add_fara.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_fara.Size = new System.Drawing.Size(42, 15);
            this.ch_add_fara.TabIndex = 91;
            this.ch_add_fara.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_fara.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_fara.UseVisualStyleBackColor = true;
            // 
            // ch_show_fara
            // 
            this.ch_show_fara.AutoSize = true;
            this.ch_show_fara.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_fara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_fara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_fara.FlatAppearance.BorderSize = 0;
            this.ch_show_fara.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_fara.Location = new System.Drawing.Point(140, 70);
            this.ch_show_fara.Name = "ch_show_fara";
            this.ch_show_fara.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_fara.Size = new System.Drawing.Size(45, 15);
            this.ch_show_fara.TabIndex = 90;
            this.ch_show_fara.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_fara.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_fara.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel5);
            this.groupBox5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.Red;
            this.groupBox5.Location = new System.Drawing.Point(929, 417);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(10, 5, 10, 10);
            this.groupBox5.Size = new System.Drawing.Size(418, 214);
            this.groupBox5.TabIndex = 89;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "اعدادات";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.AutoSize = true;
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel5.ColumnCount = 5;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.Controls.Add(label67, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.ch_delete_All_account, 4, 6);
            this.tableLayoutPanel5.Controls.Add(this.ch_update_All_account, 3, 6);
            this.tableLayoutPanel5.Controls.Add(this.ch_show_UserAccessMachineName, 3, 7);
            this.tableLayoutPanel5.Controls.Add(this.ch_add_All_account, 2, 6);
            this.tableLayoutPanel5.Controls.Add(this.ch_show_All_account, 1, 6);
            this.tableLayoutPanel5.Controls.Add(label30, 0, 6);
            this.tableLayoutPanel5.Controls.Add(label29, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.ch_delete_type_cash, 4, 5);
            this.tableLayoutPanel5.Controls.Add(this.ch_update_type_cash, 3, 5);
            this.tableLayoutPanel5.Controls.Add(this.ch_add_type_cash, 2, 5);
            this.tableLayoutPanel5.Controls.Add(this.ch_show_type_cash, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.ch_delete_store, 4, 4);
            this.tableLayoutPanel5.Controls.Add(this.ch_delete_setting, 4, 2);
            this.tableLayoutPanel5.Controls.Add(this.ch_update_store, 3, 4);
            this.tableLayoutPanel5.Controls.Add(this.ch_update_setting, 3, 2);
            this.tableLayoutPanel5.Controls.Add(this.ch_add_setting, 2, 2);
            this.tableLayoutPanel5.Controls.Add(this.ch_show_store, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.ch_show_setting, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.ch_delete_fara, 4, 3);
            this.tableLayoutPanel5.Controls.Add(this.ch_delete_user, 4, 1);
            this.tableLayoutPanel5.Controls.Add(this.ch_update_fara, 3, 3);
            this.tableLayoutPanel5.Controls.Add(this.ch_update_user, 3, 1);
            this.tableLayoutPanel5.Controls.Add(this.ch_add_fara, 2, 3);
            this.tableLayoutPanel5.Controls.Add(label35, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.ch_add_user, 2, 1);
            this.tableLayoutPanel5.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label37, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label38, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.label39, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.label40, 4, 0);
            this.tableLayoutPanel5.Controls.Add(label34, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.ch_show_fara, 1, 3);
            this.tableLayoutPanel5.Controls.Add(label41, 0, 1);
            this.tableLayoutPanel5.Controls.Add(label42, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.ch_show_user, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.ch_add_store, 2, 4);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(10, 28);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 8;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(398, 176);
            this.tableLayoutPanel5.TabIndex = 83;
            // 
            // ch_delete_All_account
            // 
            this.ch_delete_All_account.AutoSize = true;
            this.ch_delete_All_account.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_All_account.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_All_account.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_All_account.FlatAppearance.BorderSize = 0;
            this.ch_delete_All_account.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_All_account.Location = new System.Drawing.Point(4, 136);
            this.ch_delete_All_account.Name = "ch_delete_All_account";
            this.ch_delete_All_account.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_All_account.Size = new System.Drawing.Size(36, 15);
            this.ch_delete_All_account.TabIndex = 163;
            this.ch_delete_All_account.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_All_account.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_All_account.UseVisualStyleBackColor = true;
            // 
            // ch_update_All_account
            // 
            this.ch_update_All_account.AutoSize = true;
            this.ch_update_All_account.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_All_account.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_All_account.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_All_account.FlatAppearance.BorderSize = 0;
            this.ch_update_All_account.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_All_account.Location = new System.Drawing.Point(47, 136);
            this.ch_update_All_account.Name = "ch_update_All_account";
            this.ch_update_All_account.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_All_account.Size = new System.Drawing.Size(37, 15);
            this.ch_update_All_account.TabIndex = 163;
            this.ch_update_All_account.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_All_account.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_All_account.UseVisualStyleBackColor = true;
            // 
            // ch_add_All_account
            // 
            this.ch_add_All_account.AutoSize = true;
            this.ch_add_All_account.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_All_account.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_All_account.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_All_account.FlatAppearance.BorderSize = 0;
            this.ch_add_All_account.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_All_account.Location = new System.Drawing.Point(91, 136);
            this.ch_add_All_account.Name = "ch_add_All_account";
            this.ch_add_All_account.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_All_account.Size = new System.Drawing.Size(42, 15);
            this.ch_add_All_account.TabIndex = 163;
            this.ch_add_All_account.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_All_account.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_All_account.UseVisualStyleBackColor = true;
            // 
            // ch_show_All_account
            // 
            this.ch_show_All_account.AutoSize = true;
            this.ch_show_All_account.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_All_account.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_All_account.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_All_account.FlatAppearance.BorderSize = 0;
            this.ch_show_All_account.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_All_account.Location = new System.Drawing.Point(140, 136);
            this.ch_show_All_account.Name = "ch_show_All_account";
            this.ch_show_All_account.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_All_account.Size = new System.Drawing.Size(45, 15);
            this.ch_show_All_account.TabIndex = 163;
            this.ch_show_All_account.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_All_account.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_All_account.UseVisualStyleBackColor = true;
            // 
            // ch_delete_type_cash
            // 
            this.ch_delete_type_cash.AutoSize = true;
            this.ch_delete_type_cash.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_type_cash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_type_cash.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_type_cash.FlatAppearance.BorderSize = 0;
            this.ch_delete_type_cash.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_type_cash.Location = new System.Drawing.Point(4, 114);
            this.ch_delete_type_cash.Name = "ch_delete_type_cash";
            this.ch_delete_type_cash.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_type_cash.Size = new System.Drawing.Size(36, 15);
            this.ch_delete_type_cash.TabIndex = 163;
            this.ch_delete_type_cash.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_type_cash.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_type_cash.UseVisualStyleBackColor = true;
            // 
            // ch_update_type_cash
            // 
            this.ch_update_type_cash.AutoSize = true;
            this.ch_update_type_cash.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_type_cash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_type_cash.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_type_cash.FlatAppearance.BorderSize = 0;
            this.ch_update_type_cash.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_type_cash.Location = new System.Drawing.Point(47, 114);
            this.ch_update_type_cash.Name = "ch_update_type_cash";
            this.ch_update_type_cash.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_type_cash.Size = new System.Drawing.Size(37, 15);
            this.ch_update_type_cash.TabIndex = 163;
            this.ch_update_type_cash.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_type_cash.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_type_cash.UseVisualStyleBackColor = true;
            // 
            // ch_add_type_cash
            // 
            this.ch_add_type_cash.AutoSize = true;
            this.ch_add_type_cash.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_type_cash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_type_cash.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_type_cash.FlatAppearance.BorderSize = 0;
            this.ch_add_type_cash.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_type_cash.Location = new System.Drawing.Point(91, 114);
            this.ch_add_type_cash.Name = "ch_add_type_cash";
            this.ch_add_type_cash.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_type_cash.Size = new System.Drawing.Size(42, 15);
            this.ch_add_type_cash.TabIndex = 163;
            this.ch_add_type_cash.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_type_cash.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_type_cash.UseVisualStyleBackColor = true;
            // 
            // ch_show_type_cash
            // 
            this.ch_show_type_cash.AutoSize = true;
            this.ch_show_type_cash.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_type_cash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_type_cash.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_type_cash.FlatAppearance.BorderSize = 0;
            this.ch_show_type_cash.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_type_cash.Location = new System.Drawing.Point(140, 114);
            this.ch_show_type_cash.Name = "ch_show_type_cash";
            this.ch_show_type_cash.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_type_cash.Size = new System.Drawing.Size(45, 15);
            this.ch_show_type_cash.TabIndex = 163;
            this.ch_show_type_cash.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_type_cash.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_type_cash.UseVisualStyleBackColor = true;
            // 
            // ch_delete_store
            // 
            this.ch_delete_store.AutoSize = true;
            this.ch_delete_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_store.FlatAppearance.BorderSize = 0;
            this.ch_delete_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_store.Location = new System.Drawing.Point(4, 92);
            this.ch_delete_store.Name = "ch_delete_store";
            this.ch_delete_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_store.Size = new System.Drawing.Size(36, 15);
            this.ch_delete_store.TabIndex = 97;
            this.ch_delete_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_store.UseVisualStyleBackColor = true;
            // 
            // ch_delete_setting
            // 
            this.ch_delete_setting.AutoSize = true;
            this.ch_delete_setting.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_setting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_setting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_setting.FlatAppearance.BorderSize = 0;
            this.ch_delete_setting.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_setting.Location = new System.Drawing.Point(4, 48);
            this.ch_delete_setting.Name = "ch_delete_setting";
            this.ch_delete_setting.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_setting.Size = new System.Drawing.Size(36, 15);
            this.ch_delete_setting.TabIndex = 97;
            this.ch_delete_setting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_setting.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_setting.UseVisualStyleBackColor = true;
            // 
            // ch_update_store
            // 
            this.ch_update_store.AutoSize = true;
            this.ch_update_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_store.FlatAppearance.BorderSize = 0;
            this.ch_update_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_store.Location = new System.Drawing.Point(47, 92);
            this.ch_update_store.Name = "ch_update_store";
            this.ch_update_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_store.Size = new System.Drawing.Size(37, 15);
            this.ch_update_store.TabIndex = 96;
            this.ch_update_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_store.UseVisualStyleBackColor = true;
            // 
            // ch_update_setting
            // 
            this.ch_update_setting.AutoSize = true;
            this.ch_update_setting.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_setting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_setting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_setting.FlatAppearance.BorderSize = 0;
            this.ch_update_setting.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_setting.Location = new System.Drawing.Point(47, 48);
            this.ch_update_setting.Name = "ch_update_setting";
            this.ch_update_setting.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_setting.Size = new System.Drawing.Size(37, 15);
            this.ch_update_setting.TabIndex = 96;
            this.ch_update_setting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_setting.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_setting.UseVisualStyleBackColor = true;
            // 
            // ch_add_setting
            // 
            this.ch_add_setting.AutoSize = true;
            this.ch_add_setting.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_setting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_setting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_setting.FlatAppearance.BorderSize = 0;
            this.ch_add_setting.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_setting.Location = new System.Drawing.Point(91, 48);
            this.ch_add_setting.Name = "ch_add_setting";
            this.ch_add_setting.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_setting.Size = new System.Drawing.Size(42, 15);
            this.ch_add_setting.TabIndex = 95;
            this.ch_add_setting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_setting.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_setting.UseVisualStyleBackColor = true;
            // 
            // ch_show_store
            // 
            this.ch_show_store.AutoSize = true;
            this.ch_show_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_store.FlatAppearance.BorderSize = 0;
            this.ch_show_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_store.Location = new System.Drawing.Point(140, 92);
            this.ch_show_store.Name = "ch_show_store";
            this.ch_show_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_store.Size = new System.Drawing.Size(45, 15);
            this.ch_show_store.TabIndex = 94;
            this.ch_show_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_store.UseVisualStyleBackColor = true;
            // 
            // ch_show_setting
            // 
            this.ch_show_setting.AutoSize = true;
            this.ch_show_setting.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_setting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_setting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_setting.FlatAppearance.BorderSize = 0;
            this.ch_show_setting.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_setting.Location = new System.Drawing.Point(140, 48);
            this.ch_show_setting.Name = "ch_show_setting";
            this.ch_show_setting.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_setting.Size = new System.Drawing.Size(45, 15);
            this.ch_show_setting.TabIndex = 94;
            this.ch_show_setting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_setting.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_setting.UseVisualStyleBackColor = true;
            // 
            // ch_delete_user
            // 
            this.ch_delete_user.AutoSize = true;
            this.ch_delete_user.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_user.FlatAppearance.BorderSize = 0;
            this.ch_delete_user.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_user.Location = new System.Drawing.Point(4, 26);
            this.ch_delete_user.Name = "ch_delete_user";
            this.ch_delete_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_user.Size = new System.Drawing.Size(36, 15);
            this.ch_delete_user.TabIndex = 93;
            this.ch_delete_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_user.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_user.UseVisualStyleBackColor = true;
            // 
            // ch_update_user
            // 
            this.ch_update_user.AutoSize = true;
            this.ch_update_user.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_user.FlatAppearance.BorderSize = 0;
            this.ch_update_user.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_user.Location = new System.Drawing.Point(47, 26);
            this.ch_update_user.Name = "ch_update_user";
            this.ch_update_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_user.Size = new System.Drawing.Size(37, 15);
            this.ch_update_user.TabIndex = 92;
            this.ch_update_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_user.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_user.UseVisualStyleBackColor = true;
            // 
            // ch_add_user
            // 
            this.ch_add_user.AutoSize = true;
            this.ch_add_user.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_user.FlatAppearance.BorderSize = 0;
            this.ch_add_user.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_user.Location = new System.Drawing.Point(91, 26);
            this.ch_add_user.Name = "ch_add_user";
            this.ch_add_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_user.Size = new System.Drawing.Size(42, 15);
            this.ch_add_user.TabIndex = 91;
            this.ch_add_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_user.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_user.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Black;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(189, 1);
            this.label36.Margin = new System.Windows.Forms.Padding(0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(208, 21);
            this.label36.TabIndex = 83;
            this.label36.Text = "الصلاحية";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Black;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(137, 1);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(51, 21);
            this.label37.TabIndex = 84;
            this.label37.Text = "عرض";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Black;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(88, 1);
            this.label38.Margin = new System.Windows.Forms.Padding(0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(48, 21);
            this.label38.TabIndex = 85;
            this.label38.Text = "اضافة";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Black;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(44, 1);
            this.label39.Margin = new System.Windows.Forms.Padding(0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(43, 21);
            this.label39.TabIndex = 87;
            this.label39.Text = "تعديل";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Black;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(1, 1);
            this.label40.Margin = new System.Windows.Forms.Padding(0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(42, 21);
            this.label40.TabIndex = 86;
            this.label40.Text = "حذف";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_show_user
            // 
            this.ch_show_user.AutoSize = true;
            this.ch_show_user.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_user.FlatAppearance.BorderSize = 0;
            this.ch_show_user.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_user.Location = new System.Drawing.Point(140, 26);
            this.ch_show_user.Name = "ch_show_user";
            this.ch_show_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_user.Size = new System.Drawing.Size(45, 15);
            this.ch_show_user.TabIndex = 90;
            this.ch_show_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_user.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_user.UseVisualStyleBackColor = true;
            // 
            // ch_add_store
            // 
            this.ch_add_store.AutoSize = true;
            this.ch_add_store.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_store.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_store.FlatAppearance.BorderSize = 0;
            this.ch_add_store.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_store.Location = new System.Drawing.Point(91, 92);
            this.ch_add_store.Name = "ch_add_store";
            this.ch_add_store.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_store.Size = new System.Drawing.Size(42, 15);
            this.ch_add_store.TabIndex = 95;
            this.ch_add_store.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_store.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_store.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tableLayoutPanel6.AutoSize = true;
            this.tableLayoutPanel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel6.ColumnCount = 4;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.Controls.Add(this.btn_print, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.btn_save, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.btn_new, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.btn_delete, 2, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(15, 724);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(360, 35);
            this.tableLayoutPanel6.TabIndex = 153;
            // 
            // btn_print
            // 
            this.btn_print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_print.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_print.FlatAppearance.BorderSize = 0;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(2, 3);
            this.btn_print.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(86, 29);
            this.btn_print.TabIndex = 80;
            this.btn_print.Text = "طباعة";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Visible = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tableLayoutPanel7);
            this.groupBox6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.Color.Red;
            this.groupBox6.Location = new System.Drawing.Point(607, 634);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(10, 5, 10, 10);
            this.groupBox6.Size = new System.Drawing.Size(316, 82);
            this.groupBox6.TabIndex = 154;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "بيانات الشركة";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.AutoSize = true;
            this.tableLayoutPanel7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel7.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.label20, 1, 0);
            this.tableLayoutPanel7.Controls.Add(label43, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.ch_update_company, 1, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(10, 28);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(296, 44);
            this.tableLayoutPanel7.TabIndex = 83;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Black;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(53, 1);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(242, 20);
            this.label19.TabIndex = 83;
            this.label19.Text = "الصلاحية";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Black;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(1, 1);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 20);
            this.label20.TabIndex = 84;
            this.label20.Text = "عرض";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_update_company
            // 
            this.ch_update_company.AutoSize = true;
            this.ch_update_company.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_company.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_company.FlatAppearance.BorderSize = 0;
            this.ch_update_company.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_company.Location = new System.Drawing.Point(4, 25);
            this.ch_update_company.Name = "ch_update_company";
            this.ch_update_company.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_company.Size = new System.Drawing.Size(45, 15);
            this.ch_update_company.TabIndex = 90;
            this.ch_update_company.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_company.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_company.UseVisualStyleBackColor = true;
            // 
            // ch_all
            // 
            this.ch_all.AutoSize = true;
            this.ch_all.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_all.FlatAppearance.BorderSize = 0;
            this.ch_all.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_all.Location = new System.Drawing.Point(449, 55);
            this.ch_all.Name = "ch_all";
            this.ch_all.Size = new System.Drawing.Size(178, 28);
            this.ch_all.TabIndex = 155;
            this.ch_all.Text = "تحديد جميع الصلاحيات";
            this.ch_all.UseVisualStyleBackColor = true;
            this.ch_all.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.tableLayoutPanel8);
            this.groupBox7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.Color.Red;
            this.groupBox7.Location = new System.Drawing.Point(14, 417);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(10, 5, 10, 10);
            this.groupBox7.Size = new System.Drawing.Size(578, 214);
            this.groupBox7.TabIndex = 156;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "اعدادات عامة للفواتير";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.AutoSize = true;
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel8.Controls.Add(this.ch_invoice_agel, 1, 1);
            this.tableLayoutPanel8.Controls.Add(label46, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.ch_invoice_chang_price, 1, 4);
            this.tableLayoutPanel8.Controls.Add(this.ch_invoice_show_Balance_client, 1, 6);
            this.tableLayoutPanel8.Controls.Add(this.ch_invoice_chang_list_price_client, 1, 5);
            this.tableLayoutPanel8.Controls.Add(this.ch_invoice_date, 1, 2);
            this.tableLayoutPanel8.Controls.Add(this.label49, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.label50, 1, 0);
            this.tableLayoutPanel8.Controls.Add(label51, 0, 2);
            this.tableLayoutPanel8.Controls.Add(label52, 0, 6);
            this.tableLayoutPanel8.Controls.Add(label55, 0, 5);
            this.tableLayoutPanel8.Controls.Add(label56, 0, 4);
            this.tableLayoutPanel8.Controls.Add(label57, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.ch_invoice_print, 1, 3);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(10, 28);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 7;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(558, 176);
            this.tableLayoutPanel8.TabIndex = 83;
            // 
            // ch_invoice_agel
            // 
            this.ch_invoice_agel.AutoSize = true;
            this.ch_invoice_agel.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_agel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_agel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_agel.FlatAppearance.BorderSize = 0;
            this.ch_invoice_agel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_agel.Location = new System.Drawing.Point(4, 29);
            this.ch_invoice_agel.Name = "ch_invoice_agel";
            this.ch_invoice_agel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_agel.Size = new System.Drawing.Size(41, 18);
            this.ch_invoice_agel.TabIndex = 157;
            this.ch_invoice_agel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_agel.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_agel.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_chang_price
            // 
            this.ch_invoice_chang_price.AutoSize = true;
            this.ch_invoice_chang_price.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_chang_price.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_chang_price.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_chang_price.FlatAppearance.BorderSize = 0;
            this.ch_invoice_chang_price.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_chang_price.Location = new System.Drawing.Point(4, 104);
            this.ch_invoice_chang_price.Name = "ch_invoice_chang_price";
            this.ch_invoice_chang_price.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_chang_price.Size = new System.Drawing.Size(41, 18);
            this.ch_invoice_chang_price.TabIndex = 157;
            this.ch_invoice_chang_price.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_chang_price.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_chang_price.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_show_Balance_client
            // 
            this.ch_invoice_show_Balance_client.AutoSize = true;
            this.ch_invoice_show_Balance_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_show_Balance_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_show_Balance_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_show_Balance_client.FlatAppearance.BorderSize = 0;
            this.ch_invoice_show_Balance_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_show_Balance_client.Location = new System.Drawing.Point(4, 154);
            this.ch_invoice_show_Balance_client.Name = "ch_invoice_show_Balance_client";
            this.ch_invoice_show_Balance_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_show_Balance_client.Size = new System.Drawing.Size(41, 18);
            this.ch_invoice_show_Balance_client.TabIndex = 157;
            this.ch_invoice_show_Balance_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_show_Balance_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_show_Balance_client.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_chang_list_price_client
            // 
            this.ch_invoice_chang_list_price_client.AutoSize = true;
            this.ch_invoice_chang_list_price_client.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_chang_list_price_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_chang_list_price_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_chang_list_price_client.FlatAppearance.BorderSize = 0;
            this.ch_invoice_chang_list_price_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_chang_list_price_client.Location = new System.Drawing.Point(4, 129);
            this.ch_invoice_chang_list_price_client.Name = "ch_invoice_chang_list_price_client";
            this.ch_invoice_chang_list_price_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_chang_list_price_client.Size = new System.Drawing.Size(41, 18);
            this.ch_invoice_chang_list_price_client.TabIndex = 157;
            this.ch_invoice_chang_list_price_client.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_chang_list_price_client.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_chang_list_price_client.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_date
            // 
            this.ch_invoice_date.AutoSize = true;
            this.ch_invoice_date.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_date.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_date.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_date.FlatAppearance.BorderSize = 0;
            this.ch_invoice_date.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_date.Location = new System.Drawing.Point(4, 54);
            this.ch_invoice_date.Name = "ch_invoice_date";
            this.ch_invoice_date.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_date.Size = new System.Drawing.Size(41, 18);
            this.ch_invoice_date.TabIndex = 157;
            this.ch_invoice_date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_date.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_date.UseVisualStyleBackColor = true;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Black;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(49, 1);
            this.label49.Margin = new System.Windows.Forms.Padding(0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(508, 24);
            this.label49.TabIndex = 83;
            this.label49.Text = "الصلاحية";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Black;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(1, 1);
            this.label50.Margin = new System.Windows.Forms.Padding(0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(47, 24);
            this.label50.TabIndex = 84;
            this.label50.Text = "سماح";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_invoice_print
            // 
            this.ch_invoice_print.AutoSize = true;
            this.ch_invoice_print.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_print.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ch_invoice_print.FlatAppearance.BorderSize = 0;
            this.ch_invoice_print.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_print.Location = new System.Drawing.Point(4, 80);
            this.ch_invoice_print.Name = "ch_invoice_print";
            this.ch_invoice_print.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_print.Size = new System.Drawing.Size(41, 17);
            this.ch_invoice_print.TabIndex = 157;
            this.ch_invoice_print.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_print.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_print.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_print_anoter_user
            // 
            this.ch_invoice_print_anoter_user.AutoSize = true;
            this.ch_invoice_print_anoter_user.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_print_anoter_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_print_anoter_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_print_anoter_user.FlatAppearance.BorderSize = 0;
            this.ch_invoice_print_anoter_user.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_print_anoter_user.Location = new System.Drawing.Point(4, 148);
            this.ch_invoice_print_anoter_user.Name = "ch_invoice_print_anoter_user";
            this.ch_invoice_print_anoter_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_print_anoter_user.Size = new System.Drawing.Size(41, 24);
            this.ch_invoice_print_anoter_user.TabIndex = 158;
            this.ch_invoice_print_anoter_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_print_anoter_user.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_print_anoter_user.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_print_befor_date
            // 
            this.ch_invoice_print_befor_date.AutoSize = true;
            this.ch_invoice_print_befor_date.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_print_befor_date.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_print_befor_date.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_print_befor_date.FlatAppearance.BorderSize = 0;
            this.ch_invoice_print_befor_date.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_print_befor_date.Location = new System.Drawing.Point(4, 124);
            this.ch_invoice_print_befor_date.Name = "ch_invoice_print_befor_date";
            this.ch_invoice_print_befor_date.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_print_befor_date.Size = new System.Drawing.Size(41, 17);
            this.ch_invoice_print_befor_date.TabIndex = 158;
            this.ch_invoice_print_befor_date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_print_befor_date.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_print_befor_date.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_delete_anoter_user
            // 
            this.ch_invoice_delete_anoter_user.AutoSize = true;
            this.ch_invoice_delete_anoter_user.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_delete_anoter_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_delete_anoter_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_delete_anoter_user.FlatAppearance.BorderSize = 0;
            this.ch_invoice_delete_anoter_user.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_delete_anoter_user.Location = new System.Drawing.Point(4, 100);
            this.ch_invoice_delete_anoter_user.Name = "ch_invoice_delete_anoter_user";
            this.ch_invoice_delete_anoter_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_delete_anoter_user.Size = new System.Drawing.Size(41, 17);
            this.ch_invoice_delete_anoter_user.TabIndex = 158;
            this.ch_invoice_delete_anoter_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_delete_anoter_user.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_delete_anoter_user.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_update_anoter_user
            // 
            this.ch_invoice_update_anoter_user.AutoSize = true;
            this.ch_invoice_update_anoter_user.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_update_anoter_user.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_update_anoter_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_update_anoter_user.FlatAppearance.BorderSize = 0;
            this.ch_invoice_update_anoter_user.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_update_anoter_user.Location = new System.Drawing.Point(4, 52);
            this.ch_invoice_update_anoter_user.Name = "ch_invoice_update_anoter_user";
            this.ch_invoice_update_anoter_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_update_anoter_user.Size = new System.Drawing.Size(41, 17);
            this.ch_invoice_update_anoter_user.TabIndex = 159;
            this.ch_invoice_update_anoter_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_update_anoter_user.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_update_anoter_user.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_update_befor_date
            // 
            this.ch_invoice_update_befor_date.AutoSize = true;
            this.ch_invoice_update_befor_date.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_update_befor_date.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_update_befor_date.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_update_befor_date.FlatAppearance.BorderSize = 0;
            this.ch_invoice_update_befor_date.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_update_befor_date.Location = new System.Drawing.Point(4, 28);
            this.ch_invoice_update_befor_date.Name = "ch_invoice_update_befor_date";
            this.ch_invoice_update_befor_date.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_update_befor_date.Size = new System.Drawing.Size(41, 17);
            this.ch_invoice_update_befor_date.TabIndex = 158;
            this.ch_invoice_update_befor_date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_update_befor_date.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_update_befor_date.UseVisualStyleBackColor = true;
            // 
            // ch_invoice_delete_befor_date
            // 
            this.ch_invoice_delete_befor_date.AutoSize = true;
            this.ch_invoice_delete_befor_date.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_delete_befor_date.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_invoice_delete_befor_date.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_invoice_delete_befor_date.FlatAppearance.BorderSize = 0;
            this.ch_invoice_delete_befor_date.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_invoice_delete_befor_date.Location = new System.Drawing.Point(4, 76);
            this.ch_invoice_delete_befor_date.Name = "ch_invoice_delete_befor_date";
            this.ch_invoice_delete_befor_date.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_invoice_delete_befor_date.Size = new System.Drawing.Size(41, 17);
            this.ch_invoice_delete_befor_date.TabIndex = 158;
            this.ch_invoice_delete_befor_date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_invoice_delete_befor_date.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_invoice_delete_befor_date.UseVisualStyleBackColor = true;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.Black;
            this.label64.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label64.ForeColor = System.Drawing.Color.White;
            this.label64.Location = new System.Drawing.Point(1071, 35);
            this.label64.Margin = new System.Windows.Forms.Padding(0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(51, 24);
            this.label64.TabIndex = 158;
            this.label64.Text = "عرض";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label64.Visible = false;
            // 
            // dr_invoice_AutoUpdatePrice
            // 
            this.dr_invoice_AutoUpdatePrice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_invoice_AutoUpdatePrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.dr_invoice_AutoUpdatePrice.FormattingEnabled = true;
            this.dr_invoice_AutoUpdatePrice.Location = new System.Drawing.Point(24, 643);
            this.dr_invoice_AutoUpdatePrice.Name = "dr_invoice_AutoUpdatePrice";
            this.dr_invoice_AutoUpdatePrice.Size = new System.Drawing.Size(315, 32);
            this.dr_invoice_AutoUpdatePrice.TabIndex = 159;
            // 
            // ch_report_all_amount
            // 
            this.ch_report_all_amount.AutoSize = true;
            this.ch_report_all_amount.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_report_all_amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_report_all_amount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_report_all_amount.FlatAppearance.BorderSize = 0;
            this.ch_report_all_amount.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_report_all_amount.Location = new System.Drawing.Point(140, 24);
            this.ch_report_all_amount.Name = "ch_report_all_amount";
            this.ch_report_all_amount.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_report_all_amount.Size = new System.Drawing.Size(45, 14);
            this.ch_report_all_amount.TabIndex = 90;
            this.ch_report_all_amount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_report_all_amount.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_report_all_amount.UseVisualStyleBackColor = true;
            // 
            // dr_AcssessStore
            // 
            this.dr_AcssessStore.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_AcssessStore.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.dr_AcssessStore.FormattingEnabled = true;
            this.dr_AcssessStore.Location = new System.Drawing.Point(24, 682);
            this.dr_AcssessStore.Name = "dr_AcssessStore";
            this.dr_AcssessStore.Size = new System.Drawing.Size(315, 32);
            this.dr_AcssessStore.TabIndex = 161;
            // 
            // ch_show_UserAccessMachineName
            // 
            this.ch_show_UserAccessMachineName.AutoSize = true;
            this.ch_show_UserAccessMachineName.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_UserAccessMachineName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_UserAccessMachineName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_UserAccessMachineName.FlatAppearance.BorderSize = 0;
            this.ch_show_UserAccessMachineName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_UserAccessMachineName.Location = new System.Drawing.Point(47, 158);
            this.ch_show_UserAccessMachineName.Name = "ch_show_UserAccessMachineName";
            this.ch_show_UserAccessMachineName.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_UserAccessMachineName.Size = new System.Drawing.Size(37, 14);
            this.ch_show_UserAccessMachineName.TabIndex = 162;
            this.ch_show_UserAccessMachineName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_UserAccessMachineName.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_UserAccessMachineName.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel4);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.Red;
            this.groupBox4.Location = new System.Drawing.Point(928, 634);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(10, 5, 10, 10);
            this.groupBox4.Size = new System.Drawing.Size(418, 100);
            this.groupBox4.TabIndex = 163;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "الحسابات";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.AutoSize = true;
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel4.ColumnCount = 5;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.ch_delete_amount, 4, 2);
            this.tableLayoutPanel4.Controls.Add(this.ch_update_amount, 3, 2);
            this.tableLayoutPanel4.Controls.Add(this.ch_report_all_amount, 1, 1);
            this.tableLayoutPanel4.Controls.Add(label63, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.ch_add_amount, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.label69, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label70, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label71, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label72, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label73, 4, 0);
            this.tableLayoutPanel4.Controls.Add(label75, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.ch_show_amount, 1, 2);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(10, 28);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(398, 62);
            this.tableLayoutPanel4.TabIndex = 83;
            // 
            // ch_delete_amount
            // 
            this.ch_delete_amount.AutoSize = true;
            this.ch_delete_amount.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_delete_amount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_delete_amount.FlatAppearance.BorderSize = 0;
            this.ch_delete_amount.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_delete_amount.Location = new System.Drawing.Point(4, 45);
            this.ch_delete_amount.Name = "ch_delete_amount";
            this.ch_delete_amount.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_delete_amount.Size = new System.Drawing.Size(36, 13);
            this.ch_delete_amount.TabIndex = 93;
            this.ch_delete_amount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_delete_amount.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_delete_amount.UseVisualStyleBackColor = true;
            // 
            // ch_update_amount
            // 
            this.ch_update_amount.AutoSize = true;
            this.ch_update_amount.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_update_amount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_update_amount.FlatAppearance.BorderSize = 0;
            this.ch_update_amount.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_update_amount.Location = new System.Drawing.Point(47, 45);
            this.ch_update_amount.Name = "ch_update_amount";
            this.ch_update_amount.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_update_amount.Size = new System.Drawing.Size(37, 13);
            this.ch_update_amount.TabIndex = 92;
            this.ch_update_amount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_update_amount.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_update_amount.UseVisualStyleBackColor = true;
            // 
            // ch_add_amount
            // 
            this.ch_add_amount.AutoSize = true;
            this.ch_add_amount.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_add_amount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_add_amount.FlatAppearance.BorderSize = 0;
            this.ch_add_amount.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_add_amount.Location = new System.Drawing.Point(91, 45);
            this.ch_add_amount.Name = "ch_add_amount";
            this.ch_add_amount.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_add_amount.Size = new System.Drawing.Size(42, 13);
            this.ch_add_amount.TabIndex = 91;
            this.ch_add_amount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_add_amount.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_add_amount.UseVisualStyleBackColor = true;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Black;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label69.ForeColor = System.Drawing.Color.White;
            this.label69.Location = new System.Drawing.Point(189, 1);
            this.label69.Margin = new System.Windows.Forms.Padding(0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(208, 19);
            this.label69.TabIndex = 83;
            this.label69.Text = "الصلاحية";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.Black;
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label70.ForeColor = System.Drawing.Color.White;
            this.label70.Location = new System.Drawing.Point(137, 1);
            this.label70.Margin = new System.Windows.Forms.Padding(0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(51, 19);
            this.label70.TabIndex = 84;
            this.label70.Text = "عرض";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.Black;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label71.ForeColor = System.Drawing.Color.White;
            this.label71.Location = new System.Drawing.Point(88, 1);
            this.label71.Margin = new System.Windows.Forms.Padding(0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(48, 19);
            this.label71.TabIndex = 85;
            this.label71.Text = "اضافة";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.Black;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label72.ForeColor = System.Drawing.Color.White;
            this.label72.Location = new System.Drawing.Point(44, 1);
            this.label72.Margin = new System.Windows.Forms.Padding(0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(43, 19);
            this.label72.TabIndex = 87;
            this.label72.Text = "تعديل";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.Black;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label73.ForeColor = System.Drawing.Color.White;
            this.label73.Location = new System.Drawing.Point(1, 1);
            this.label73.Margin = new System.Windows.Forms.Padding(0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(42, 19);
            this.label73.TabIndex = 86;
            this.label73.Text = "حذف";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ch_show_amount
            // 
            this.ch_show_amount.AutoSize = true;
            this.ch_show_amount.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_show_amount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ch_show_amount.FlatAppearance.BorderSize = 0;
            this.ch_show_amount.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ch_show_amount.Location = new System.Drawing.Point(140, 45);
            this.ch_show_amount.Name = "ch_show_amount";
            this.ch_show_amount.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ch_show_amount.Size = new System.Drawing.Size(45, 13);
            this.ch_show_amount.TabIndex = 90;
            this.ch_show_amount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ch_show_amount.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.ch_show_amount.UseVisualStyleBackColor = true;
            // 
            // lp_titel
            // 
            this.lp_titel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lp_titel.Dock = System.Windows.Forms.DockStyle.Top;
            this.lp_titel.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold);
            this.lp_titel.ForeColor = System.Drawing.Color.White;
            this.lp_titel.Image = global::tnerhbeauty.Properties.Resources.add_user;
            this.lp_titel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp_titel.Location = new System.Drawing.Point(0, 0);
            this.lp_titel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lp_titel.Name = "lp_titel";
            this.lp_titel.Size = new System.Drawing.Size(1358, 35);
            this.lp_titel.TabIndex = 51;
            this.lp_titel.Text = "الصلاحيات";
            this.lp_titel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.tableLayoutPanel9);
            this.groupBox8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.Color.Red;
            this.groupBox8.Location = new System.Drawing.Point(607, 417);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(10, 5, 10, 10);
            this.groupBox8.Size = new System.Drawing.Size(316, 214);
            this.groupBox8.TabIndex = 164;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "اعدادات عامة";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.AutoSize = true;
            this.tableLayoutPanel9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tableLayoutPanel9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel9.Controls.Add(this.ch_invoice_print_anoter_user, 1, 6);
            this.tableLayoutPanel9.Controls.Add(this.label32, 0, 0);
            this.tableLayoutPanel9.Controls.Add(label61, 0, 6);
            this.tableLayoutPanel9.Controls.Add(this.ch_invoice_print_befor_date, 1, 5);
            this.tableLayoutPanel9.Controls.Add(this.label33, 1, 0);
            this.tableLayoutPanel9.Controls.Add(label48, 0, 1);
            this.tableLayoutPanel9.Controls.Add(label62, 0, 5);
            this.tableLayoutPanel9.Controls.Add(this.ch_invoice_delete_anoter_user, 1, 4);
            this.tableLayoutPanel9.Controls.Add(this.ch_invoice_update_befor_date, 1, 1);
            this.tableLayoutPanel9.Controls.Add(label59, 0, 2);
            this.tableLayoutPanel9.Controls.Add(label60, 0, 4);
            this.tableLayoutPanel9.Controls.Add(this.ch_invoice_update_anoter_user, 1, 2);
            this.tableLayoutPanel9.Controls.Add(this.ch_invoice_delete_befor_date, 1, 3);
            this.tableLayoutPanel9.Controls.Add(label58, 0, 3);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.ForeColor = System.Drawing.Color.Black;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(10, 28);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 7;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(296, 176);
            this.tableLayoutPanel9.TabIndex = 83;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Black;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(49, 1);
            this.label32.Margin = new System.Windows.Forms.Padding(0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(246, 23);
            this.label32.TabIndex = 83;
            this.label32.Text = "الصلاحية";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Black;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(1, 1);
            this.label33.Margin = new System.Windows.Forms.Padding(0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(47, 23);
            this.label33.TabIndex = 84;
            this.label33.Text = "سماح";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            label67.AutoSize = true;
            label67.Dock = System.Windows.Forms.DockStyle.Fill;
            label67.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label67.Location = new System.Drawing.Point(191, 155);
            label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label67.Name = "label67";
            label67.Size = new System.Drawing.Size(204, 20);
            label67.TabIndex = 165;
            label67.Text = "التحكم في الاجهزة المتصلة";
            label67.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox2.FlatAppearance.BorderSize = 0;
            this.checkBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.checkBox2.Location = new System.Drawing.Point(840, 70);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.checkBox2.Size = new System.Drawing.Size(18, 17);
            this.checkBox2.TabIndex = 165;
            this.checkBox2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.Visible = false;
            // 
            // maridBindingSource
            // 
            this.maridBindingSource.DataSource = typeof(tnerhbeauty.Client);
            // 
            // add_setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1358, 795);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.dr_AcssessStore);
            this.Controls.Add(this.dr_invoice_AutoUpdatePrice);
            this.Controls.Add(this.label64);
            this.Controls.Add(label47);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.ch_all);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.tableLayoutPanel6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lp_titel);
            this.Controls.Add(this.lb_mas);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.tx_name);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "add_setting";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "الصلاحيات";
            this.Load += new System.EventHandler(this.add_marid_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.add_marid_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maridBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource maridBindingSource;
        private System.Windows.Forms.TextBox tx_name;
        private System.Windows.Forms.Label lb_mas;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label lp_titel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox ch_update_price_producut_exal;
        private System.Windows.Forms.CheckBox ch_update_price_producut;
        private System.Windows.Forms.CheckBox ch_delete_product;
        private System.Windows.Forms.CheckBox ch_update_product;
        private System.Windows.Forms.CheckBox ch_add_product;
        private System.Windows.Forms.CheckBox ch_show_product;
        private System.Windows.Forms.CheckBox ch_delete_invoice_to_store;
        private System.Windows.Forms.CheckBox ch_update_invoice_to_store;
        private System.Windows.Forms.CheckBox ch_add_invoice_to_store;
        private System.Windows.Forms.CheckBox ch_show_invoice_to_store;
        private System.Windows.Forms.CheckBox ch_delete_invoice_sale;
        private System.Windows.Forms.CheckBox ch_update_invoice_sale;
        private System.Windows.Forms.CheckBox ch_add_invoice_sale;
        private System.Windows.Forms.CheckBox ch_show_invoice_sale;
        private System.Windows.Forms.CheckBox ch_delete_invoice_pay;
        private System.Windows.Forms.CheckBox ch_update_invoice_pay;
        private System.Windows.Forms.CheckBox ch_add_invoice_pay;
        private System.Windows.Forms.CheckBox ch_show_invoice_pay;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox ch_report_mabeat_product;
        private System.Windows.Forms.CheckBox ch_store_in_and_out;
        private System.Windows.Forms.CheckBox ch_blance_in_storses;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox ch_kashf_hesab_prodct;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.CheckBox ch_kashf_hesab_client;
        private System.Windows.Forms.CheckBox ch_delete_amount_client;
        private System.Windows.Forms.CheckBox ch_update_amount_client;
        private System.Windows.Forms.CheckBox ch_add_amount_client;
        private System.Windows.Forms.CheckBox ch_show_amount_client;
        private System.Windows.Forms.CheckBox ch_delete_client;
        private System.Windows.Forms.CheckBox ch_update_client;
        private System.Windows.Forms.CheckBox ch_add_client;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.CheckBox ch_show_client;
        private System.Windows.Forms.CheckBox ch_delete_fara;
        private System.Windows.Forms.CheckBox ch_update_fara;
        private System.Windows.Forms.CheckBox ch_add_fara;
        private System.Windows.Forms.CheckBox ch_show_fara;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.CheckBox ch_delete_setting;
        private System.Windows.Forms.CheckBox ch_update_setting;
        private System.Windows.Forms.CheckBox ch_add_setting;
        private System.Windows.Forms.CheckBox ch_show_setting;
        private System.Windows.Forms.CheckBox ch_delete_user;
        private System.Windows.Forms.CheckBox ch_update_user;
        private System.Windows.Forms.CheckBox ch_add_user;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.CheckBox ch_show_user;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox ch_update_company;
        private System.Windows.Forms.CheckBox ch_show_invoice_pay_from_store;
        private System.Windows.Forms.CheckBox ch_add_invoice_pay_from_store;
        private System.Windows.Forms.CheckBox ch_update_invoice_pay_from_store;
        private System.Windows.Forms.CheckBox ch_delete_invoice_pay_from_store;
        private System.Windows.Forms.CheckBox ch_update_invoice_return_to_supplier;
        private System.Windows.Forms.CheckBox ch_update_invoice_taswiat_khasm;
        private System.Windows.Forms.CheckBox ch_update_invoice_return_from_client;
        private System.Windows.Forms.CheckBox ch_add_invoice_return_to_supplier;
        private System.Windows.Forms.CheckBox ch_add_invoice_taswet_edafa;
        private System.Windows.Forms.CheckBox ch_show_invoice_taswet_edafa;
        private System.Windows.Forms.CheckBox ch_add_invoice_return_from_client;
        private System.Windows.Forms.CheckBox ch_add_invoice_taswiat_khasm;
        private System.Windows.Forms.CheckBox ch_show_invoice_return_to_supplier;
        private System.Windows.Forms.CheckBox ch_show_invoice_return_from_client;
        private System.Windows.Forms.CheckBox ch_delete_invoice_return_to_supplier;
        private System.Windows.Forms.CheckBox ch_update_invoice_taswet_edafa;
        private System.Windows.Forms.CheckBox ch_delete_invoice_return_from_client;
        private System.Windows.Forms.CheckBox ch_delete_invoice_taswet_edafa;
        private System.Windows.Forms.CheckBox ch_show_invoice_taswiat_khasm;
        private System.Windows.Forms.CheckBox ch_delete_invoice_taswiat_khasm;
        private System.Windows.Forms.CheckBox ch_all;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.CheckBox ch_invoice_show_Balance_client;
        private System.Windows.Forms.CheckBox ch_invoice_chang_list_price_client;
        private System.Windows.Forms.CheckBox ch_invoice_print;
        private System.Windows.Forms.CheckBox ch_invoice_date;
        private System.Windows.Forms.CheckBox ch_invoice_chang_price;
        private System.Windows.Forms.CheckBox ch_invoice_agel;
        private System.Windows.Forms.CheckBox ch_invoice_update_befor_date;
        private System.Windows.Forms.CheckBox ch_invoice_delete_befor_date;
        private System.Windows.Forms.CheckBox ch_invoice_update_anoter_user;
        private System.Windows.Forms.CheckBox ch_invoice_delete_anoter_user;
        private System.Windows.Forms.CheckBox ch_invoice_print_anoter_user;
        private System.Windows.Forms.CheckBox ch_invoice_print_befor_date;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.CheckBox ch_Discount_invoice_return_from_client;
        private System.Windows.Forms.CheckBox ch_Discount_invoice_return_to_supplier;
        private System.Windows.Forms.CheckBox ch_Discount_invoice_sale;
        private System.Windows.Forms.CheckBox ch_Discount_invoice_pay;
        private System.Windows.Forms.CheckBox ch_Discount_item_invoice_return_from_client;
        private System.Windows.Forms.CheckBox ch_Discount_item_invoice_return_to_supplier;
        private System.Windows.Forms.CheckBox ch_Discount_item_invoice_sale;
        private System.Windows.Forms.CheckBox ch_Discount_item_invoice_pay;
        private System.Windows.Forms.ComboBox dr_invoice_AutoUpdatePrice;
        private System.Windows.Forms.CheckBox ch_report_all_amount;
        private System.Windows.Forms.ComboBox dr_AcssessStore;
        private System.Windows.Forms.CheckBox ch_add_type_cash;
        private System.Windows.Forms.CheckBox ch_show_UserAccessMachineName;
        private System.Windows.Forms.CheckBox ch_show_type_cash;
        private System.Windows.Forms.CheckBox ch_delete_store;
        private System.Windows.Forms.CheckBox ch_update_store;
        private System.Windows.Forms.CheckBox ch_show_store;
        private System.Windows.Forms.CheckBox ch_add_store;
        private System.Windows.Forms.CheckBox ch_delete_type_cash;
        private System.Windows.Forms.CheckBox ch_update_type_cash;
        private System.Windows.Forms.CheckBox ch_delete_All_account;
        private System.Windows.Forms.CheckBox ch_update_All_account;
        private System.Windows.Forms.CheckBox ch_add_All_account;
        private System.Windows.Forms.CheckBox ch_show_All_account;
        private System.Windows.Forms.CheckBox ch_up_product_min_mum;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.CheckBox ch_delete_amount;
        private System.Windows.Forms.CheckBox ch_update_amount;
        private System.Windows.Forms.CheckBox ch_add_amount;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.CheckBox ch_show_amount;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.CheckBox ch_delete_invoice_broken;
        private System.Windows.Forms.CheckBox ch_update_invoice_broken;
        private System.Windows.Forms.CheckBox ch_add_invoice_broken;
        private System.Windows.Forms.CheckBox ch_show_invoice_broken;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.CheckBox ch_Extra_invoice_return_from_client;
        private System.Windows.Forms.CheckBox ch_Extra_invoice_return_to_supplier;
        private System.Windows.Forms.CheckBox ch_Extra_invoice_sale;
        private System.Windows.Forms.CheckBox ch_Extra_invoice_pay;
        private System.Windows.Forms.CheckBox ch_show_Price_mabeat_product;
        private System.Windows.Forms.CheckBox checkBox2;
    }
}