﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using tnerhbeauty.Class;
using tnerhbeauty.rport;
using Microsoft.Reporting.WinForms;
using static tnerhbeauty.Class.invoice;

namespace tnerhbeauty
{
    public partial class all_InvoiceHeader : Form
    {
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;  // Turn on WS_EX_COMPOSITED
                return cp;
            }
        }
       
        invoice_type Invoice_Type;
     
        public all_InvoiceHeader(int _type)
        {
            InitializeComponent();
            Invoice_Type = invoice.GetInvoiceType(_type);
        }       
        private void all_kushufat_Load(object sender, EventArgs e)
        {
            btn_new.Visible = Invoice_Type.id == (int)invoice_name.invoice_pay_from_store;
            dr_fara.IntializeData(cproduct.FaraUser, nameof(fara.name_fara), nameof(fara.id));
            dr_fara_SelectionChangeCommitted(null, null);
            dr_is_agel.IntializeData(Session.PayMethodsList);
           
            gv.DataSource = new List<InvoiceHeaderView>();
            getdata();
            //gv.Columns[nameof(InvoiceHeaderView.id)].Visible = false;
            gv.Columns[nameof(InvoiceHeaderView.id_cient)].Visible = false;
            gv.Columns[nameof(InvoiceHeaderView.id_invoice_type)].Visible = false;
            gv.Columns[nameof(InvoiceHeaderView.id_fara)].Visible = false;
            gv.Columns[nameof(InvoiceHeaderView.id_user)].Visible = false;
            //gv.Columns[nameof(InvoiceHeaderView.name_invoice_type)].Visible = false;
            //gv.Columns[nameof(InvoiceHeaderView.name_fara)].Visible = false;
            //gv.Columns[nameof(InvoiceHeaderView.user_name)].Visible = false;

            gv.Columns[nameof(InvoiceHeaderView.name)].Visible = Invoice_Type.showClient;
            gv.Columns[nameof(InvoiceHeaderView.Total_product)].Visible = Invoice_Type.ShowPrice;
            gv.Columns[nameof(InvoiceHeaderView.Discount)].Visible = Invoice_Type.ShowPrice;
            gv.Columns[nameof(InvoiceHeaderView.Extra)].Visible = Invoice_Type.ShowPrice;
            gv.Columns[nameof(InvoiceHeaderView.Net)].Visible = Invoice_Type.ShowPrice;
            //gv.Columns[nameof(InvoiceHeaderView.is_agel)].Visible = Invoice_Type.ShowPrice;

            gv.Columns[nameof(InvoiceHeaderView.name)].HeaderText = "  اسم العميل";
            gv.Columns[nameof(InvoiceHeaderView.Total_product)].HeaderText = "اجمالي الاصناف";
            gv.Columns[nameof(InvoiceHeaderView.Discount)].HeaderText = " خصم مبلغ ";
            gv.Columns[nameof(InvoiceHeaderView.Extra)].HeaderText = "اضافة مبلغ";
            gv.Columns[nameof(InvoiceHeaderView.Net)].HeaderText = "الصافي";
            gv.Columns[nameof(InvoiceHeaderView.Notes)].HeaderText = "ملاحظات ";
            gv.Columns[nameof(InvoiceHeaderView.is_agel)].HeaderText = "اجل ";
            gv.Columns[nameof(InvoiceHeaderView.DateServer)].HeaderText = "تاريخ ";
            gv.Columns[nameof(InvoiceHeaderView.name_invoice_type)].HeaderText = "العملية";
            gv.Columns[nameof(InvoiceHeaderView.name_fara)].HeaderText = "الفرع";
            gv.Columns[nameof(InvoiceHeaderView.user_name)].HeaderText = "الموظف";
            lp_titel.Text = " بحث عن "+" " + Invoice_Type.name_invoice_type;
        }
        bool isrun = false;
        public async void getdata()
        {
            if(isrun)
                return;
            isrun = true;
            pic_login.Visible = true;
            gv.DataSource = await invoice.Serch_Invoice(tx_id.Text, IdClient.ToString(), Invoice_Type.id.ToString()+ ",5", tx_nots.Text, dr_is_agel.SelectedValue.ToString(), dr_user.SelectedValue.ToString(), dr_fara.SelectedValue.ToString(), dt_date_from.Value.Date.ToString("yyyy/MM/dd"), dt_date_to.Value.Date.ToString("yyyy/MM/dd"));
            gv.CurrentCell = null;
            lb_mas.Text = " عدد  :  " + gv.Rows.Count;
            if(Invoice_Type.ShowPrice)
            lb_mas.Text +=" --- "+" اجمالي  مبلغ الصافي  :   " + Session.Convertdecimal(gv.Rows.Cast<DataGridViewRow>().Sum(t => Convert.ToDouble(t.Cells[nameof(InvoiceHeaderView.Net)].Value)).ToString()).ToString("0.00");
            p_name_client = tx_name_cient.Text;
            p_date_from = dt_date_from.Value.ToString();
            p_date_to = dt_date_to.Value.ToString();
            pic_login.Visible = false;
            isrun=false;
        }
        int IdClient = 0;
        private void bt_aladawia_Click(object sender, EventArgs e)
        {
            selct_sick frm_Clint = new selct_sick();
            frm_Clint.ShowDialog();
            client_View client_View = frm_Clint.GetClient();
            if (client_View != null)
            {
                IdClient = client_View.id;
                tx_name_cient.Text = client_View.name;
            }
        }
        string p_name_client = "";
        string p_date_from;
        string p_date_to;
        private void bt_search_Click(object sender, EventArgs e)
        {
            getdata();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            IdClient = 0;
            tx_name_cient.Text = "";
        }
        private void gv_kushf_with_marid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {           
            if (e.RowIndex < 0)
                return;
            int id = Convert.ToInt32(gv.Rows[e.RowIndex].Cells[nameof(InvoiceHeaderView.id)].Value.ToString());
            frm_InvoiceHeader_nots kushufat = new frm_InvoiceHeader_nots(id,Invoice_Type.id);
            kushufat.ShowDialog();
            bt_search.PerformClick();
        }
        
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0)
                return;

            List<ReportParameter> para = new List<ReportParameter>();
            para.Add(new ReportParameter("p_date_from", p_date_from));
            para.Add(new ReportParameter("p_dt_date_to", p_date_to));
            para.Add(new ReportParameter("p_name_client", p_name_client));

            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("InvoiceHeaderView", gv.DataSource),
            };
            frm_show_report _Report = new frm_show_report(para, "all_InvoiceHeader", ReportDataSource, true);
            _Report.Show();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if (gv.SelectedRows.Count > 0)
            {
                int rowindex = gv.CurrentRow.Index;
                int id_invoice = Convert.ToInt32(gv.Rows[rowindex].Cells[nameof(InvoiceHeader.id)].Value.ToString());
                frm_InvoiceHeader_nots kushufat = new frm_InvoiceHeader_nots(id_invoice, (int)invoice_name.invoice_pay);
                kushufat.ShowDialog();
                bt_search.PerformClick();
            }
            else MyMessageBox.showMessage("معلومات", "يجب اختيار فاتورة اولا", "", MessageBoxButtons.RetryCancel);
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dr_fara_SelectionChangeCommitted(object sender, EventArgs e)
        {
            dr_user.IntializeData(Session.usersfara(Session.ConvertInt(dr_fara.SelectedValue.ToString())), nameof(user.user_name), nameof(user.id));
            dr_user.SelectedValue = Session.User_login.id;
            dr_user.Enabled = dr_fara.Enabled = !((Session.Accsess)Session.User_setting().AcssessStore == Session.Accsess.mowazf);
            if (dr_user.SelectedIndex == -1)
                dr_user.SelectedIndex = 0;
        }

        private void btn_export_exal_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0) return;
            lb_mas.Text = "  جاري انشاء ملف الاكسيل ...";
            var xx = (List<InvoiceHeaderView>)gv.DataSource;
            xx.ExportListToExal(" بحث بيان اسعار " + p_name_client);
            lb_mas.Text = @"تم حفظ الملف  \" + Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer" + @"\" + DateTime.Now.Ticks + "Response.xlsx" + "";
        }
    }
}
