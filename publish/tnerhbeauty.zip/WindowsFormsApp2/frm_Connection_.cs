using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using tnerhbeauty.Class;
using tnerhbeauty.Properties;

namespace tnerhbeauty
{
    public partial class frm_Connection_ : Form
    {
        private SqlConnection cnn;
        private string ConnectionString;
        private SqlConnection cn;
        public frm_Connection_()
        {
            InitializeComponent();
        }
        private void btn_new_Click(object sender, EventArgs e)
        {
            tx_ip_adress.Enabled = true;
            btn_save.Visible = false;
            btn_new.Visible = false;
            btn_test.Visible = true;
            pictureBox1.Image = null;
            label1.Text = string.Empty;
            ConnectionString = "";
        }
        private void btn_save_Click(object sender, EventArgs e)
        {
            Configuration configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ConnectionStringsSection connectionStringsSection = (ConnectionStringsSection)configuration.GetSection("connectionStrings");
            connectionStringsSection.ConnectionStrings["tnerhbeauty.Properties.Settings.DBBETTERLIFE_MDF"].ConnectionString = ConnectionString.hide_Encrypt();
            configuration.Save();
            ConfigurationManager.RefreshSection("connectionStrings");
            Settings.Default.server = dr_data.Text;
            Settings.Default.Save();
            Settings.Default.Reload();
            home home2 = Application.OpenForms.OfType<home>().SingleOrDefault();
            if (home2 != null)
            {
                home2.ts_server.Text = Settings.Default.server;
            }
            Close();
        }
        private void btn_test_Click(object sender, EventArgs e)
        {
            Match match = Regex.Match(tx_ip_adress.Text, "\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}");
            if (!match.Success)
            {
                label1.Text = "��� ����� ����� ip ���� ����";
                tx_ip_adress.Focus();
                tx_ip_adress.SelectAll();
                return;
            }
            if (dr_data.SelectedIndex == -1)
            {
                MyMessageBox.showMessage("����", "����� ������ ��������", "", MessageBoxButtons.RetryCancel);
                return;
            }
            string data = "";
            if (dr_data.SelectedIndex == 1)
                data = "x";

            ConnectionString = String.Format(@"Data Source={0};Initial Catalog={1}DBBETTERLIFE;User ID=ba;Password=ba;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False", tx_ip_adress.Text, data);
            cnn = new SqlConnection(ConnectionString);
            try
            {
                cnn.Open();
                OkConnection();
            }
            catch (SqlException ex)
            {
                pictureBox1.Image = Resources.mark;
                if (ex.Number == -1)
                {
                    label1.Text = "�� ��� ������ ��� ������� ������ ����� ����� sqlserver ��� ������";
                }
                else if (ex.Number == 15350)
                {
                    label1.Text = "�� ��� ������ ��� ����� �������� ������� ";
                }
                else if (ex.Number == 53)
                {
                    label1.Text = "����� ip  ��� ����";
                }
                else if (ex.Number == 4060)
                {
                    label1.Text = " �� ��� ������ ��� ����� �������� ��������";
                }
                else if (ex.Number == 5120)
                {
                    label1.Text = "������� ������ ���� ";
                }
            }
            finally
            {
                cnn.Close();
            }
        }
        private void OkConnection()
        {
            label1.Text = massege.successfully;
            btn_save.Visible = true;
            btn_new.Visible = true;
            pictureBox1.Visible = true;
            pictureBox1.Image = Resources.check;
            tx_ip_adress.Enabled = false;
            btn_test.Visible = false;
        }
        private void btn_login_Click(object sender, EventArgs e)
        {
            string text = DateTime.Now.ToString("ddMMyyyy");
            if (tx_pass.Text == text)
            {
                pan_password.Visible = false;
                pan_server.Visible = true;
            }
            else
            {
                lp_mas_error.Text = "��� ��� ����";
            }
        }
    }
}
