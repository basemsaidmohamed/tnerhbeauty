﻿namespace tnerhbeauty
{
    partial class Frm_CompanyInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_CompanyInfo));
            this.tx_Address = new System.Windows.Forms.TextBox();
            this.tx_Specialized_in = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tx_Name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tx_Phone = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tx_hedar = new System.Windows.Forms.TextBox();
            this.tx_footer = new System.Windows.Forms.TextBox();
            this.lb_mas = new System.Windows.Forms.Label();
            this.bt_save = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bt_clear_pic = new System.Windows.Forms.Button();
            this.bt_re_pic = new System.Windows.Forms.Button();
            this.lp_titel = new System.Windows.Forms.Label();
            this.Img_Company = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Img_Company)).BeginInit();
            this.SuspendLayout();
            // 
            // tx_Address
            // 
            this.tx_Address.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.tx_Address.Location = new System.Drawing.Point(203, 164);
            this.tx_Address.Margin = new System.Windows.Forms.Padding(2);
            this.tx_Address.Name = "tx_Address";
            this.tx_Address.Size = new System.Drawing.Size(464, 26);
            this.tx_Address.TabIndex = 3;
            // 
            // tx_Specialized_in
            // 
            this.tx_Specialized_in.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.tx_Specialized_in.Location = new System.Drawing.Point(203, 129);
            this.tx_Specialized_in.Margin = new System.Windows.Forms.Padding(2);
            this.tx_Specialized_in.Name = "tx_Specialized_in";
            this.tx_Specialized_in.Size = new System.Drawing.Size(464, 26);
            this.tx_Specialized_in.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(103, 167);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "عنوان الشركة";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(59, 132);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "معلومات اعلي الفاتورة";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(94, 204);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "تليفونات الشركة";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tx_Name
            // 
            this.tx_Name.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.errorProvider1.SetIconAlignment(this.tx_Name, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_Name.Location = new System.Drawing.Point(203, 92);
            this.tx_Name.Margin = new System.Windows.Forms.Padding(2);
            this.tx_Name.Name = "tx_Name";
            this.tx_Name.Size = new System.Drawing.Size(464, 26);
            this.tx_Name.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(125, 95);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "اسم الفرع";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tx_Phone
            // 
            this.tx_Phone.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.tx_Phone.Location = new System.Drawing.Point(203, 199);
            this.tx_Phone.Margin = new System.Windows.Forms.Padding(2);
            this.tx_Phone.Name = "tx_Phone";
            this.tx_Phone.Size = new System.Drawing.Size(464, 26);
            this.tx_Phone.TabIndex = 4;
            // 
            // errorProvider1
            // 
            this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider1.ContainerControl = this;
            this.errorProvider1.RightToLeft = true;
            // 
            // tx_hedar
            // 
            this.tx_hedar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.errorProvider1.SetIconAlignment(this.tx_hedar, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_hedar.Location = new System.Drawing.Point(203, 57);
            this.tx_hedar.Margin = new System.Windows.Forms.Padding(2);
            this.tx_hedar.Name = "tx_hedar";
            this.tx_hedar.Size = new System.Drawing.Size(464, 26);
            this.tx_hedar.TabIndex = 0;
            // 
            // tx_footer
            // 
            this.tx_footer.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.errorProvider1.SetIconAlignment(this.tx_footer, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_footer.Location = new System.Drawing.Point(203, 236);
            this.tx_footer.Margin = new System.Windows.Forms.Padding(2);
            this.tx_footer.Name = "tx_footer";
            this.tx_footer.Size = new System.Drawing.Size(464, 26);
            this.tx_footer.TabIndex = 5;
            // 
            // lb_mas
            // 
            this.lb_mas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lb_mas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_mas.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mas.ForeColor = System.Drawing.Color.White;
            this.lb_mas.Location = new System.Drawing.Point(0, 334);
            this.lb_mas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_mas.Name = "lb_mas";
            this.lb_mas.Size = new System.Drawing.Size(914, 35);
            this.lb_mas.TabIndex = 0;
            this.lb_mas.Text = "F12 = SAVE";
            this.lb_mas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_mas.UseCompatibleTextRendering = true;
            // 
            // bt_save
            // 
            this.bt_save.BackColor = System.Drawing.Color.Purple;
            this.bt_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_save.FlatAppearance.BorderSize = 0;
            this.bt_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_save.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.bt_save.ForeColor = System.Drawing.Color.White;
            this.bt_save.Location = new System.Drawing.Point(203, 282);
            this.bt_save.Margin = new System.Windows.Forms.Padding(2);
            this.bt_save.Name = "bt_save";
            this.bt_save.Size = new System.Drawing.Size(102, 31);
            this.bt_save.TabIndex = 6;
            this.bt_save.Text = "حفظ";
            this.bt_save.UseVisualStyleBackColor = false;
            this.bt_save.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(116, 60);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 19);
            this.label5.TabIndex = 56;
            this.label5.Text = "اسم الشركة";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(59, 239);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 19);
            this.label6.TabIndex = 58;
            this.label6.Text = "معلومات نهاية الفاتورة";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bt_clear_pic
            // 
            this.bt_clear_pic.BackColor = System.Drawing.Color.Transparent;
            this.bt_clear_pic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_clear_pic.FlatAppearance.BorderSize = 0;
            this.bt_clear_pic.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.bt_clear_pic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_clear_pic.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_clear_pic.ForeColor = System.Drawing.Color.IndianRed;
            this.bt_clear_pic.Location = new System.Drawing.Point(702, 266);
            this.bt_clear_pic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bt_clear_pic.Name = "bt_clear_pic";
            this.bt_clear_pic.Size = new System.Drawing.Size(23, 26);
            this.bt_clear_pic.TabIndex = 61;
            this.bt_clear_pic.TabStop = false;
            this.bt_clear_pic.Text = "X";
            this.bt_clear_pic.UseVisualStyleBackColor = false;
            this.bt_clear_pic.Click += new System.EventHandler(this.bt_clear_pic_Click);
            // 
            // bt_re_pic
            // 
            this.bt_re_pic.BackColor = System.Drawing.Color.Transparent;
            this.bt_re_pic.BackgroundImage = global::tnerhbeauty.Properties.Resources.Rotate;
            this.bt_re_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_re_pic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_re_pic.FlatAppearance.BorderSize = 0;
            this.bt_re_pic.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.bt_re_pic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_re_pic.ForeColor = System.Drawing.Color.Red;
            this.bt_re_pic.Location = new System.Drawing.Point(875, 266);
            this.bt_re_pic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bt_re_pic.Name = "bt_re_pic";
            this.bt_re_pic.Size = new System.Drawing.Size(23, 26);
            this.bt_re_pic.TabIndex = 62;
            this.bt_re_pic.TabStop = false;
            this.bt_re_pic.UseVisualStyleBackColor = false;
            this.bt_re_pic.Click += new System.EventHandler(this.bt_re_pic_Click);
            // 
            // lp_titel
            // 
            this.lp_titel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lp_titel.Dock = System.Windows.Forms.DockStyle.Top;
            this.lp_titel.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold);
            this.lp_titel.ForeColor = System.Drawing.Color.White;
            this.lp_titel.Image = global::tnerhbeauty.Properties.Resources.setting_cogwheel;
            this.lp_titel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp_titel.Location = new System.Drawing.Point(0, 0);
            this.lp_titel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_titel.Name = "lp_titel";
            this.lp_titel.Size = new System.Drawing.Size(914, 39);
            this.lp_titel.TabIndex = 60;
            this.lp_titel.Text = "بيانات الشركة";
            this.lp_titel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Img_Company
            // 
            this.Img_Company.BackColor = System.Drawing.Color.Transparent;
            this.Img_Company.BackgroundImage = global::tnerhbeauty.Properties.Resources.imgcompany;
            this.Img_Company.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Img_Company.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Img_Company.Image = global::tnerhbeauty.Properties.Resources.imgcompany;
            this.Img_Company.ImageLocation = "";
            this.Img_Company.Location = new System.Drawing.Point(698, 57);
            this.Img_Company.Margin = new System.Windows.Forms.Padding(2);
            this.Img_Company.Name = "Img_Company";
            this.Img_Company.Size = new System.Drawing.Size(204, 204);
            this.Img_Company.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Img_Company.TabIndex = 33;
            this.Img_Company.TabStop = false;
            this.Img_Company.Click += new System.EventHandler(this.img_prodct_Click);
            // 
            // Frm_CompanyInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(914, 369);
            this.Controls.Add(this.bt_clear_pic);
            this.Controls.Add(this.bt_re_pic);
            this.Controls.Add(this.lp_titel);
            this.Controls.Add(this.tx_footer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tx_hedar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bt_save);
            this.Controls.Add(this.lb_mas);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tx_Address);
            this.Controls.Add(this.tx_Phone);
            this.Controls.Add(this.Img_Company);
            this.Controls.Add(this.tx_Specialized_in);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tx_Name);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Frm_CompanyInfo";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Company Info";
            this.Load += new System.EventHandler(this.frm_CompanyInfo_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Frm_CompanyInfo_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Img_Company)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tx_Address;
        private System.Windows.Forms.TextBox tx_Specialized_in;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tx_Name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tx_Phone;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label lb_mas;
        private System.Windows.Forms.PictureBox Img_Company;
        private System.Windows.Forms.Button bt_save;
        private System.Windows.Forms.TextBox tx_hedar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tx_footer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lp_titel;
        private System.Windows.Forms.Button bt_clear_pic;
        private System.Windows.Forms.Button bt_re_pic;
    }
}