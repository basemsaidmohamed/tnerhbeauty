﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;
using static tnerhbeauty.Class.invoice;
using static tnerhbeauty.Class.Session;


namespace tnerhbeauty
{

    public partial class frm_InvoiceHeader_nots : Form
    {
        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, Int32 wMsg, bool wParam, Int32 lParam);
        const int WM_PARENTNOTIFY = 0x210;
        const int WM_LBUTTONDOWN = 0x201;
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_LBUTTONDOWN || (m.Msg == WM_PARENTNOTIFY &&
                (int)m.WParam == WM_LBUTTONDOWN))
                if (!tx_ItemName.ClientRectangle.Contains(tx_ItemName.PointToClient(Cursor.Position)) && !gvSerchProduct.ClientRectangle.Contains(gvSerchProduct.PointToClient(Cursor.Position)))
                {
                    gvSerchProduct.Hide();
                    if (Producselct == null || Producselct.fullname != tx_ItemName.Text)
                    {
                        tx_Price.Text = "";
                        tx_TotalPrice_ditals.Text = "";
                        tx_ItemName.Text = "";
                        tx_total_item.Text = "";
                        lb_balance.Text = "";
                        Producselct = null;
                    }

                }
            base.WndProc(ref m);
        }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;  // Turn on WS_EX_COMPOSITED
                return cp;
            }
        }
        product_serch_View Producselct;
        DataClasses1DataContext dbs;
        DataClasses1DataContext db;
        InvoiceHeader invoiceHeader;
        BindingSource bs;
        List<InvoiceDetail> InvoiceDetail_old;
        List<product_serch_View> dataprodcut = new List<product_serch_View>(getallprodct.ToList());
        bool updateid = false;
        decimal kilo = 1;
        int client_save;
        int id_InvoiceHeader = 0;
        string _nots = "";
        string istx_ItemQty = "";
        bool isranning;
        bool is_agel;
        int IDTypeInvoice;
        invoice_type Invoice_Type;
        client_View client_View;
        bool IsUupdateNote = false;

        public frm_InvoiceHeader_nots(int _type)
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            IDTypeInvoice = _type;
        }
        public frm_InvoiceHeader_nots(int _id, int _type)
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            IDTypeInvoice = _type;
            id_InvoiceHeader = _id;
        }
        private void frm_kushufat_Load(object sender, EventArgs e)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                Invoice_Type = new invoice_type();
                Invoice_Type = invoice.GetInvoiceType(IDTypeInvoice);
                PanClient.Visible = Invoice_Type.showClient;
                PanPrice.Visible = Invoice_Type.ShowPrice;
                PanTotal.Visible = Invoice_Type.ShowPrice;
                dr_store_to.Visible = Invoice_Type.DrToStore;
                lpstore_to.Visible = Invoice_Type.DrToStore;
                InitializeGvInvoiceDetails();
                InvoicAccess();

            }));
        }
        private void frm_InvoiceHeader_nots_Shown(object sender, EventArgs e)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                ch_kilo.Checked = Properties.Settings.Default.ch_kilo;
                kilo = ch_kilo.Checked ? 1000 : 1;
                ch_auto_insert.Checked = Properties.Settings.Default.ch_auto_insert;
                ch_not_celar_ItemQty.Checked = Properties.Settings.Default.ch_not_celar_ItemQty;
                dr_discunt_item.SelectedIndex = Properties.Settings.Default.dr_discunt_item;
                LoadData();
            }));
        }

        void LoadData()
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                dr_price.IntializeData(Session.list_price, nameof(list_price.name_row), nameof(list_price.id));
                if (User_setting().invoice_agel)
                    is_agel = Properties.Settings.Default.ch_is_agel;
                client_save = Invoice_Type.showClient ? Properties.Settings.Default.id_client : 0;
                //ch_notes.Visible = Invoice_Type.DrToStore;
                InitializeClass();
                InitializeGvSerchProduct();
                GetDataProdct();
                GetStore();
                GetData();

            }));
        }
        void InitializeClass()
        {
            dbs = new DataClasses1DataContext();
            db = new DataClasses1DataContext();
            invoiceHeader = new InvoiceHeader();
            bs = new BindingSource();
            InvoiceDetail_old = new List<InvoiceDetail>();
        }
        void GetDataProdct()
        {
            dataprodcut = getallprodct.ToList();
            if (dataprodcut.Count == 0)
            {
                MyMessageBox.showMessage("لا يوجد اصناف مسجلة", "يجب اضافة اصناف اولا", "", MessageBoxButtons.RetryCancel);
            }
            DrItemID.DataSource = dataprodcut;
            DrItemID.DataPropertyName = nameof(InvoiceDetail.ItemID);
            DrItemID.DisplayMember = nameof(product_serch_View.fullname);
            DrItemID.ValueMember = nameof(product_serch_View.id);
        }
        void GetStore()
        {
            dr_store.IntializeData(cproduct.StoreUser, nameof(store.store_name), nameof(store.id));

            dr_store_to.IntializeData(Store, nameof(store.store_name), nameof(store.id));
            DrStore_id.DataSource = Store;
            DrStore_id.DataPropertyName = nameof(InvoiceDetail.store_id);
            DrStore_id.DisplayMember = nameof(store.store_name);
            DrStore_id.ValueMember = nameof(store.id);
        }
        void InitializeGvSerchProduct()
        {
            gvSerchProduct.DataSource = new List<product_serch_View>();
            gvSerchProduct.Columns[nameof(product_serch_View.name)].HeaderText = "اسم الصنف";
            gvSerchProduct.Columns[nameof(product_serch_View.price_sale)].HeaderText = "السعر";
            gvSerchProduct.Columns[nameof(product_serch_View.Balance)].HeaderText = "الكمية";
            gvSerchProduct.Columns[nameof(product_serch_View.store_name)].HeaderText = "المخزن";
            gvSerchProduct.Columns[nameof(product_serch_View.code)].HeaderText = "كود الصنف";

            gvSerchProduct.Columns[nameof(product_serch_View.name)].Width = 200;
            gvSerchProduct.Columns[nameof(product_serch_View.id)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_sale)].Visible = Invoice_Type.ShowPrice;
            gvSerchProduct.Columns[nameof(product_serch_View.price_buy)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_sale_100)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_sale_75)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_sale_vip2)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_sale_vip1)].Visible = false;

            gvSerchProduct.Columns[nameof(product_serch_View.price_1)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_2)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_3)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_4)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_5)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_6)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_7)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_8)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_9)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.price_10)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.is_stop)].Visible = false;
            //gvSerchProduct.Columns[nameof(product_serch_View.Balance)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.update_price)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.fullname)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.store_id)].Visible = false;
            gvSerchProduct.Columns[nameof(product_serch_View.min_mum)].Visible = false;
            gvSerchProduct.AutoSize = true;
        }
        void InitializeGvInvoiceDetails()
        {

            //DrItemID.DataSource = dataprodcut;
            //DrItemID.DataPropertyName = nameof(InvoiceDetail.ItemID);
            //DrItemID.DisplayMember = nameof(product_serch_View.fullname);
            //DrItemID.ValueMember = nameof(product_serch_View.id);

            //DrStore_id.DataSource = Store;
            //DrStore_id.DataPropertyName = nameof(InvoiceDetail.store_id);
            //DrStore_id.DisplayMember = nameof(store.store_name);
            //DrStore_id.ValueMember = nameof(store.id);

            gv_InvoiceDetails.DataSource = new List<InvoiceDetail>();
            gv_InvoiceDetails.Columns.Cast<DataGridViewColumn>().ToList().ForEach(f => f.SortMode = DataGridViewColumnSortMode.NotSortable);
            gv_InvoiceDetails.AutoGenerateColumns = false;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.id)].Visible = false;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.store_id)].Visible = false;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.InvoiceHeaderID)].Visible = false;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.InvoiceHeader)].Visible = false;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Price)].Visible = Invoice_Type.ShowPrice;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.TotalPrice)].Visible = Invoice_Type.ShowPrice;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Discount)].Visible = Invoice_Type.ShowPrice;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Total)].Visible = Invoice_Type.ShowPrice;

            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.ItemID)].Visible = false;
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.ItemQty)].HeaderText = "الكمية";
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Price)].HeaderText = "السعر";
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.TotalPrice)].HeaderText = "الاجمالي";
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Discount)].HeaderText = "خصم ";
            gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Total)].HeaderText = "الصافي";
            gv_InvoiceDetails.Columns[DrItemID.Name].DisplayIndex = 0;
            gv_InvoiceDetails.Columns[DrStore_id.Name].DisplayIndex = gv_InvoiceDetails.Columns.Count - 1;
            gv_InvoiceDetails.Columns[deleteitem.Name].DisplayIndex = gv_InvoiceDetails.Columns.Count - 1;
            gv_InvoiceDetails.Columns[deleteitem.Name].Width = 38;
            gv_InvoiceDetails.CurrentCell = null;

        }
        void SetDataInvoiceHeader()
        {
            invoiceHeader.id_cient = null;
            if (Invoice_Type.showClient)
                invoiceHeader.id_cient = Convert.ToInt32(tx_id_cient.Text);

            invoiceHeader.Discount_type = dr_Discount_type.SelectedIndex;
            invoiceHeader.Discount_percent = Convertdecimal(tx_Discount_percent.Text);
            invoiceHeader.Discount = Convertdecimal(tx_Discount.Text);

            invoiceHeader.Extra_type = dr_Extra_type.SelectedIndex;
            invoiceHeader.Extra_percent = Convertdecimal(tx_Extra_percent.Text);
            invoiceHeader.Extra = Convertdecimal(tx_Extra.Text);

            invoiceHeader.Total_product = Convertdecimal(tx_Total_product.Text);
            invoiceHeader.Net = Convertdecimal(tx_Net.Text);
            invoiceHeader.Notes = tx_Notes.Text.Replace_text();
            invoiceHeader.DateAdd = tx_DateAdd.Value;
            invoiceHeader.is_agel = ch_is_agel.Checked;
            invoiceHeader.id_invoice_type = ch_notes.Checked ? 5 : IDTypeInvoice;
            invoiceHeader.id_user = User_login.id;
            invoiceHeader.id_fara = User_login.id_fara;
            invoiceHeader.DateServer = invoiceHeader.id != 0 ? invoiceHeader.DateServer : GetDate();
            invoiceHeader.store_logs = AddToStore();
            invoiceHeader.InvoiceDetails = (EntitySet<InvoiceDetail>)bs.DataSource;
            if (IsUupdateNote == true && invoiceHeader.id_invoice_type != 5)
                invoiceHeader.DateServer = GetDate();
        }
        void GetData()
        {
            if (id_InvoiceHeader != 0)
                invoiceHeader = dbs.InvoiceHeaders.FirstOrDefault(c => c.id == id_InvoiceHeader);

            if (invoiceHeader == null)
                invoiceHeader = new InvoiceHeader();

            CelarAddProudct();
            clearClient();
            TxTotalQty.Text = "0.000";
            //bs.DataSource = DBDetails.InvoiceDetails.Where(x => x.InvoiceHeaderID == invoiceHeader.id);

            gv_InvoiceDetails.DataSource = bs.DataSource = invoiceHeader.InvoiceDetails;
            tx_id_cient.Text = Invoice_Type.showClient ? invoiceHeader.id != 0 ? invoiceHeader.id_cient.ToString() : client_save.ToString() : null;
            dr_Discount_type.SelectedIndex = invoiceHeader.Discount_type;
            tx_Discount_percent.Text = invoiceHeader.Discount_percent.ToString();
            tx_Discount.Text = invoiceHeader.Discount.ToString("0.00");
            dr_Extra_type.SelectedIndex = invoiceHeader.Extra_type;
            tx_Extra_percent.Text = invoiceHeader.Extra_percent.ToString();
            tx_Extra.Text = invoiceHeader.Extra.ToString("0.00");
            tx_Total_product.Text = invoiceHeader.Total_product.ToString("0.00");
            tx_Net.Text = invoiceHeader.Net.ToString("0.00");
            tx_Notes.Text = invoiceHeader.Notes;
            tx_DateAdd.Value = invoiceHeader.id != 0 ? invoiceHeader.DateAdd : DateTime.Now;
            dr_price.SelectedIndex = Invoice_Type.showClient ? -1 : 0;
            dr_store_to.SelectedIndex = -1;
            ch_is_agel.Checked = invoiceHeader.id != 0 ? invoiceHeader.is_agel : is_agel;
            ch_notes.Checked = invoiceHeader.id_invoice_type == 5;
            lp_titel.Text = invoiceHeader.id == 0 ? $"{Invoice_Type.name_invoice_type} جديد" : $"تعديل {Invoice_Type.name_invoice_type}";
            GetClient();
            if (invoiceHeader.id != 0)
            {
                InvoiceDetail_old = bs.Cast<InvoiceDetail>().GroupBy(x => new { x.ItemID, x.store_id }).Select(cl => new InvoiceDetail
                {
                    ItemID = cl.First().ItemID,
                    ItemQty = (decimal?)cl.Sum(x => x.ItemQty) ?? 0,
                    store_id = cl.First().store_id,
                }).ToList();
                if (Invoice_Type.DrToStore && invoiceHeader.id_invoice_type != 5)
                    dr_store_to.SelectedValue = db.store_logs.Where(x => x.Source_Id == invoiceHeader.id && x.ItemQty_in > 0).FirstOrDefault().store_id;
                ch_notes.Visible = invoiceHeader.id_invoice_type == 5;
                IsUupdateNote = invoiceHeader.id_invoice_type == 5;
                updateid = true;
            }
            tx_ItemName.Focus();

        }
        void InvoicAccess()
        {
            btn_print.Visible = id_InvoiceHeader == 0 ? false : User_setting().invoice_print;
            tx_DateAdd.Visible = label2.Visible = User_setting().invoice_date;
            pan_Balance_client.Visible = lp_Balance_client.Visible = User_setting().invoice_show_Balance_client;
            dr_price.Enabled = User_setting().invoice_chang_list_price_client;


            switch ((invoice_name)Invoice_Type.id)
            {
                //بيع
                case invoice_name.invoice_pay:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_pay;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_pay : User_setting().update_invoice_pay;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_pay : false;
                    dr_discunt_item.Visible = tx_discunt_item.Visible = tx_total_item.Visible = lp_total_item.Visible = User_setting().Discount_item_invoice_pay;
                    gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Discount)].Visible = User_setting().Discount_item_invoice_pay;
                    pan_Discount.Visible = User_setting().Discount_invoice_pay;
                    pan_Extra.Visible = User_setting().Extra_invoice_pay;
                    tx_Price.ReadOnly = !User_setting().invoice_chang_price;
                    if (id_InvoiceHeader == 0)
                        pan_is_agel.Visible = User_setting().invoice_agel;
                    break;
                //مشتريات
                case invoice_name.invoice_sale:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_sale;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_sale : User_setting().update_invoice_sale;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_sale : false;
                    dr_discunt_item.Visible = tx_discunt_item.Visible = tx_total_item.Visible = lp_total_item.Visible = User_setting().Discount_item_invoice_sale;
                    gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Discount)].Visible = User_setting().Discount_item_invoice_sale;
                    pan_Discount.Visible = User_setting().Discount_invoice_sale;
                    pan_Extra.Visible = User_setting().Extra_invoice_sale;
                    if (id_InvoiceHeader == 0)
                        pan_is_agel.Visible = User_setting().invoice_agel;
                    break;
                //مرتجع الي المصنع
                case invoice_name.invoice_return_to_supplier:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_return_to_supplier;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_return_to_supplier : User_setting().update_invoice_return_to_supplier;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_return_to_supplier : false;
                    dr_discunt_item.Visible = tx_discunt_item.Visible = tx_total_item.Visible = lp_total_item.Visible = User_setting().Discount_item_invoice_return_to_supplier;
                    gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Discount)].Visible = User_setting().Discount_item_invoice_return_to_supplier;
                    pan_Discount.Visible = User_setting().Discount_invoice_return_to_supplier;
                    pan_Extra.Visible = User_setting().Extra_invoice_return_to_supplier;
                    tx_Price.ReadOnly = !User_setting().invoice_chang_price;
                    if (id_InvoiceHeader == 0)
                        pan_is_agel.Visible = User_setting().invoice_agel;
                    break;
                //مرتجع من العميل
                case invoice_name.invoice_return_from_client:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_return_from_client;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_return_from_client : User_setting().update_invoice_return_from_client;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_return_from_client : false;
                    dr_discunt_item.Visible = tx_discunt_item.Visible = tx_total_item.Visible = lp_total_item.Visible = User_setting().Discount_item_invoice_return_from_client;
                    gv_InvoiceDetails.Columns[nameof(InvoiceDetail.Discount)].Visible = User_setting().Discount_item_invoice_return_from_client;
                    pan_Discount.Visible = User_setting().Discount_invoice_return_from_client;
                    pan_Extra.Visible = User_setting().Extra_invoice_return_from_client;
                    if (id_InvoiceHeader == 0)
                        pan_is_agel.Visible = User_setting().invoice_agel;
                    break;
                // بيع من مخزن
                case invoice_name.invoice_pay_from_store:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_pay_from_store;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_pay_from_store : User_setting().update_invoice_pay_from_store;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_pay_from_store : false;
                    pan_Balance_client.Visible = lp_Balance_client.Visible = User_setting().invoice_show_Balance_client;
                    ch_is_agel.Checked = true;
                    break;
                //تحويل الي مخزن
                case invoice_name.invoice_to_store:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_to_store;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_to_store : User_setting().update_invoice_to_store;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_to_store : false;
                    ch_is_agel.Checked = false;
                    break;

                //تسوية اضافة
                case invoice_name.invoice_taswet_edafa:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_taswet_edafa;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_taswet_edafa : User_setting().update_invoice_taswet_edafa;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_taswet_edafa : false;
                    ch_is_agel.Checked = false;
                    break;
                // تسوية خصم
                case invoice_name.invoice_taswiat_khasm:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_taswiat_khasm;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_taswiat_khasm : User_setting().update_invoice_taswiat_khasm;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_taswiat_khasm : false;
                    ch_is_agel.Checked = false;
                    break;
                case invoice_name.invoice_broken:
                    btn_delete.Visible = id_InvoiceHeader == 0 ? false : User_setting().delete_invoice_broken;
                    btn_save.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_broken : User_setting().update_invoice_broken;
                    btn_new.Visible = id_InvoiceHeader == 0 ? User_setting().add_invoice_broken : false;
                    ch_is_agel.Checked = false;
                    break;

            }
            if (pan_Discount.Visible == false && pan_Extra.Visible == false)
                pan_Total_product.Visible = false;
            else pan_Total_product.Visible = true;
        }
        void GetClient()
        {
            if (tx_id_cient.Text != "0" && Invoice_Type.showClient)
            {
                client_View = Client_Views.Where(x => x.id == ConvertInt(tx_id_cient.Text)).FirstOrDefault();

                SetClient();
                if (invoiceHeader.id == 0 && client_save != 0)
                {
                    if (tx_name_cient.Text == "")
                    {
                        Properties.Settings.Default.id_client = 0;
                        Properties.Settings.Default.Save();
                    }
                }
            }
        }
        void clearClient()
        {
            tx_name_cient.Text = "";
            dr_price.SelectedValue = "";
            tx_Balance.Text = "";
            tx_Balance_type.Text = "";
        }
        private void btn_find_client_Click(object sender, EventArgs e)
        {
            selct_sick frm_Clint = new selct_sick();
            frm_Clint.ShowDialog();
            client_View = frm_Clint.GetClient();           
            SetClient();
            if (client_View != null)
                dr_price_SelectionChangeCommitted(null, null);
        }
        private void SetClient()
        {
            if (client_View != null)
            {
                tx_id_cient.Text = client_View.id.ToString();
                tx_name_cient.Text = client_View.name;
                dr_price.SelectedValue = client_View.list_price;
                tx_Balance.Text = client_View.Balance.ToString();
                tx_Balance_type.Text = client_View.Balance_type;                
            }
        }


        bool valid()
        {
            gv_InvoiceDetails.CurrentCell = null;
            errorProvider1.Clear();
            int error = 0;
            if (string.IsNullOrEmpty(tx_name_cient.Text.Trim()) && Invoice_Type.showClient)
            {
                errorProvider1.SetError(tx_name_cient, "يجب اختار العميل");
                error++;
            }
            if (Invoice_Type.ShowPrice)
            {
                if (string.IsNullOrEmpty(tx_Total_product.Text.Trim()) || ConvertDouble(tx_Total_product.Text) <= 0)
                {
                    errorProvider1.SetError(tx_Total_product, "يجب اضافة اصناف للفاتورة");
                    errorProvider1.SetError(TxTotalQty, "يجب اضافة اصناف للفاتورة");
                    error++;
                }
                if (string.IsNullOrEmpty(tx_Net.Text.Trim()) || ConvertDouble(tx_Net.Text) <= 0)
                {
                    errorProvider1.SetError(tx_Net, "يجب ان تكون القيمة اكبر من صفر");
                    error++;
                }
            }
            if (!ch_notes.Checked)
            {
                if (dr_store_to.SelectedIndex == -1 && Invoice_Type.DrToStore)
                {
                    errorProvider1.SetError(dr_store_to, "يجب اختيار المخزن التحويل");
                    error++;
                }
                if (Invoice_Type.DrToStore && dr_store_to.SelectedIndex != -1)
                {
                    for (int i = 0; i < gv_InvoiceDetails.Rows.Count; i++)
                    {
                        int storeid = Session.ConvertInt(gv_InvoiceDetails.Rows[i].Cells[nameof(InvoiceDetail.store_id)].Value.ToString());
                        if (Session.ConvertInt(dr_store_to.SelectedValue.ToString()) == storeid)
                        {
                            gv_InvoiceDetails.Rows[i].Cells[nameof(DrStore_id)].Style.BackColor = Color.Red;
                            errorProvider1.SetError(dr_store_to, "لا يمكن التحويل لنفس المخزن");
                            error++;
                        }
                    }
                }
            }
            return error == 0;
        }
        bool CheckBalance()
        {
            string StError = "";
            int CountError = 0;
            if (!updateid && ((type_qty)Invoice_Type.type_qty == type_qty.Qty_in || ch_notes.Checked))
            {
                return true;
            }
            if ((type_qty)Invoice_Type.type_qty == type_qty.Qty_in && invoiceHeader.id_invoice_type == 5)
            {
                return true;
            }
            if (updateid && ch_notes.Checked)
            {
                return invoice.ChekAndDeleteStoreAndAmount(invoiceHeader.id);
            }

            var list = bs.Cast<InvoiceDetail>().GroupBy(x => new { x.ItemID, x.store_id }).Select(cl => new InvoiceDetail
            {
                ItemID = cl.First().ItemID,
                ItemQty = (decimal?)cl.Sum(x => x.ItemQty) ?? 0,
                store_id = cl.First().store_id,
            }).ToList();

            if ((type_qty)Invoice_Type.type_qty == type_qty.Qty_out)
            {
                foreach (InvoiceDetail item in list)
                {
                    store_log_View _prod = new store_log_View();
                    if (invoiceHeader.id == 0 || (IsUupdateNote && !ch_notes.Checked))
                        _prod = db.store_log_Views.Where(x => (x.ItemID == item.ItemID) && (x.store_id == item.store_id))
                        .GroupBy(x => new { x.ItemID, x.store_id }).Select(cl => new store_log_View
                        {
                            store_id = cl.First().store_id,
                            ItemID = cl.First().ItemID,
                            code = cl.First().code,
                            product_name = cl.First().product_name,
                            Balance = (decimal?)cl.Sum(x => x.Balance) ?? 0,
                            store_name = cl.First().store_name,
                        }).FirstOrDefault();
                    else
                        _prod = db.store_log_Views.Where(x => (x.ItemID == item.ItemID) && (x.store_id == item.store_id) && (x.Source_Id < invoiceHeader.id))
                        .GroupBy(x => new { x.ItemID, x.store_id }).Select(cl => new store_log_View
                        {
                            store_id = cl.First().store_id,
                            ItemID = cl.First().ItemID,
                            code = cl.First().code,
                            product_name = cl.First().product_name,
                            Balance = (decimal?)cl.Sum(x => x.Balance) ?? 0,
                            store_name = cl.First().store_name,
                        }).FirstOrDefault();
                    if (_prod != null)
                    {
                        if (item.ItemQty > _prod.Balance)
                        {
                            CountError++;
                            StError += _prod.product_name + " " + _prod.store_name + " " + "اكبر كمية بيع" + " " + _prod.Balance + "\n";
                        }
                    }
                    else
                    {
                        StError += " لا يوجد رصيد من " + Get_ProductPyId(item.ItemID).fullname + "\n";
                        CountError++;
                    }
                }
            }

            if (updateid && (type_qty)Invoice_Type.type_qty == type_qty.Qty_in && !ch_notes.Checked)
            {
                var oldinvo = db.AfterUpdateQty_IN_Views.Where(x => x.Source_Id == invoiceHeader.id).ToList();
                if (oldinvo.Count > 0)
                {
                    foreach (AfterUpdateQty_IN_View _prod in oldinvo)
                    {
                        var item = list.Where(x => (x.ItemID == _prod.ItemID) && (x.store_id == _prod.store_id)).FirstOrDefault();
                        if (item == null || item.ItemQty < _prod.Balance)
                        {
                            CountError++;
                            StError += _prod.product_name + _prod.store_name + " " + _prod.Balance.ToString() + " " + "\n";
                        }
                    }
                }


            }
            if (CountError > 0)
            {
                MyMessageBox.showMessage("تاكيد", StError, "", MessageBoxButtons.RetryCancel);
            }
            return (CountError == 0);
        }
        private void btn_save_Click(object sender, EventArgs e)
        {
            if (Invoice_Type.id != (int)invoice_name.invoice_pay_from_store)
                if (!User_setting().invoice_agel && ch_is_agel.Checked)
                {
                    MyMessageBox.showMessage("تاكيد", "ليس لديك صلاحيات للعمل علي فاتورة اجل", "", MessageBoxButtons.RetryCancel);
                    return;
                }
            if (updateid)
                if (checkUpdate(type_.update, invoiceHeader.DateServer, invoiceHeader.id_user))
                    return;
            if (!valid())
                return;
            //if (!CheckBalance())
            //    return;

            _nots = Invoice_Type.name_invoice_type + " ";
            if (Invoice_Type.showClient)
                _nots += ch_is_agel.Checked ? " اجل " : " نقدي ";
            _nots += " " + tx_name_cient.Text + " " + User_login.user_name + " " + User_login.name_fara;


            var nocheck =( (invoiceHeader.id == 0 && (type_qty)Invoice_Type.type_qty == type_qty.Qty_in) ||
                (invoiceHeader.id == 0 && ch_notes.Checked) ||
                                  (IsUupdateNote&& ch_notes.Checked)||
                                  (IsUupdateNote && (type_qty)Invoice_Type.type_qty == type_qty.Qty_in));



                if (dbs.Connection.State != ConnectionState.Open)
                dbs.Connection.Open();
            dbs.Transaction = dbs.Connection.BeginTransaction(IsolationLevel.ReadUncommitted);
            try
            {
                var ch = new List<negative_product_View>();               
                if (IsUupdateNote && !ch_notes.Checked)
                {
                    invoiceHeader = new InvoiceHeader();
                    SetDataInvoiceHeader();
                    dbs.InvoiceHeaders.InsertOnSubmit(invoiceHeader);
                    dbs.SubmitChanges();
                    dbs.deleteInvoiceHeaderANDamount_client(id_InvoiceHeader);
                }
                else
                {
                    SetDataInvoiceHeader();
                    if (invoiceHeader.id == 0)
                    {
                        dbs.InvoiceHeaders.InsertOnSubmit(invoiceHeader);
                    }
                    else
                    {
                        //if (updateid && !ch_notes.Checked)
                        dbs.DeleteStoreAndAmount(invoiceHeader.id);
                    }
                }
                dbs.SubmitChanges();

                if (!nocheck)
                ch = dbs.negative_product_Views.ToList();
                if (ch.Count == 0)
                {
                    updatePriceBuy();
                    AddAmountClient();
                    AddAllamount();
                    dbs.SubmitChanges();
                    dbs.Transaction.Commit();
                }
                else
                {
                    dbs.Transaction.Rollback();
                    string ids = string.Join("\n", ch.Select(x => "فاتورة رقم" + " " + x.Source_Id + " " + "صنف" + " " + x.product_name + " " + x.Balance + " ").ToArray());
                    MyMessageBox.showMessage("لا يمكن تعديل الفاتورة ارصده سالبه", ids, "", MessageBoxButtons.RetryCancel);
                    return;
                }
            }
            catch (Exception ex)
            {
                if (dbs.Transaction != null)
                {
                    dbs.Transaction.Rollback();
                    dbs.Transaction.Dispose();
                    dbs.Transaction = null;
                }
                massege.ExptionAnthetTime.MsgError();
                return;
            }
            finally
            {
                if (dbs.Transaction != null)
                {
                    dbs.Transaction.Dispose();
                }
            }
            if (updateid)
            {
                this.Close();
                return;
            }
            btn_new.PerformClick();
            lb_mas.Text = massege.successfully;
        }
        void updatePriceBuy()
        {
            if (ch_notes.Checked)
                return;
            if (!Invoice_Type.updatePriceBuy)
                return;
            if (User_setting().invoice_AutoUpdatePrice == (int)AutoUpdatePrice.Stop)
                return;
            if (User_setting().invoice_AutoUpdatePrice == (int)AutoUpdatePrice.Ask)
                if (MyMessageBox.showMessage("تاكيد", "هل تريد تحديث  سعر  الشراء للاصناف المدرجة بناء علي هذه الاسعار ", "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                    return;
            DataClasses1DataContext data = new DataClasses1DataContext();
            foreach (DataGridViewRow item in gv_InvoiceDetails.Rows)
            {
                int ItemID = ConvertInt(item.Cells[nameof(InvoiceDetail.ItemID)].Value.ToString());
                double price = ConvertDouble(item.Cells[nameof(InvoiceDetail.Price)].Value.ToString());
                double Discount = ConvertDouble(item.Cells[nameof(InvoiceDetail.Discount)].Value.ToString());
                double total = price - Discount;
                dbs.ExecuteCommand("UPDATE product SET update_price = GETDATE(), price_buy = " + total + " WHERE id = " + ItemID + "");
            }

        }
        private EntitySet<store_log> AddToStore()
        {
            EntitySet<store_log> list_store_Log = new EntitySet<store_log>();
            if (ch_notes.Checked)
                return list_store_Log;
            foreach (DataGridViewRow item in gv_InvoiceDetails.Rows)
            {
                decimal qty = Convertdecimal(item.Cells[nameof(InvoiceDetail.ItemQty)].Value.ToString());
                string storename = item.Cells[nameof(DrStore_id)].FormattedValue.ToString();

                list_store_Log.Add(new store_log
                {
                    ItemID = ConvertInt(item.Cells[nameof(InvoiceDetail.ItemID)].Value.ToString()),
                    ItemQty_out = (type_qty)Invoice_Type.type_qty == type_qty.Qty_out ? qty : 0,
                    ItemQty_in = (type_qty)Invoice_Type.type_qty == type_qty.Qty_in ? qty : 0,
                    nots = Invoice_Type.DrToStore ? " تحويل صادر من " + item.Cells[nameof(DrStore_id)].FormattedValue.ToString() + " الي " + dr_store_to.Text : _nots.Replace_text() + " " + storename,
                    DateAdd = invoiceHeader.DateServer,
                    Source_Id = invoiceHeader.id,
                    id_type = invoiceHeader.id_invoice_type,
                    store_id = ConvertInt(item.Cells[nameof(InvoiceDetail.store_id)].Value.ToString()),
                    id_fara = invoiceHeader.id_fara,
                    id_user = invoiceHeader.id_user,
                });
            }
            if (Invoice_Type.DrToStore)
            {
                int _id_fara = Session.Store.Where(x => x.id == ConvertInt(dr_store_to.SelectedValue.ToString())).FirstOrDefault().id_fara;
                foreach (DataGridViewRow item in gv_InvoiceDetails.Rows)
                {
                    decimal qty = Convertdecimal(item.Cells[nameof(InvoiceDetail.ItemQty)].Value.ToString());
                    list_store_Log.Add(new store_log
                    {
                        ItemID = ConvertInt(item.Cells[nameof(InvoiceDetail.ItemID)].Value.ToString()),
                        ItemQty_out = (type_qty)Invoice_Type.type_qty == type_qty.Qty_in ? qty : 0,
                        ItemQty_in = (type_qty)Invoice_Type.type_qty == type_qty.Qty_out ? qty : 0,
                        nots = " تحويل وارد من " + (item.Cells[nameof(DrStore_id)] as DataGridViewComboBoxCell).FormattedValue.ToString() + " الي " + dr_store_to.Text,
                        DateAdd = invoiceHeader.DateServer,
                        //Source_Id = invoiceHeader.id,
                        id_type = invoiceHeader.id_invoice_type,
                        store_id = ConvertInt(dr_store_to.SelectedValue.ToString()),
                        id_fara = _id_fara,
                        id_user = invoiceHeader.id_user,
                    });
                }
            }
            //db_store_Log.store_logs.InsertAllOnSubmit(list_store_Log);
            //db_store_Log.SubmitChanges();
            return list_store_Log;
        }
        private void AddAmountClient()
        {
            if (ch_notes.Checked)
                return;
            if (!Invoice_Type.showClient)
                return;
            amount_client amount_Client = new amount_client();
            if (invoiceHeader.is_agel)
            {
                if ((type_qty)Invoice_Type.type_qty == type_qty.Qty_in)
                {
                    amount_Client.amount_in = invoiceHeader.Net;
                    amount_Client.amount_out = 0;
                }
                if ((type_qty)Invoice_Type.type_qty == type_qty.Qty_out)
                {
                    amount_Client.amount_in = 0;
                    amount_Client.amount_out = invoiceHeader.Net;
                }
            }
            else
            {
                amount_Client.amount_in = invoiceHeader.Net;
                amount_Client.amount_out = invoiceHeader.Net;
            }
            amount_Client.id_account = invoiceHeader.id_invoice_type;
            amount_Client.id_client = ConvertInt(invoiceHeader.id_cient.ToString());
            amount_Client.nots = _nots;
            amount_Client.DateAdd = invoiceHeader.DateAdd;
            amount_Client.Source_Id = invoiceHeader.id;
            amount_Client.id_fara = invoiceHeader.id_fara;
            amount_Client.id_user = invoiceHeader.id_user;
            amount_Client.DateServer = invoiceHeader.DateServer;
            dbs.amount_clients.InsertOnSubmit(amount_Client);
            //db.SubmitChanges();
        }
        private void AddAllamount()
        {
            AllAmount _AllAmount = new AllAmount();
            _AllAmount.amount = invoiceHeader.Net;
            _AllAmount.id_account = ch_notes.Checked ? 5 : Invoice_Type.Account;
            if (!ch_notes.Checked)
                _AllAmount.id_cash = invoiceHeader.is_agel ? (int)PayMethods.agel : (int)PayMethods.cach;
            if (ch_notes.Checked || !Invoice_Type.ShowPrice)
                _AllAmount.id_cash = (int)PayMethods.no;
            _AllAmount.nots = _nots;
            _AllAmount.Source_Id = invoiceHeader.id;
            _AllAmount.id_fara = invoiceHeader.id_fara;
            _AllAmount.id_user = invoiceHeader.id_user;
            _AllAmount.DateServer = invoiceHeader.DateServer;
            dbs.AllAmounts.InsertOnSubmit(_AllAmount);
        }
        private EntitySet<InvoiceDetail> Addinvoiceditals()
        {
            EntitySet<InvoiceDetail> list_store_Log = new EntitySet<InvoiceDetail>();
            list_store_Log = (EntitySet<InvoiceDetail>)gv_InvoiceDetails.DataSource;
            //for (int i = 0; i < gv_InvoiceDetails.Rows.Count; i++)
            //    gv_InvoiceDetails.Rows[i].Cells[nameof(InvoiceDetail.InvoiceHeaderID)].Value = invoiceHeader.id;
            //DBDetails.SubmitChanges();
            return list_store_Log;
        }
        private void btn_new_Click(object sender, EventArgs e)
        {
            InitializeClass();
            GetData();
            updateid = false;
        }
        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.delete, invoiceHeader.DateServer, invoiceHeader.id_user))
                return;
            if (invoice.deleteInvoice(invoiceHeader.id))
                this.Close();
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.print, invoiceHeader.DateServer, invoiceHeader.id_user))
                return;
            string s = "";
            List<ReportParameter> para = new List<ReportParameter>();
            if (Invoice_Type.showClient)
                s = invoiceHeader.is_agel == true ? "اجل" : "نقدي";
            if (Invoice_Type.DrToStore)
                s = "الي" + dr_store_to.Text;
            para.Add(new ReportParameter("P_titel", Invoice_Type.name_invoice_type + " " + s));
            para.Add(new ReportParameter("p_ShowPrice", Invoice_Type.ShowPrice.ToString()));
            DataClasses1DataContext data = new DataClasses1DataContext();
            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("invoice", data.InvoiceHeaderViews.Where(x=>x.id==invoiceHeader.id).ToList()),
             new ReportDataSource("InvoiceDetails", data.InvoiceDetails_rep_Views.Where(x=>x.InvoiceHeaderID==invoiceHeader.id).ToList()),
            };
            frm_show_report _Report = new frm_show_report(para, "invoice", ReportDataSource, true);
            _Report.Show();

        }
        private void frm_kushufat_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F12)
            {
                btn_save.PerformClick();
            }
            if (e.KeyCode == Keys.F11)
            {
                btn_add_grid.PerformClick();
            }
            if (e.KeyCode == Keys.F2)
            {
                btn_new.PerformClick();
            }
            if (e.KeyCode == Keys.P && e.Modifiers == Keys.Control)
            {
                btn_print.PerformClick();
            }
            if (e.KeyCode == Keys.Escape && updateid)
            {
                this.Close();
            }
            if (e.KeyCode == Keys.Enter )
            {
                if(gvSerchProduct.Focus())
                {
                    if (gvSerchProduct.CurrentCell != null)
                        ClickGridEnter();
                }
               
            }
        }
        private  CancellationTokenSource _cancellationTokenSource;        
        private async void SerchProductTx()
        {           
            pic_login.Visible = true;
            _cancellationTokenSource?.Cancel();
            _cancellationTokenSource = new CancellationTokenSource();
            var token = _cancellationTokenSource.Token;
            try
            {
              
                var q = new DataTable();
                await Task.Delay(100, token); // انتظار التأخيرهام جدا متفكرش تاني
                if ((type_qty)Invoice_Type.type_qty == type_qty.Qty_out && !ch_notes.Checked)
                    q = await cproduct.ExecuteQuery(cproduct.StringSerch_product(tx_ItemName.Text, dr_price.SelectedValue.ToString(), dr_store.SelectedValue.ToString(), invoiceHeader.id.ToString(), invoiceHeader.id_invoice_type.ToString()));
                else
                   //q = await cproduct.Serch_product(cproduct.StringSerchProductPricebuy(tx_ItemName.Text, dr_price.SelectedValue.ToString()), token);
                    q = await cproduct.ExecuteQuery(cproduct.StringSerchProductPricebuy(tx_ItemName.Text, dr_price.SelectedValue.ToString()));
                //if (token.IsCancellationRequested)هام جدا
                //    return;
                gvSerchProduct.DataSource = q; // تحديث النتائج
                gvSerchProduct.Columns[nameof(product_serch_View.name)].Width = 200;
                gvSerchProduct.Columns[nameof(product_serch_View.price_sale)].HeaderText = Invoice_Type.showClient ? dr_price.Text : "سعر المصنع";
                if(gvSerchProduct.Columns[nameof(product_serch_View.store_name)]!= null)
                gvSerchProduct.Columns[nameof(product_serch_View.store_name)].Visible = ((type_qty)Invoice_Type.type_qty == type_qty.Qty_out && dr_store.SelectedValue.ToString() == "0");
                gvSerchProduct.Visible = gvSerchProduct.Rows.Count != 0;
            }
            catch (TaskCanceledException)
            {
               
            }
            pic_login.Visible = false;
            if (string.IsNullOrWhiteSpace(tx_ItemName.Text))
            {
                gvSerchProduct.Visible = false;
                return;
            }
        }
         bool  StopSerch = true;
        private void tx_ItemName_TextChanged(object sender, EventArgs e)
        {
            if (Invoice_Type.showClient)
            {
                if (tx_id_cient.Text == "0" || dr_price.SelectedIndex == -1)
                {
                    btn_find_client.PerformClick();
                    return;
                }
            }
            if (string.IsNullOrWhiteSpace(tx_ItemName.Text))
            {
                gvSerchProduct.Visible = false;
                return;
            }            
            else
            {
                if(StopSerch)
                SerchProductTx();
            }
        }      
        void CelarAddProudct()
        {
            if (ch_not_celar_ItemQty.Checked == false)
                tx_ItemQty.Text = "";
            tx_Price.Text = "";
            tx_TotalPrice_ditals.Text = "";
            tx_ItemName.Text = "";
            tx_discunt_item.Text = "";
            tx_total_item.Text = "";
            lb_balance.Text = "";
            _nots = "";
            gv_InvoiceDetails.CurrentCell = null;
            Producselct = null;
            tx_ItemName.Focus();
        }
        private void ClickGridEnter()
        {
            StopSerch = false;
            if (tx_id_cient.Text == "0" || dr_price.SelectedIndex == -1)
            {
                gvSerchProduct.Visible = false;
                return;
            }
           
            if (gvSerchProduct.CurrentCell != null)
            {
                
                Producselct = new product_serch_View();
                //Producselct = (product_serch_View)gvSerchProduct.Rows[gvSerchProduct.CurrentCell.RowIndex].DataBoundItem;
                Producselct =cproduct.ConvertDataGridViewRowToObject<product_serch_View>(gvSerchProduct);
                tx_Price.Text = Producselct.price_sale.ToString();
                tx_ItemName.Text = Producselct.fullname;
                lb_balance.Text = Producselct.Balance.ToString() + " " + Producselct.store_name;
                GetProductReturn();

                //if((type_qty)Invoice_Type.type_qty==type_qty.Qty_out)
                //dr_store.SelectedValue = Producselct.store_id;
                gvSerchProduct.Visible = false;
                tx_ItemQty_TextChanged(null, null);
                if ((type_qty)Invoice_Type.type_qty == type_qty.Qty_out)
                {
                    tx_ItemQty.Focus();
                    tx_ItemQty.SelectAll();
                }
                if ((type_qty)Invoice_Type.type_qty == type_qty.Qty_in)
                {
                    if (dr_store.SelectedValue.ToString() == "0")
                    {
                        dr_store.Focus();
                        dr_store.DroppedDown = true;
                        return;
                    }
                    else
                    {
                        tx_ItemQty.Focus();
                        tx_ItemQty.SelectAll();
                    }
                }
                if (ch_auto_insert.Checked)
                {
                    btn_add_grid.PerformClick();
                }
                StopSerch = true;
            }
        }
        async void GetProductReturn()
        {
            string mas = await GetReturn(Producselct.id.ToString(), tx_id_cient.Text, (Invoice_Type.id).ToString());
            if (mas != null)
                lb_mas.Text = mas + " للصنف " + Producselct.fullname + " " + tx_name_cient.Text;
        }
        private void gvSerchProduct_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ClickGridEnter();
        }
        private void tx_ItemName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {               
                tx_ItemName.Text = "";              
                return;
            }           
            if (string.IsNullOrWhiteSpace(tx_ItemName.Text) || gvSerchProduct.Rows.Count == 0)
                return;
           else if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up)
            {
                int currentRowIndex = gvSerchProduct.CurrentCell?.RowIndex ?? 0;
                int targetRowIndex = e.KeyCode == Keys.Down? currentRowIndex + 1: currentRowIndex - 1;
                if (targetRowIndex >= 0 && targetRowIndex < gvSerchProduct.Rows.Count)
                {
                    gvSerchProduct.CurrentCell = gvSerchProduct.Rows[targetRowIndex].Cells[gvSerchProduct.CurrentCell.ColumnIndex];
                }                
                e.Handled = true;  
            }
            else if (e.KeyCode == Keys.Enter && gvSerchProduct.CurrentCell != null)
            {
                ClickGridEnter();
            }
        }
        private bool ValidAddGrid()
        {
            int err = 0;
            errorProvider1.Clear();
            if (Convertdecimal(tx_ItemQty.Text) == 0)
            {
                errorProvider1.SetError(tx_ItemQty, "يجب ادخال كمية صحيحة");
                tx_ItemQty.Text = "";
                err += 1;
            }
            else if (Producselct != null && Producselct.id != 0)
            {
                if (Invoice_Type.type_qty == 2)
                    if (!ch_notes.Checked)
                    {
                        var Qty_old = InvoiceDetail_old.Where(x => x.ItemID == Producselct.id && x.store_id == Producselct.store_id).Sum(x => x.ItemQty);
                        var Qty = bs.Cast<InvoiceDetail>().Where(x => x.ItemID == Producselct.id && x.store_id == Producselct.store_id).Sum(x => x.ItemQty);
                        if (Convertdecimal(tx_ItemQty.Text) / kilo + (Qty) > Producselct.Balance + Qty_old)
                        {
                            tx_ItemQty.SelectAll();
                            tx_ItemQty.Focus();
                            errorProvider1.SetError(tx_ItemQty, "الكمية المباعة اكبر من رصيد المخزن");
                            err += 1;
                        }
                    }
            }
            if (Producselct == null || Producselct.id == 0)
            {
                errorProvider1.SetError(tx_ItemName, "يجب اختيار صنف ");
                err += 1;
            }
            if (tx_Price.Text == "")
            {
                errorProvider1.SetError(tx_Price, "يجب اضافة سعر");
                err += 1;
            }
            if (Invoice_Type.ShowPrice)
                if (string.IsNullOrEmpty(tx_total_item.Text.Trim()) || ConvertDouble(tx_total_item.Text) <= 0)
                {
                    errorProvider1.SetError(tx_total_item, "يجب ان تكون القيمة اكبر من صفر");
                    err += 1;
                }
            if (dr_store.SelectedValue.ToString() == "0" && (type_qty)Invoice_Type.type_qty == type_qty.Qty_in)
            {
                errorProvider1.SetError(dr_store, "يجب اختيار المخزن");
                err += 1;
            }
            return (err == 0);
        }
        private void btn_add_grid_Click(object sender, EventArgs e)
        {
            if (ValidAddGrid() == false)
                return;

            bs.Insert(0, new InvoiceDetail
            {
                InvoiceHeaderID = invoiceHeader.id,
                ItemID = Producselct.id,
                ItemQty = Convert.ToDecimal((Convertdecimal(tx_ItemQty.Text) / kilo).ToString("0.000")),
                Price = Convertdecimal(tx_Price.Text),
                TotalPrice = Convertdecimal(tx_TotalPrice_ditals.Text),
                Discount = dr_discunt_item.SelectedIndex == 1 ? Convertdecimal(tx_discunt_item.Text) : Convertdecimal(tx_TotalPrice_ditals.Text) * Convertdecimal(tx_discunt_item.Text) / 100,
                Total = Convertdecimal(tx_total_item.Text),
                store_id = (type_qty)Invoice_Type.type_qty == type_qty.Qty_out && !ch_notes.Checked ? (int)Producselct.store_id : (int)dr_store.SelectedValue
            });
            CelarAddProudct();
            GetTotal();
        }
        void GetTotal()
        {
            tx_Total_product.Text = Convertdecimal(gv_InvoiceDetails.Rows.Cast<DataGridViewRow>().Sum(t => Convert.ToDouble(t.Cells[nameof(InvoiceDetail.Total)].Value)).ToString()).ToString("0.00");
            TxTotalQty.Text = Convertdecimal(gv_InvoiceDetails.Rows.Cast<DataGridViewRow>().Sum(t => Convert.ToDecimal(t.Cells[nameof(InvoiceDetail.ItemQty)].Value)).ToString()).ToString("0.000");
            decimal total_product = Convertdecimal(tx_Total_product.Text);

            if (dr_Extra_type.SelectedIndex == 0)
                tx_Extra.Text = (total_product * Convertdecimal(tx_Extra_percent.Text) / 100).ToString("0.00");
            else
                tx_Extra.Text = Convertdecimal(tx_Extra_percent.Text).ToString("0.00");

            if (dr_Discount_type.SelectedIndex == 0)
                tx_Discount.Text = (total_product * Convertdecimal(tx_Discount_percent.Text) / 100).ToString("0.00");
            else
                tx_Discount.Text = Convertdecimal(tx_Discount_percent.Text).ToString("0.00");

            decimal Discount = Convertdecimal(tx_Discount.Text);
            decimal Extra = Convertdecimal(tx_Extra.Text);

            tx_Net.Text = Math.Round(((total_product + Extra - Discount) / 1) * 1).ToString("0.00");
        }
        private void Gv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var dataGridViewColumn = gv_InvoiceDetails.Columns[deleteitem.Name];
            if (e.ColumnIndex == gv_InvoiceDetails.Columns.IndexOf(dataGridViewColumn) && e.RowIndex != -1)
            {
                if (MyMessageBox.showMessage("تاكيد", "هل متاكد من حذف السجل المحدد", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    bs.RemoveAt(e.RowIndex);
                    GetTotal();
                }
                else
                {
                    gv_InvoiceDetails.CurrentCell = null;
                    tx_ItemName.Focus();
                }
            }
        }
        private void tx_ItemQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void tx_Discount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Regex.IsMatch((sender as TextBox).Text, @"\.\d\d") && e.KeyChar != 8)
            {
                e.Handled = true;
            }
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (((e.KeyChar == '.') || char.IsDigit(e.KeyChar)) && (sender as TextBox).SelectionLength == (sender as TextBox).Text.Length)
            {
                e.Handled = false;
            }
            else
            if ((e.KeyChar == '.') && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }
        private void gv_InvoiceDetails_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            if (MyMessageBox.showMessage("تاكيد", "هل متاكد من حذف السجل المحدد", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                e.Cancel = false;
                gv_InvoiceDetails.CurrentCell = null;
            }
            else
            {
                e.Cancel = true;
            }
        }
        private void gv_InvoiceDetails_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            GetTotal();
        }
        private void tx_Discount_percent_TextChanged(object sender, EventArgs e)
        {
            GetTotal();
        }
        private void CkTxQty()
        {
            if (tx_ItemName.Text == "")
                tx_ItemName.Focus();
            else
            {
                tx_ItemQty.Focus();
                tx_ItemQty.SelectAll();
            }
            tx_ItemQty_TextChanged(null, null);
        }
        private void ClientSave_Click(object sender, EventArgs e)
        {
            if (ConvertInt(tx_id_cient.Text) != 0)
            {
                Properties.Settings.Default.id_client = ConvertInt(tx_id_cient.Text);
                Properties.Settings.Default.Save();
                lb_mas.Text = "تم تثبيت العميل عند البداء";
                client_save = ConvertInt(tx_id_cient.Text);
            }
            else
                lb_mas.Text = "يجب اضافة عميل اولا";
        }
        private void BtnClientUnSave_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.id_client = 0;
            Properties.Settings.Default.Save();
            lb_mas.Text = " تم ازالة تثبيت العميل عند البداء";
        }
        private void dr_price_SelectionChangeCommitted(object sender, EventArgs e)
        {
            tx_ItemName.Focus();
            if (gv_InvoiceDetails.RowCount == 0)
                return;
            if (!User_setting().invoice_chang_list_price_client && !User_setting().invoice_chang_price)
            {
                NewMethod();
                MyMessageBox.showMessage("تاكيد", " تم تحديث  اسعار الاصناف المدرجة بناء علي قائمة الاسعار  " + dr_price.Text + " ", "", MessageBoxButtons.OK);
                return;
            }
            if (MyMessageBox.showMessage("تاكيد", "هل تريد تحديث  اسعار الاصناف المدرجة بناء علي قائمة الاسعار " + dr_price.Text + " ", "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;
            NewMethod();
        }
        private void NewMethod()
        {
            for (int i = 0; i < gv_InvoiceDetails.Rows.Count; i++)
            {
                int ItemID = ConvertInt(gv_InvoiceDetails.Rows[i].Cells[nameof(InvoiceDetail.ItemID)].Value.ToString());
                decimal ItemGvDiscount = Convertdecimal(gv_InvoiceDetails.Rows[i].Cells[nameof(InvoiceDetail.Discount)].Value.ToString());
                decimal ItemQty = Convertdecimal(gv_InvoiceDetails.Rows[i].Cells[nameof(InvoiceDetail.ItemQty)].Value.ToString());
                product product = db.products.Where(x => x.id == ItemID).First();
                decimal price_sale = Convertdecimal(product.GetType().GetProperty(dr_price.SelectedValue.ToString()).GetValue(product, null).ToString());
                gv_InvoiceDetails.Rows[i].Cells[nameof(InvoiceDetail.Price)].Value = price_sale;
                gv_InvoiceDetails.Rows[i].Cells[nameof(InvoiceDetail.TotalPrice)].Value = (price_sale * ItemQty);
                gv_InvoiceDetails.Rows[i].Cells[nameof(InvoiceDetail.Total)].Value = (price_sale * ItemQty) - ItemGvDiscount;
            }
            GetTotal();
        }
        private void dr_discunt_item_SelectionChangeCommitted(object sender, EventArgs e)
        {
            CkTxQty();
            Properties.Settings.Default.dr_discunt_item = dr_discunt_item.SelectedIndex;
            Properties.Settings.Default.Save();
        }
        private void bt_save_is_agel_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.ch_is_agel = ch_is_agel.Checked;
            Properties.Settings.Default.Save();
            lb_mas.Text = toolTip1.GetToolTip(bt_save_is_agel);
        }
        private void ch_kilo_Click(object sender, EventArgs e)
        {
            if (ch_kilo.Checked)
            {
                kilo = 1000;
                ch_kilo.ForeColor = Color.Green;
            }
            else
            {
                kilo = 1;
                ch_kilo.ForeColor = Color.DimGray;
            }
            Properties.Settings.Default.ch_kilo = ch_kilo.Checked;
            Properties.Settings.Default.Save();
            CkTxQty();
        }
        private void ch_auto_insert_Click(object sender, EventArgs e)
        {
            if (ch_auto_insert.Checked)
            {
                ch_auto_insert.ForeColor = Color.Green;
            }
            else ch_auto_insert.ForeColor = Color.DimGray;
            Properties.Settings.Default.ch_auto_insert = ch_auto_insert.Checked;
            Properties.Settings.Default.Save();
            CkTxQty();
        }
        private void ch_not_celar_ItemQty_Click(object sender, EventArgs e)
        {
            if (ch_not_celar_ItemQty.Checked)
            {
                ch_not_celar_ItemQty.ForeColor = Color.Green;
            }
            else ch_not_celar_ItemQty.ForeColor = Color.DimGray;
            Properties.Settings.Default.ch_not_celar_ItemQty = ch_not_celar_ItemQty.Checked;
            Properties.Settings.Default.Save();
            CkTxQty();
        }
        private void ch_is_agel_CheckedChanged(object sender, EventArgs e)
        {
            if (ch_is_agel.Checked)
            {
                tx_Net.BackColor = Color.Red;
                ch_is_agel.BackColor = Color.Red;
                toolTip1.SetToolTip(bt_save_is_agel, "جعل الفاتورة اجل دائما عند انشاء بيان جديد");
            }
            else
            {
                tx_Net.BackColor = Color.LimeGreen;
                ch_is_agel.BackColor = Color.LimeGreen;
                toolTip1.SetToolTip(bt_save_is_agel, "جعل الفاتورة نقدي دائما عند انشاء بيان جديد");
            }
        }

        private void tx_ItemQty_TextChanged(object sender, EventArgs e)
        {
            decimal dis = 0;
            if (dr_discunt_item.SelectedIndex == -1)
                dr_discunt_item.SelectedIndex = 0;

            if (dr_discunt_item.SelectedIndex == 0)
                dis = Convertdecimal(tx_TotalPrice_ditals.Text) * Convertdecimal(tx_discunt_item.Text) / 100;
            if (dr_discunt_item.SelectedIndex == 1)
                dis = Convertdecimal(tx_discunt_item.Text);

            //if (istx_ItemQty == tx_ItemQty.Name)
            //    tx_TotalPrice_ditals.Text = ((Convertdecimal(tx_ItemQty.Text) / kilo * Convertdecimal(tx_Price.Text))).ToString("0.00");
            if (istx_ItemQty == tx_TotalPrice_ditals.Name)
            {
                if (Convertdecimal(tx_Price.Text) != 0)
                {
                    decimal d = Convertdecimal(tx_TotalPrice_ditals.Text) / Convertdecimal(tx_Price.Text);
                    tx_ItemQty.Text = (d * kilo).ToString("0");
                    //tx_ItemQty.Text = (Convertdecimal(tx_TotalPrice_ditals.Text) / Convertdecimal(tx_Price.Text)).ToString("0.000");
                }
            }
            else
            {
                tx_TotalPrice_ditals.Text = ((Convertdecimal(tx_ItemQty.Text) / kilo * Convertdecimal(tx_Price.Text))).ToString("0.00");
            }
            tx_total_item.Text = (Convertdecimal(tx_TotalPrice_ditals.Text) - dis).ToString("0.00");
        }
        private void tx_ItemQty_Leave(object sender, EventArgs e)
        {
            var tx = sender as TextBox;
            tx.TextChanged -= tx_ItemQty_TextChanged;
            istx_ItemQty = "";
        }
        private void tx_ItemQty_Enter(object sender, EventArgs e)
        {
            var tx = sender as TextBox;
            tx.TextChanged += tx_ItemQty_TextChanged;
            istx_ItemQty = tx.Name;
        }
        private void dr_store_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if ((type_qty)Invoice_Type.type_qty == type_qty.Qty_in)
                {
                    if (dr_store.SelectedValue.ToString() == "0")
                        return;
                    tx_ItemQty.Focus();
                    tx_ItemQty.SelectAll();

                }
            }
        }
        private void tx_ItemQty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (ConvertDouble(tx_ItemQty.Text) > 0)
                {
                    if (Invoice_Type.ShowPrice)
                    {
                        tx_Price.Focus();
                        tx_Price.SelectAll();
                    }
                    else
                    {
                        btn_add_grid.PerformClick();
                    }
                }
            }
        }
        private void tx_Price_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (ConvertDouble(tx_Price.Text) > 0)
                {
                    if (tx_discunt_item.Visible != true)
                    {
                        btn_add_grid.PerformClick();
                    }
                    else
                    {
                        if (ConvertDouble(tx_discunt_item.Text) > 0)
                            btn_add_grid.PerformClick();
                        else
                        {
                            tx_discunt_item.Focus();
                            tx_discunt_item.SelectAll();
                        }
                    }
                }
            }
        }
        private void tx_discunt_item_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (ConvertDouble(tx_ItemQty.Text) > 0)
                    btn_add_grid.PerformClick();
            }
        }

        private void pan_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
