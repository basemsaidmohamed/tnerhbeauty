﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace tnerhbeauty
{
    public partial class Form2 : Form
    {
        public Form2()
        {

            InitializeComponent();
        }

        List<object> result = new List<object> { "newss" };

        List<list_price> p;
        private void Form2_Load(object sender, EventArgs e)
        {



        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

    }
}
