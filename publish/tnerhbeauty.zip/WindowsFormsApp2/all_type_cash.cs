﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace tnerhbeauty
{
    public partial class all_type_cash : Form
    {
        DataClasses1DataContext db;
        public all_type_cash()
        {
            InitializeComponent();

        }
        public void getdata()
        {
            db = new DataClasses1DataContext();
            gv.DataSource = db.type_cashes.Where(x => x.id > 2 && x.name.Contains(tx_serch.Text)).OrderByDescending(x => x.id);
            gv.CurrentCell = null;
        }
        private void gv_mariddata_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            int id = Convert.ToInt32(gv.Rows[e.RowIndex].Cells[nameof(type_cash.id)].Value.ToString());
            add_type_cash kushufat = new add_type_cash(id);
            kushufat.ShowDialog();
            getdata();
        }
        private void all_marid_Load(object sender, EventArgs e)
        {
            gv.AutoGenerateColumns = false;
            getdata();
        }
        private void bt_search_Click(object sender, EventArgs e)
        {
            getdata();
        }
    }
}
