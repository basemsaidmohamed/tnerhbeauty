﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using tnerhbeauty.Class;

namespace tnerhbeauty
{
    public partial class all_fara : Form
    {
        DataClasses1DataContext db;
        public all_fara()
        {
            InitializeComponent();

        }
        public void getdata()
        {
            db = new DataClasses1DataContext();
            var data = db.faras.OrderBy(x => x.name_fara).Where(
              x => (x.name_fara.Contains(tx_serch.Text.Replace_text())
              || x.tel.Contains(tx_serch.Text)
              || Convert.ToString(x.id) == tx_serch.Text
              )).OrderByDescending(x => x.name_fara.StartsWith(tx_serch.Text.Replace_text())).ToList();
            gv.DataSource = data;
            gv.CurrentCell = null;
            gv_stores.DataSource = null;
            gv_user.DataSource = null;
        }
        private void gv_mariddata_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            int id = Convert.ToInt32(gv.Rows[e.RowIndex].Cells[nameof(fara.id)].Value.ToString());
            add_fara kushufat = new add_fara(id);
            kushufat.ShowDialog();
            getdata();
        }
        private void all_marid_Load(object sender, EventArgs e)
        {
            if (Session.User_setting().show_store == Session.User_setting().update_store == Session.User_setting().delete_store == false)
                gv_stores.Visible = false;
            if (Session.User_setting().show_user == Session.User_setting().update_user == Session.User_setting().delete_user == false)
                gv_user.Visible = false;

            gv_stores.AutoGenerateColumns = false;
            gv_user.AutoGenerateColumns = false;
            db = new DataClasses1DataContext();
            fara _fara;
            gv.DataSource = new List<fara>();
            gv.Columns[nameof(_fara.is_stop)].SortMode = DataGridViewColumnSortMode.Automatic;
            gv.Columns[nameof(_fara.id)].Visible = false;
            //gv.Columns[nameof(_fara.id_user)].Visible = false;
            gv.Columns[nameof(_fara.tel)].HeaderText = "التليفون";
            gv.Columns[nameof(_fara.adress)].HeaderText = "العنوان ";
            gv.Columns[nameof(_fara.is_stop)].HeaderText = "موقوف ";
            gv.Columns[nameof(_fara.name_fara)].HeaderText = "اسم الفرع";
            gv.Columns[nameof(_fara.id_user)].HeaderText = "رقم الموظف";
            getdata();
        }
        private void bt_search_Click(object sender, EventArgs e)
        {
            getdata();
        }

        private void gv_CellClick(object sender, DataGridViewCellEventArgs e)
        {


            if (e.RowIndex < 0)
                return;
            int id = Convert.ToInt32(gv.Rows[e.RowIndex].Cells[nameof(fara.id)].Value.ToString());

            gv_stores.DataSource = Session.GetStoreFara(id).ToList();
            gv_stores.CurrentCell = null;

            gv_user.DataSource = Session.GetUserByFaraId(id).ToList();
            gv_user.CurrentCell = null;
            gv_user.Columns[nameof(gv_store_name)].Visible = true;
            gv_user.DataSource = Session.GetUserByFaraId(id).ToList();
            gv_user.CurrentCell = null;
            gv_user.Columns[nameof(gv_store_name)].Visible = false;
        }
    }
}
