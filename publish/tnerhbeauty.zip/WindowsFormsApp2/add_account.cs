﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using tnerhbeauty.Class;
using static tnerhbeauty.Class.Session;
namespace tnerhbeauty
{
    public partial class add_account : Form
    {
        DataClasses1DataContext db;
        All_account _Account;
        bool updateid = false;
        public add_account()
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
            _Account = new All_account();
        }
        public add_account(int id)
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
            _Account = new All_account();
            _Account = db.All_accounts.Where(s => s.id == id).FirstOrDefault();
            updateid = true;
        }
        private void add_marid_Load(object sender, EventArgs e)
        {
            dr_typeAmount.IntializeData(Session.TypeAmountList);
            GetData();
        }
        void GetData()
        {
            tx_name.Text = _Account.name;
            ch_isstop.Checked = _Account.is_stop;
            if (_Account.id != 0)
            {
                lp_titel.Text = "تعديل بيانات حساب";
                dr_typeAmount.SelectedValue = _Account.type_amount;
                btn_delete.Visible = Session.User_setting().delete_All_account;
                btn_save.Visible = Session.User_setting().update_All_account;
            }
            else
            {
                lp_titel.Text = "اضافة حساب  جديد";
                dr_typeAmount.SelectedIndex = -1;
                btn_save.Visible = Session.User_setting().add_All_account;
                btn_new.Visible = Session.User_setting().add_All_account;
            }
        }
        void SetData()
        {
            _Account.name = tx_name.Text.Replace_text();
            _Account.type_amount = Session.ConvertInt(dr_typeAmount.SelectedValue.ToString());
            _Account.type_acount = 3;
            _Account.is_stop = ch_isstop.Checked;
            _Account.id_user = Session.User_login.id;
            if (_Account.id == 0)
                _Account.DateServer = Session.GetDate();
        }
        bool valid()
        {
            errorProvider1.Clear();
            int error = 0;
            if (string.IsNullOrEmpty(tx_name.Text.Trim()))
            {
                errorProvider1.SetError(tx_name, "يجب ادخال الاسم");
                error++;
            }
            return error == 0;
        }
        private void bt_new_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            updateid = false;
            _Account = new All_account();
            GetData();
            tx_name.Focus();
        }
        private void add_marid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F12)
            {
                btn_save.PerformClick();
            }
            if (e.KeyCode == Keys.F2)
            {
                btn_new.PerformClick();
            }
            if (e.KeyCode == Keys.Escape && updateid)
            {
                this.Close();
            }
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl(ActiveControl, true, true, true, true);
                if (ActiveControl is TextBox tx)
                {
                    tx.SelectAll();
                }
            }
        }
        private void bt_save_Click(object sender, EventArgs e)
        {
            if (updateid)
                if (checkUpdate(type_.update, _Account.DateServer, _Account.id_user))
                    return;
            if (!valid())
                return;
            SetData();
            if (_Account.id == 0)
                db.All_accounts.InsertOnSubmit(_Account);
            try
            {
                db.SubmitChanges();
            }
            catch (SqlException x)
            {
                if (x.Number == 2627)
                {
                    MyMessageBox.showMessage("error ", "يوجد محزن اخر مسجل بنفس الاسم ", "", MessageBoxButtons.RetryCancel);
                }
                else
                    MyMessageBox.showMessage("error ", " لم يتم الحفظ ", "", MessageBoxButtons.RetryCancel);
                return;
            }
            if (updateid)
            {
                this.Close();
                return;
            }
            lb_mas.Text = massege.successfully;
            btn_new.PerformClick();
        }
        private void bt_delete_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.delete, _Account.DateServer, _Account.id_user))
                return;
            if (MyMessageBox.showMessage("تاكيد", massege.AskDelete, "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;
            try
            {
                db.deleteAll_account(_Account.id);
            }
            catch (SqlException x)
            {
                if (x.Number == 547)
                {
                    MyMessageBox.showMessage("خطاء", massege.NotDelete, "", MessageBoxButtons.RetryCancel);
                }
                else
                    MyMessageBox.showMessage("error ", " لم يتم الحذف  ", "", MessageBoxButtons.RetryCancel);
                return;
            }
            this.Close();
        }

        private void btn_print_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.print, _Account.DateServer, _Account.id_user))
                return;
        }
    }
}
