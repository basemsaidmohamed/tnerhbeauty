﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;
using tnerhbeauty.Class;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using System.Xml.Linq;
using ClosedXML.Excel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Activities.Statements;
using System.Reflection;



namespace tnerhbeauty
{
    public partial class frm_up_product_min_mum : Form
    {
        string end_column = "c";
        int code = 0, name = 1, min_mum = 2, not = 3;
        bool isimpore;
        private void gv_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            if (MyMessageBox.showMessage("تاكيد", "هل متاكد من حذف السجل المحدد", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                e.Cancel = false;
                gv.CurrentCell = null;
            }
            else
            {
                e.Cancel = true;
            }
        }
        private void gv_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            if (valid())
            {
                bt_save.Visible = true;
            }
        }
        public frm_up_product_min_mum()
        {
            InitializeComponent();
        }
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            //try
            //{            
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "اختار ملف اكسيل ";
            ofd.Filter = "Excel Files|*.xlsx;*.xls;";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                emptyall();
                string FileName = Path.GetFileName(ofd.FileName);
                txtPath.Text = ofd.FileName;
                isimpore = true;
                cboSheet.Items.Clear();
                get_data(null);
                gv.Columns.Cast<DataGridViewColumn>().ToList().ForEach(f => f.SortMode = DataGridViewColumnSortMode.NotSortable);
            }
            //}
            //catch
            //{
            //    emptyall();
            //    MyMessageBox.showMessage("تحذير   ", "حدث خطاء اثناء جلب البيانات ربما يكون الملف غير صالح ", "", MessageBoxButtons.RetryCancel);
            //}
        }
        private void emptyall()
        {
            cboSheet.Items.Clear();
            cboSheet.Text = "";
            txtPath.Text = "";
            bt_save.Visible = false;
            gv.DataSource = new DataTable();
        }
        DataTable dt;
        bool valid()
        {
            int error = 0;
            for (int i = 0; i < gv.Rows.Count; i++)
            {
                string datacode = gv.Rows[i].Cells[code].Value.ToString();
                if (string.IsNullOrEmpty(datacode.Trim()))
                {
                    gv.Rows[i].Cells[not].Value += " برجاء ادخال كود الصنف ";
                    gv.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                    error++;
                }

                string data_minmum = gv.Rows[i].Cells[min_mum].Value.ToString();
                if (!decimal.TryParse(data_minmum, out _))
                {
                    gv.Rows[i].Cells[not].Value += " الكمية غير صحيح ";
                    gv.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                    error++;
                }
                string dataname = gv.Rows[i].Cells[name].Value.ToString();
                if (string.IsNullOrEmpty(dataname.Trim()))
                {
                    gv.Rows[i].Cells[not].Value += " اسم الصنف  غير صحيح ";
                    gv.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                    error++;
                }
            }
            return error == 0;
        }
        private void errorimport(string mas)
        {
            gv.DataSource = new DataTable();
            lb_mas.Text = mas;
        }
        private void cboSheet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isimpore)
            {
                get_data(cboSheet.Text);
            }
            isimpore = false;
        }      
        private void dataGridView1_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length != 1)
                {
                    lb_mas.Text = "يجب اضافة ملف اكسيل واحد فقط";
                    return;
                }
                emptyall();
                string FileName = Path.GetFileName(files[0]);
                txtPath.Text = files[0];
                isimpore = true;
                get_data(null);
            }
        }
        private void dataGridView1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.All;
            else
                e.Effect = DragDropEffects.None;
        }
        private void bt_save_Click(object sender, EventArgs e)
        {
            if (MyMessageBox.showMessage("معلومات هامة ", "سيتم تحديث الاسعار بتاريخ اليوم هل متاكد من الاسنمرار .. ؟", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DataClasses1DataContext db = new DataClasses1DataContext();
                for (int i = 0; i < gv.Rows.Count; i++)
                {
                    string datacode = gv.Rows[i].Cells[code].Value.ToString();
                    decimal datamin_mum = Session.Convertdecimal(gv.Rows[i].Cells[min_mum].Value.ToString());
                    db.ExecuteCommand("UPDATE product SET min_mum =" + datamin_mum + "  WHERE (code = N'" + datacode + "')", "");
                }
                db.SubmitChanges();
                emptyall();
                MyMessageBox.showMessage("معلومات", massege.successfully, "", MessageBoxButtons.OK);
            }
            else MyMessageBox.showMessage("معلومات", "تم الغاء التحديث ", "", MessageBoxButtons.RetryCancel);
        }
        private void btn_export_exal_Click(object sender, EventArgs e)
        {
            lb_mas.Text = "  جاري انشاء ملف الاكسيل ...";           
            DataClasses1DataContext db = new DataClasses1DataContext();
            var xx = db.products.Select(x => new {x.code,x.name,x.min_mum}).ToList();
            xx.ExportListToExal("حد الطلب");                       
            lb_mas.Text = @"تم حفظ الملف  \" + Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer" + @"\" + DateTime.Now.Ticks + "Response.xlsx" + "";
        }
        private void get_data(string sheetname)
        {
            try
            {
                bt_save.Visible = false;
                
                gv.DataSource = new DataTable();
                dt = new DataTable();

                GetDatabyOLEDB(sheetname);
            if (dt.Rows.Count == 0)
                GetDataFromExcel(sheetname);

            gv.DataSource = dt;
            if (dt.Rows.Count > 0 && dt.Columns.Count == not)
            {
                dt.Columns.Add();
                gv.DataSource = null;
                gv.DataSource = dt;
                gv.Columns[code].HeaderText = "كود";
                gv.Columns[name].HeaderText = "اسم الصنف";
                gv.Columns[min_mum].HeaderText = "حد الطلب";               
                gv.Columns[not].HeaderText = "ملاحظات";
                if (valid())
                {
                    bt_save.Visible = true;
                    
                }
            }
            else
            {
                gv.DataSource = new DataTable();
                errorimport("صفحة ربما لا تحتوي علي بيانات وايضا يجب ان يكون الصفحة تحتوي على 3 اعمدة هي  الكود-اسم الصنف-حد الطلب  بنفس الترتيب ");
            }

            }
            catch
            {
                errorimport("برجاء التاكد من  الملف و الصفحة ");
                gv.DataSource = new DataTable();
            }
        }
        private void GetDatabyOLEDB(dynamic sheetname)
        {
            try
            {
                string Extension = Path.GetExtension(txtPath.Text);
                string conStr = "";
                if (Extension == ".xls")
                    conStr = String.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source={0};Extended Properties=\'Excel 8.0;HDR=Yes;IMEX=1'", txtPath.Text);
                else
                    conStr = String.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source={0};Extended Properties='Excel 12.0;HDR=Yes;IMEX=1'", txtPath.Text);
                OleDbConnection connExcel = new OleDbConnection(conStr);
                OleDbCommand cmdExcel = new OleDbCommand();
                OleDbDataAdapter oda = new OleDbDataAdapter();
                cmdExcel.Connection = connExcel;
                connExcel.Open();
                DataTable dtExcelSchema = new DataTable();

                dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                if (dtExcelSchema.Rows.Count > 0)
                {
                    if (sheetname == null)
                    {
                        foreach (DataRow table in dtExcelSchema.Rows)
                        {
                            cboSheet.Items.Add(table["TABLE_NAME"].ToString().Replace("'", "").Replace("$", ""));
                        }
                        cboSheet.SelectedIndex = 0;
                    }
                    string SheetName = sheetname == null ? dtExcelSchema.Rows[0]["TABLE_NAME"].ToString() : sheetname + "$";
                    cmdExcel.CommandText = "select * from [" + SheetName + "A1:" + end_column + "]";
                    oda.SelectCommand = cmdExcel;
                    oda.Fill(dt);
                    connExcel.Close();
                }
            }
            catch { }
        }
        private void GetDataFromExcel(dynamic worksheet)
        {
            try { 
            //Save the uploaded Excel file.

            //Open the Excel file using ClosedXML.
            using (XLWorkbook workBook = new XLWorkbook(txtPath.Text))
            {
                if (worksheet == null)
                {
                    cboSheet.Items.Clear();
                    foreach (IXLWorksheet sheet in workBook.Worksheets)
                    {
                        cboSheet.Items.Add(sheet.Name);
                    }
                    cboSheet.SelectedIndex = 0;
                }
                //Read the first Sheet from Excel file.
                IXLWorksheet workSheet = workBook.Worksheet(cboSheet.Text);




                //Create a new DataTable.

                //Loop through the Worksheet rows.
                bool firstRow = true;
                foreach (IXLRow row in workSheet.Rows())
                {
                    //Use the first row to add columns to DataTable.
                    if (firstRow)
                    {
                        foreach (IXLCell cell in row.Cells("a", end_column))
                        {
                            if (!string.IsNullOrEmpty(cell.Value.ToString()))
                            {
                                dt.Columns.Add(cell.FormulaR1C1.ToString());
                            }
                            else
                            {
                                break;
                            }
                        }
                        firstRow = false;
                    }
                    else
                    {
                        if (dt.Columns.Count == 0)
                            return;
                        int i = 0;
                        DataRow toInsert = dt.NewRow();
                        foreach (IXLCell cell in row.Cells(1, dt.Columns.Count))
                        {
                            try
                            {
                                toInsert[i] = cell.Value.ToString();
                            }
                            catch 
                            {

                            }
                            i++;
                        }
                        dt.Rows.Add(toInsert);
                    }
                }
            }
        } catch{}

        }        
    }
    
}