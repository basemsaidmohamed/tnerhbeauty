﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using tnerhbeauty.Class;
using static tnerhbeauty.Class.Session;

namespace tnerhbeauty
{
    public partial class add_amount : Form
    {
        DataClasses1DataContext db;
        AllAmount _AllAmount;
        bool updateid = false;
        public add_amount()
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
            _AllAmount = new AllAmount();
        }
        public add_amount(int id)
        {
            InitializeComponent();
            db = new DataClasses1DataContext();
            _AllAmount = new AllAmount();
            _AllAmount = db.AllAmounts.Where(s => s.id == id).FirstOrDefault();
            updateid = true;
        }
        private void add_marid_Load(object sender, EventArgs e)
        {
            dr_type_amount.IntializeData(Session.TypeAmountList);
            dr_type_cach.IntializeData(Session.Type_cash_list);
            getdata();
        }
        void getdata()
        {

            tx_amount.Value = 0;
            tx_nots.Text = _AllAmount.nots;

            if (_AllAmount.id != 0)
            {
                lp_titel.Text = "تعديل  بيان ايرادات و مصروفات";
                btn_delete.Visible = Session.User_setting().delete_amount;
                btn_save.Visible = Session.User_setting().update_amount;
                dr_type_amount.SelectedValue = db.All_accounts.Where(x => x.id == _AllAmount.id_account).FirstOrDefault().type_amount;
                dr_type_account_SelectionChangeCommitted(null, null);
                dr_account.SelectedValue = _AllAmount.id_account;
                dr_type_cach.SelectedValue = _AllAmount.id_cash;
                tx_amount.Value = _AllAmount.amount;
            }
            else
            {
                lp_titel.Text = "اضافة بيان ايرادات و مصروفات";
                dr_type_amount.SelectedIndex = -1;
                dr_type_cach.SelectedIndex = -1;
                btn_save.Visible = Session.User_setting().add_amount;
                btn_new.Visible = Session.User_setting().add_amount;
                tx_amount.Text = "";
            }
            dr_type_amount.Focus();
        }
        void setdata()
        {

            _AllAmount.id_account = Session.ConvertInt(dr_account.SelectedValue.ToString());
            _AllAmount.id_cash = Session.ConvertInt(dr_type_cach.SelectedValue.ToString());
            _AllAmount.amount = tx_amount.Value;
            _AllAmount.nots = tx_nots.Text.Replace_text();
            _AllAmount.id_user = Session.User_login.id;
            _AllAmount.id_fara = Session.User_login.id_fara;
            if (!updateid)
                _AllAmount.DateServer = Session.GetDate();
        }
        bool valid()
        {
            errorProvider1.Clear();
            int error = 0;
            if (string.IsNullOrEmpty(tx_amount.Text.Trim()) || Session.ConvertDouble(tx_amount.Text) <= 0)
            {
                errorProvider1.SetError(tx_amount, massege.NotNull);
                error++;
            }
            if (dr_account.SelectedIndex == -1)
            {
                errorProvider1.SetError(dr_account, massege.NotNull);
                error++;
            }
            if (dr_type_amount.SelectedIndex == -1)
            {
                errorProvider1.SetError(dr_type_amount, massege.NotNull);
                error++;
            }
            if (dr_type_cach.SelectedIndex == -1)
            {
                errorProvider1.SetError(dr_type_cach, massege.NotNull);
                error++;
            }
            return error == 0;
        }
        private void bt_new_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            _AllAmount = new AllAmount();
            dr_account.DataSource = null;
            tx_amount.Value = 0;

            tx_nots.Text = "";
            updateid = false;
            getdata();
        }
        private void add_marid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F12)
            {
                btn_save.PerformClick();
            }
            if (e.KeyCode == Keys.F2)
            {
                btn_new.PerformClick();
            }
            if (e.KeyCode == Keys.P && e.Modifiers == Keys.Control)
            {
                btn_print.PerformClick();
            }
            if (e.KeyCode == Keys.Escape && updateid)
            {
                this.Close();
            }
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl(ActiveControl, true, true, true, true);
                if (ActiveControl is TextBox)
                {
                    TextBox tx = (TextBox)ActiveControl;
                    tx.SelectAll();
                }
            }
        }
        private void bt_save_Click(object sender, EventArgs e)
        {

            if (!valid())
                return;
            if (updateid)
                if (checkUpdate(type_.update, _AllAmount.DateServer, _AllAmount.id_user))
                    return;
            setdata();
            if (_AllAmount.id == 0)
                db.AllAmounts.InsertOnSubmit(_AllAmount);

            db.SubmitChanges();

            if (updateid)
            {
                this.Close();
                return;
            }
            btn_new.PerformClick();
            lb_mas.Text = massege.successfully;
        }
        private void bt_delete_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.delete, _AllAmount.DateServer, _AllAmount.id_user))
                return;
            if (MyMessageBox.showMessage("تاكيد", massege.AskDelete, "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;
            db.deleteAllAmount(_AllAmount.id);
            this.Close();
        }
        private void bt_print_Click(object sender, EventArgs e)
        {
            if (checkUpdate(type_.print, _AllAmount.DateServer, _AllAmount.id_user))
                return;
            //DataClasses1DataContext data = new DataClasses1DataContext();
            //ReportDataSource[] ReportDataSource = new ReportDataSource[]
            //{
            // new ReportDataSource("amount_client", data.Clients.Where(x=>x.id==Amount_client.id)),
            //};
            //frm_show_report _Report = new frm_show_report(null, "amount_client", ReportDataSource,false);
            //_Report.Show();
        }
        private void dr_type_account_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (dr_type_amount.SelectedIndex != -1)
            {
                dr_account.IntializeData(db.All_accounts.Where(x => x.type_amount == (int)dr_type_amount.SelectedValue && x.type_acount == 3 && x.is_stop == false).ToList());
                dr_account.SelectedIndex = -1;
            }
            else
                dr_account.DataSource = null;
        }
    }
}
