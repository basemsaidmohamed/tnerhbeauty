﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;

namespace tnerhbeauty
{
    public partial class all_amount : Form
    {
        DataClasses1DataContext db;
        AllAmount_View _AllAmount_View;
        string p_name_client = "";
        string p_date_from;
        string p_date_to;
        public all_amount()
        {
            InitializeComponent();
        }
        private async void all_kushufat_Load(object sender, EventArgs e)
        {
            db = new DataClasses1DataContext();
            dr_type_amount.IntializeData(Session.TypeAmountList, true);
            dr_type_cach.IntializeData(Session.Type_cash_list, true);
            dr_fara.IntializeData(cproduct.FaraUser, nameof(fara.name_fara), nameof(fara.id));
            dr_fara.SelectedValue = Session.User_login.id_fara;
            dr_fara_SelectionChangeCommitted(null, null);
            await getdata();
            InitializeGridViewColumns(gv_in);
            InitializeGridViewColumns(gv_out);
        }
        private void InitializeGridViewColumns(DataGridView gv)
        {
            gv.Columns[nameof(_AllAmount_View.id)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.id_account)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.Source_Id)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.id_cash)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.id_fara)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.id_account)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.id_user)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.type_amount)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.count)].Visible = false;
            gv.Columns[nameof(_AllAmount_View.type_name)].HeaderText = " الحساب";
            gv.Columns[nameof(_AllAmount_View.amount)].HeaderText = "مبلغ ";
            gv.Columns[nameof(_AllAmount_View.nots)].HeaderText = "ملاحظات";
            gv.Columns[nameof(_AllAmount_View.DateServer)].HeaderText = "تاريخ ";
            gv.Columns[nameof(_AllAmount_View.user_name)].HeaderText = "الموظف ";
            gv.Columns[nameof(_AllAmount_View.name_fara)].HeaderText = "الفرع ";
            gv.Columns[nameof(_AllAmount_View.cash_name)].HeaderText = "الدفع";
        }

        private async void bt_search_Click(object sender, EventArgs e)
        {
            await getdata();
        }
        private void gv_kushf_with_marid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            DataGridView grid = sender as DataGridView;
            int id = Convert.ToInt32(grid.Rows[e.RowIndex].Cells[nameof(_AllAmount_View.id)].Value.ToString());
            add_amount _add_amount_client = new add_amount(id);
            _add_amount_client.ShowDialog();
            bt_search.PerformClick();
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (gv_out.RowCount == 0)
                return;
            List<ReportParameter> para = new List<ReportParameter>();
            para.Add(new ReportParameter("p_date_from", p_date_from));
            para.Add(new ReportParameter("p_dt_date_to", p_date_to));
            para.Add(new ReportParameter("p_name_client", p_name_client));
            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("all_amount_client", gv_out.DataSource),

            };
            frm_show_report _Report = new frm_show_report(para, "all_amount_client", ReportDataSource, true);
            _Report.Show();
        }
        public async Task getdata()
        {

            var user = dr_user.SelectedValue?.ToString() ?? string.Empty;
            var fara = dr_fara.SelectedValue?.ToString() ?? string.Empty;
            var typeAmount = dr_type_amount.SelectedValue?.ToString() ?? string.Empty;
            var account = dr_account.SelectedValue?.ToString() ?? string.Empty;
            var typeCach = dr_type_cach.SelectedValue?.ToString() ?? string.Empty;
            var nots = tx_nots?.Text ?? string.Empty;

            List<AllAmount_View> list  = await C_All_Amount.SerchAllAmount(
                user,
                fara,
                dt_date_from.Value.Date.ToString("yyyy/MM/dd"),
                dt_date_to.Value.Date.ToString("yyyy/MM/dd"),
                typeAmount,
                account,
                typeCach,
                nots
            );
            gv_in.DataSource = list.Where(x => x.type_amount == 1).ToList();
            gv_out.DataSource= list.Where(x => x.type_amount == 2).ToList();
            lp_amount.Text = list.Where(x => x.type_amount == 1).Sum(x => x.amount).ToString();
            lp_amount_out.Text = list.Where(x => x.type_amount == 2).Sum(x => x.amount).ToString();
            lp_total.Text = (list.Where(x => x.type_amount == 1).Sum(x => x.amount) - list.Where(x => x.type_amount == 2).Sum(x => x.amount)).ToString();
            p_date_from = null;
            p_date_to = null;
            p_date_from = dt_date_from.Value.ToString();
            p_date_to = dt_date_to.Value.ToString();
        }
        private void dr_type_amount_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (dr_type_amount.SelectedValue.ToString() != "0")
            {
                dr_account.IntializeData(db.All_accounts.Where(x => x.type_amount == (int)dr_type_amount.SelectedValue && x.type_acount == 3).ToList(), true);
            }
            else
                dr_account.DataSource = null;
        }

        private void dr_fara_SelectionChangeCommitted(object sender, EventArgs e)
        {
            dr_user.IntializeData(Session.usersfara(Session.ConvertInt(dr_fara.SelectedValue.ToString())), nameof(user.user_name), nameof(user.id));
            dr_user.SelectedValue = Session.User_login.id;
            dr_user.Enabled = dr_fara.Enabled = !((Session.Accsess)Session.User_setting().AcssessStore == Session.Accsess.mowazf);
            if (dr_user.SelectedIndex == -1)
                dr_user.SelectedIndex = 0;
        }
    }
}
