﻿namespace tnerhbeauty
{
    partial class frm_All_Amount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_All_Amount));
            this.bt_search = new System.Windows.Forms.Button();
            this.lb_mas = new System.Windows.Forms.Label();
            this.lp_titel = new System.Windows.Forms.Label();
            this.btn_print = new System.Windows.Forms.Button();
            this.dr_fara = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dr_selct_report = new System.Windows.Forms.ComboBox();
            this.dr_user = new System.Windows.Forms.ComboBox();
            this.dt_date_from = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dt_date_to = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.pic_login = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.gv_in = new tnerhbeauty.Class.datagrid();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_in_count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_in_cash_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_in_name_fara = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_in_user_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_out = new tnerhbeauty.Class.datagrid();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_out_count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_out_cash_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_out_name_fara = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_out_user_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_total_out = new tnerhbeauty.Class.datagrid();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_total_in = new tnerhbeauty.Class.datagrid();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datagrid1 = new tnerhbeauty.Class.datagrid();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_0_count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_0_cash_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_0_name_fara = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_0_user_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_in)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_out)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_total_out)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_total_in)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_search
            // 
            this.bt_search.BackColor = System.Drawing.Color.Purple;
            this.bt_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_search.Dock = System.Windows.Forms.DockStyle.Left;
            this.bt_search.FlatAppearance.BorderSize = 0;
            this.bt_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_search.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.bt_search.ForeColor = System.Drawing.Color.White;
            this.bt_search.Location = new System.Drawing.Point(794, 46);
            this.bt_search.Margin = new System.Windows.Forms.Padding(4);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(93, 34);
            this.bt_search.TabIndex = 55;
            this.bt_search.Text = "بحث";
            this.bt_search.UseVisualStyleBackColor = false;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // lb_mas
            // 
            this.lb_mas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lb_mas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_mas.Font = new System.Drawing.Font("Tahoma", 11.25F);
            this.lb_mas.ForeColor = System.Drawing.Color.White;
            this.lb_mas.Location = new System.Drawing.Point(0, 904);
            this.lb_mas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_mas.Name = "lb_mas";
            this.lb_mas.Size = new System.Drawing.Size(1628, 38);
            this.lb_mas.TabIndex = 64;
            this.lb_mas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_titel
            // 
            this.lp_titel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lp_titel.Dock = System.Windows.Forms.DockStyle.Top;
            this.lp_titel.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_titel.ForeColor = System.Drawing.Color.White;
            this.lp_titel.Image = global::tnerhbeauty.Properties.Resources.Contact_List;
            this.lp_titel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp_titel.Location = new System.Drawing.Point(0, 0);
            this.lp_titel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_titel.Name = "lp_titel";
            this.lp_titel.Size = new System.Drawing.Size(1628, 41);
            this.lp_titel.TabIndex = 66;
            this.lp_titel.Text = "تقرير العمليات اليومية";
            this.lp_titel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_print.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_print.FlatAppearance.BorderSize = 0;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(5, 46);
            this.btn_print.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(89, 34);
            this.btn_print.TabIndex = 81;
            this.btn_print.Text = "طباعة";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // dr_fara
            // 
            this.dr_fara.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dr_fara.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_fara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_fara.FormattingEnabled = true;
            this.dr_fara.Location = new System.Drawing.Point(1259, 53);
            this.dr_fara.Margin = new System.Windows.Forms.Padding(4);
            this.dr_fara.Name = "dr_fara";
            this.dr_fara.Size = new System.Drawing.Size(116, 27);
            this.dr_fara.TabIndex = 142;
            this.dr_fara.SelectedIndexChanged += new System.EventHandler(this.dr_fara_SelectedIndexChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel1.Controls.Add(this.dr_selct_report, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.dr_user, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.dr_fara, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.dt_date_from, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dt_date_to, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.bt_search, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_print, 6, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(14, 44);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1603, 84);
            this.tableLayoutPanel1.TabIndex = 143;
            // 
            // dr_selct_report
            // 
            this.dr_selct_report.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dr_selct_report.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_selct_report.DropDownWidth = 100;
            this.dr_selct_report.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_selct_report.FormattingEnabled = true;
            this.dr_selct_report.Items.AddRange(new object[] {
            "تقرير نهاية اليوم مجمع",
            "تقرير نهاية اليوم طرق الدفع  ",
            "تقرير  نهاية اليوم تفصيلي"});
            this.dr_selct_report.Location = new System.Drawing.Point(895, 53);
            this.dr_selct_report.Margin = new System.Windows.Forms.Padding(4);
            this.dr_selct_report.Name = "dr_selct_report";
            this.dr_selct_report.Size = new System.Drawing.Size(174, 27);
            this.dr_selct_report.TabIndex = 155;
            // 
            // dr_user
            // 
            this.dr_user.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dr_user.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_user.DropDownWidth = 100;
            this.dr_user.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_user.FormattingEnabled = true;
            this.dr_user.Location = new System.Drawing.Point(1077, 53);
            this.dr_user.Margin = new System.Windows.Forms.Padding(4);
            this.dr_user.Name = "dr_user";
            this.dr_user.Size = new System.Drawing.Size(174, 27);
            this.dr_user.TabIndex = 154;
            // 
            // dt_date_from
            // 
            this.dt_date_from.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dt_date_from.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.dt_date_from.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dt_date_from.Location = new System.Drawing.Point(1495, 54);
            this.dt_date_from.Margin = new System.Windows.Forms.Padding(4);
            this.dt_date_from.Name = "dt_date_from";
            this.dt_date_from.RightToLeftLayout = true;
            this.dt_date_from.Size = new System.Drawing.Size(104, 26);
            this.dt_date_from.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(1495, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 22);
            this.label2.TabIndex = 6;
            this.label2.Text = "من تاريخ";
            // 
            // dt_date_to
            // 
            this.dt_date_to.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dt_date_to.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.dt_date_to.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dt_date_to.Location = new System.Drawing.Point(1383, 54);
            this.dt_date_to.Margin = new System.Windows.Forms.Padding(4);
            this.dt_date_to.Name = "dt_date_to";
            this.dt_date_to.RightToLeftLayout = true;
            this.dt_date_to.Size = new System.Drawing.Size(104, 26);
            this.dt_date_to.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(1383, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "الي تاريخ";
            // 
            // pic_login
            // 
            this.pic_login.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pic_login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pic_login.Image = global::tnerhbeauty.Properties.Resources.kOnzy;
            this.pic_login.Location = new System.Drawing.Point(7, 910);
            this.pic_login.Margin = new System.Windows.Forms.Padding(0);
            this.pic_login.Name = "pic_login";
            this.pic_login.Size = new System.Drawing.Size(26, 27);
            this.pic_login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_login.TabIndex = 153;
            this.pic_login.TabStop = false;
            this.pic_login.Visible = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.6087F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 1.086957F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.60869F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 1.086956F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.60869F));
            this.tableLayoutPanel2.Controls.Add(this.gv_in, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.gv_out, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.gv_total_out, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.gv_total_in, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.datagrid1, 4, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(14, 135);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 73.51778F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.48221F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1603, 764);
            this.tableLayoutPanel2.TabIndex = 154;
            // 
            // gv_in
            // 
            this.gv_in.AllowUserToAddRows = false;
            this.gv_in.AllowUserToDeleteRows = false;
            this.gv_in.AllowUserToResizeColumns = false;
            this.gv_in.AllowUserToResizeRows = false;
            this.gv_in.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gv_in.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_in.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_in.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv_in.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv_in.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_in.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_in.ColumnHeadersHeight = 30;
            this.gv_in.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv_in.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.gv_in_count,
            this.gv_in_cash_name,
            this.gv_in_name_fara,
            this.gv_in_user_name});
            this.gv_in.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_in.EnableHeadersVisualStyles = false;
            this.gv_in.GridColor = System.Drawing.Color.Black;
            this.gv_in.Location = new System.Drawing.Point(1081, 0);
            this.gv_in.Margin = new System.Windows.Forms.Padding(0);
            this.gv_in.Name = "gv_in";
            this.gv_in.ReadOnly = true;
            this.gv_in.RowHeadersVisible = false;
            this.gv_in.RowHeadersWidth = 30;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_in.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_in.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_in.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_in.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_in.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv_in.RowTemplate.Height = 30;
            this.gv_in.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_in.Size = new System.Drawing.Size(522, 561);
            this.gv_in.TabIndex = 67;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "type_name";
            this.dataGridViewTextBoxColumn1.FillWeight = 113.5651F;
            this.dataGridViewTextBoxColumn1.HeaderText = "العملية";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "amount";
            this.dataGridViewTextBoxColumn2.FillWeight = 113.5651F;
            this.dataGridViewTextBoxColumn2.HeaderText = "القيمة";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // gv_in_count
            // 
            this.gv_in_count.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.gv_in_count.DataPropertyName = "count";
            this.gv_in_count.FillWeight = 40F;
            this.gv_in_count.HeaderText = "العدد";
            this.gv_in_count.MinimumWidth = 6;
            this.gv_in_count.Name = "gv_in_count";
            this.gv_in_count.ReadOnly = true;
            this.gv_in_count.Width = 40;
            // 
            // gv_in_cash_name
            // 
            this.gv_in_cash_name.DataPropertyName = "cash_name";
            this.gv_in_cash_name.FillWeight = 113.5651F;
            this.gv_in_cash_name.HeaderText = "الدفع";
            this.gv_in_cash_name.MinimumWidth = 6;
            this.gv_in_cash_name.Name = "gv_in_cash_name";
            this.gv_in_cash_name.ReadOnly = true;
            // 
            // gv_in_name_fara
            // 
            this.gv_in_name_fara.DataPropertyName = "name_fara";
            this.gv_in_name_fara.FillWeight = 113.5651F;
            this.gv_in_name_fara.HeaderText = "الفرع";
            this.gv_in_name_fara.MinimumWidth = 6;
            this.gv_in_name_fara.Name = "gv_in_name_fara";
            this.gv_in_name_fara.ReadOnly = true;
            // 
            // gv_in_user_name
            // 
            this.gv_in_user_name.DataPropertyName = "user_name";
            this.gv_in_user_name.FillWeight = 113.5651F;
            this.gv_in_user_name.HeaderText = "الموظف";
            this.gv_in_user_name.MinimumWidth = 6;
            this.gv_in_user_name.Name = "gv_in_user_name";
            this.gv_in_user_name.ReadOnly = true;
            // 
            // gv_out
            // 
            this.gv_out.AllowUserToAddRows = false;
            this.gv_out.AllowUserToDeleteRows = false;
            this.gv_out.AllowUserToResizeColumns = false;
            this.gv_out.AllowUserToResizeRows = false;
            this.gv_out.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_out.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_out.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv_out.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv_out.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_out.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gv_out.ColumnHeadersHeight = 30;
            this.gv_out.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv_out.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.gv_out_count,
            this.gv_out_cash_name,
            this.gv_out_name_fara,
            this.gv_out_user_name});
            this.gv_out.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_out.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_out.EnableHeadersVisualStyles = false;
            this.gv_out.GridColor = System.Drawing.Color.Black;
            this.gv_out.Location = new System.Drawing.Point(542, 0);
            this.gv_out.Margin = new System.Windows.Forms.Padding(0);
            this.gv_out.Name = "gv_out";
            this.gv_out.ReadOnly = true;
            this.gv_out.RowHeadersVisible = false;
            this.gv_out.RowHeadersWidth = 51;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_out.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_out.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_out.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_out.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_out.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv_out.RowTemplate.Height = 30;
            this.gv_out.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_out.Size = new System.Drawing.Size(522, 561);
            this.gv_out.TabIndex = 68;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "type_name";
            this.dataGridViewTextBoxColumn5.FillWeight = 107.1658F;
            this.dataGridViewTextBoxColumn5.HeaderText = "العملية";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "amount";
            this.dataGridViewTextBoxColumn6.FillWeight = 107.1658F;
            this.dataGridViewTextBoxColumn6.HeaderText = "القيمة";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // gv_out_count
            // 
            this.gv_out_count.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.gv_out_count.DataPropertyName = "count";
            this.gv_out_count.FillWeight = 40F;
            this.gv_out_count.HeaderText = "العدد";
            this.gv_out_count.MinimumWidth = 6;
            this.gv_out_count.Name = "gv_out_count";
            this.gv_out_count.ReadOnly = true;
            this.gv_out_count.Width = 40;
            // 
            // gv_out_cash_name
            // 
            this.gv_out_cash_name.DataPropertyName = "cash_name";
            this.gv_out_cash_name.FillWeight = 107.1658F;
            this.gv_out_cash_name.HeaderText = "الدفع";
            this.gv_out_cash_name.MinimumWidth = 6;
            this.gv_out_cash_name.Name = "gv_out_cash_name";
            this.gv_out_cash_name.ReadOnly = true;
            // 
            // gv_out_name_fara
            // 
            this.gv_out_name_fara.DataPropertyName = "name_fara";
            this.gv_out_name_fara.FillWeight = 107.1658F;
            this.gv_out_name_fara.HeaderText = "الفرع";
            this.gv_out_name_fara.MinimumWidth = 6;
            this.gv_out_name_fara.Name = "gv_out_name_fara";
            this.gv_out_name_fara.ReadOnly = true;
            // 
            // gv_out_user_name
            // 
            this.gv_out_user_name.DataPropertyName = "user_name";
            this.gv_out_user_name.FillWeight = 107.1658F;
            this.gv_out_user_name.HeaderText = "الموظف";
            this.gv_out_user_name.MinimumWidth = 6;
            this.gv_out_user_name.Name = "gv_out_user_name";
            this.gv_out_user_name.ReadOnly = true;
            // 
            // gv_total_out
            // 
            this.gv_total_out.AllowUserToAddRows = false;
            this.gv_total_out.AllowUserToDeleteRows = false;
            this.gv_total_out.AllowUserToResizeColumns = false;
            this.gv_total_out.AllowUserToResizeRows = false;
            this.gv_total_out.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_total_out.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_total_out.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv_total_out.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_total_out.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_total_out.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_total_out.ColumnHeadersHeight = 30;
            this.gv_total_out.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv_total_out.ColumnHeadersVisible = false;
            this.gv_total_out.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn10});
            this.gv_total_out.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_total_out.EnableHeadersVisualStyles = false;
            this.gv_total_out.GridColor = System.Drawing.Color.Black;
            this.gv_total_out.Location = new System.Drawing.Point(584, 561);
            this.gv_total_out.Margin = new System.Windows.Forms.Padding(0);
            this.gv_total_out.Name = "gv_total_out";
            this.gv_total_out.ReadOnly = true;
            this.gv_total_out.RowHeadersVisible = false;
            this.gv_total_out.RowHeadersWidth = 51;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_total_out.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.gv_total_out.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_total_out.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_total_out.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_total_out.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv_total_out.RowTemplate.Height = 30;
            this.gv_total_out.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_total_out.Size = new System.Drawing.Size(480, 161);
            this.gv_total_out.TabIndex = 70;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "cash_name";
            this.dataGridViewTextBoxColumn9.HeaderText = "الدفع";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "count";
            this.dataGridViewTextBoxColumn11.HeaderText = "العدد";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "amount";
            this.dataGridViewTextBoxColumn10.HeaderText = "القيمة";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // gv_total_in
            // 
            this.gv_total_in.AllowUserToAddRows = false;
            this.gv_total_in.AllowUserToDeleteRows = false;
            this.gv_total_in.AllowUserToResizeColumns = false;
            this.gv_total_in.AllowUserToResizeRows = false;
            this.gv_total_in.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_total_in.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_total_in.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv_total_in.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_total_in.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_total_in.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.gv_total_in.ColumnHeadersHeight = 30;
            this.gv_total_in.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv_total_in.ColumnHeadersVisible = false;
            this.gv_total_in.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.gv_total_in.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_total_in.EnableHeadersVisualStyles = false;
            this.gv_total_in.GridColor = System.Drawing.Color.Black;
            this.gv_total_in.Location = new System.Drawing.Point(1123, 561);
            this.gv_total_in.Margin = new System.Windows.Forms.Padding(0);
            this.gv_total_in.Name = "gv_total_in";
            this.gv_total_in.ReadOnly = true;
            this.gv_total_in.RowHeadersVisible = false;
            this.gv_total_in.RowHeadersWidth = 51;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_total_in.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.gv_total_in.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_total_in.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_total_in.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_total_in.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv_total_in.RowTemplate.Height = 30;
            this.gv_total_in.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_total_in.Size = new System.Drawing.Size(480, 161);
            this.gv_total_in.TabIndex = 68;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "cash_name";
            this.dataGridViewTextBoxColumn12.HeaderText = "الدفع";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "count";
            this.dataGridViewTextBoxColumn13.HeaderText = "العدد";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "amount";
            this.dataGridViewTextBoxColumn14.HeaderText = "القيمة";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // datagrid1
            // 
            this.datagrid1.AllowUserToAddRows = false;
            this.datagrid1.AllowUserToDeleteRows = false;
            this.datagrid1.AllowUserToResizeColumns = false;
            this.datagrid1.AllowUserToResizeRows = false;
            this.datagrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.datagrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.datagrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datagrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.datagrid1.ColumnHeadersHeight = 30;
            this.datagrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.datagrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn18,
            this.gv_0_count,
            this.gv_0_cash_name,
            this.gv_0_name_fara,
            this.gv_0_user_name});
            this.datagrid1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.datagrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datagrid1.EnableHeadersVisualStyles = false;
            this.datagrid1.GridColor = System.Drawing.Color.Black;
            this.datagrid1.Location = new System.Drawing.Point(0, 0);
            this.datagrid1.Margin = new System.Windows.Forms.Padding(0);
            this.datagrid1.Name = "datagrid1";
            this.datagrid1.ReadOnly = true;
            this.datagrid1.RowHeadersVisible = false;
            this.datagrid1.RowHeadersWidth = 51;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.datagrid1.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.datagrid1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.datagrid1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.datagrid1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.datagrid1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.datagrid1.RowTemplate.Height = 30;
            this.datagrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagrid1.Size = new System.Drawing.Size(525, 561);
            this.datagrid1.TabIndex = 71;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "type_name";
            this.dataGridViewTextBoxColumn15.FillWeight = 107.1658F;
            this.dataGridViewTextBoxColumn15.HeaderText = "العملية";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "amount";
            this.dataGridViewTextBoxColumn18.FillWeight = 107.1658F;
            this.dataGridViewTextBoxColumn18.HeaderText = "القيمة";
            this.dataGridViewTextBoxColumn18.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // gv_0_count
            // 
            this.gv_0_count.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.gv_0_count.DataPropertyName = "count";
            this.gv_0_count.FillWeight = 40F;
            this.gv_0_count.HeaderText = "العدد";
            this.gv_0_count.MinimumWidth = 6;
            this.gv_0_count.Name = "gv_0_count";
            this.gv_0_count.ReadOnly = true;
            this.gv_0_count.Width = 40;
            // 
            // gv_0_cash_name
            // 
            this.gv_0_cash_name.DataPropertyName = "cash_name";
            this.gv_0_cash_name.FillWeight = 107.1658F;
            this.gv_0_cash_name.HeaderText = "الدفع";
            this.gv_0_cash_name.MinimumWidth = 6;
            this.gv_0_cash_name.Name = "gv_0_cash_name";
            this.gv_0_cash_name.ReadOnly = true;
            // 
            // gv_0_name_fara
            // 
            this.gv_0_name_fara.DataPropertyName = "name_fara";
            this.gv_0_name_fara.FillWeight = 107.1658F;
            this.gv_0_name_fara.HeaderText = "الفرع";
            this.gv_0_name_fara.MinimumWidth = 6;
            this.gv_0_name_fara.Name = "gv_0_name_fara";
            this.gv_0_name_fara.ReadOnly = true;
            // 
            // gv_0_user_name
            // 
            this.gv_0_user_name.DataPropertyName = "user_name";
            this.gv_0_user_name.FillWeight = 107.1658F;
            this.gv_0_user_name.HeaderText = "الموظف";
            this.gv_0_user_name.MinimumWidth = 6;
            this.gv_0_user_name.Name = "gv_0_user_name";
            this.gv_0_user_name.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "type_name";
            this.Column1.HeaderText = "العملية";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 125;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "cash_name";
            this.Column4.HeaderText = "الدفع";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 125;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "count";
            this.Column3.HeaderText = "العدد";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 125;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "amount";
            this.Column2.HeaderText = "القيمة";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 125;
            // 
            // frm_All_Amount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1628, 942);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.pic_login);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.lp_titel);
            this.Controls.Add(this.lb_mas);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_All_Amount";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Physical Checkup";
            this.Load += new System.EventHandler(this.all_kushufat_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_in)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_out)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_total_out)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_total_in)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button bt_search;
        private System.Windows.Forms.Label lb_mas;
        private System.Windows.Forms.Label lp_titel;
        private Class.datagrid gv_in;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.ComboBox dr_fara;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker dt_date_from;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pic_login;
        private System.Windows.Forms.ComboBox dr_user;
        private System.Windows.Forms.DateTimePicker dt_date_to;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Class.datagrid gv_out;
        private System.Windows.Forms.ComboBox dr_selct_report;
        private Class.datagrid gv_total_in;
        private Class.datagrid gv_total_out;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private Class.datagrid datagrid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_out_count;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_out_cash_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_out_name_fara;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_out_user_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_0_count;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_0_cash_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_0_name_fara;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_0_user_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_in_count;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_in_cash_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_in_name_fara;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_in_user_name;
    }
}