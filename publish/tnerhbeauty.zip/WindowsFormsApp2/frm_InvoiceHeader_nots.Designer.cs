﻿namespace tnerhbeauty
{
    partial class frm_InvoiceHeader_nots
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label10;
            System.Windows.Forms.Label label11;
            System.Windows.Forms.Label label12;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_InvoiceHeader_nots));
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lp_Balance_client = new System.Windows.Forms.Label();
            this.lb_mas = new System.Windows.Forms.Label();
            this.btn_new = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.tx_name_cient = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tx_ItemName = new System.Windows.Forms.TextBox();
            this.tx_Price = new System.Windows.Forms.TextBox();
            this.tx_ItemQty = new System.Windows.Forms.TextBox();
            this.tx_Total_product = new System.Windows.Forms.TextBox();
            this.tx_total_item = new System.Windows.Forms.TextBox();
            this.tx_Net = new System.Windows.Forms.TextBox();
            this.tx_Balance_type = new System.Windows.Forms.Label();
            this.tx_Balance = new System.Windows.Forms.Label();
            this.TxTotalQty = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.tx_id_cient = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.ch_not_celar_ItemQty = new System.Windows.Forms.CheckBox();
            this.ch_kilo = new System.Windows.Forms.CheckBox();
            this.lb_balance = new System.Windows.Forms.Label();
            this.bt_save_is_agel = new System.Windows.Forms.Button();
            this.btn_find_client = new System.Windows.Forms.Button();
            this.btn_client_un_save = new System.Windows.Forms.Button();
            this.btn_client_save = new System.Windows.Forms.Button();
            this.ch_notes = new System.Windows.Forms.CheckBox();
            this.ch_auto_insert = new System.Windows.Forms.CheckBox();
            this.ch_is_agel = new System.Windows.Forms.CheckBox();
            this.tx_Notes = new System.Windows.Forms.RichTextBox();
            this.tx_DateAdd = new System.Windows.Forms.DateTimePicker();
            this.btn_add_grid = new System.Windows.Forms.Button();
            this.lp_TotalPrice_ditals = new System.Windows.Forms.Label();
            this.lp_total_item = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tx_TotalPrice_ditals = new System.Windows.Forms.TextBox();
            this.tx_discunt_item = new System.Windows.Forms.TextBox();
            this.tx_Discount = new System.Windows.Forms.TextBox();
            this.tx_Extra = new System.Windows.Forms.TextBox();
            this.dr_Discount_type = new System.Windows.Forms.ComboBox();
            this.tx_Discount_percent = new System.Windows.Forms.TextBox();
            this.tx_Extra_percent = new System.Windows.Forms.TextBox();
            this.dr_Extra_type = new System.Windows.Forms.ComboBox();
            this.gv_InvoiceDetails = new System.Windows.Forms.DataGridView();
            this.DrItemID = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.DrStore_id = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.deleteitem = new System.Windows.Forms.DataGridViewImageColumn();
            this.dr_price = new System.Windows.Forms.ComboBox();
            this.lp_Price = new System.Windows.Forms.Label();
            this.dr_store = new System.Windows.Forms.ComboBox();
            this.dr_discunt_item = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_print = new System.Windows.Forms.Button();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.lp_titel = new System.Windows.Forms.Label();
            this.pic_login = new System.Windows.Forms.PictureBox();
            this.lpstore_to = new System.Windows.Forms.Label();
            this.dr_store_to = new System.Windows.Forms.ComboBox();
            this.PanClient = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pan_Balance_client = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.pan_Total_product = new System.Windows.Forms.Panel();
            this.pan_is_agel = new System.Windows.Forms.Panel();
            this.pan_Discount = new System.Windows.Forms.Panel();
            this.pan_Extra = new System.Windows.Forms.Panel();
            this.PanPrice = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.pan = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.PanTotal = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.gvSerchProduct = new tnerhbeauty.Class.datagrid();
            label5 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_InvoiceDetails)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).BeginInit();
            this.PanClient.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.pan_Balance_client.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.pan_Total_product.SuspendLayout();
            this.pan_is_agel.SuspendLayout();
            this.pan_Discount.SuspendLayout();
            this.pan_Extra.SuspendLayout();
            this.PanPrice.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.pan.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.PanTotal.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvSerchProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            label5.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            label5.Location = new System.Drawing.Point(269, 6);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(101, 15);
            label5.TabIndex = 110;
            label5.Text = "اجمالي الاصناف";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            label8.Location = new System.Drawing.Point(263, 21);
            label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(36, 15);
            label8.TabIndex = 113;
            label8.Text = "الصافي";
            // 
            // label10
            // 
            label10.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            label10.Location = new System.Drawing.Point(339, 60);
            label10.Margin = new System.Windows.Forms.Padding(3);
            label10.Name = "label10";
            label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            label10.Size = new System.Drawing.Size(65, 21);
            label10.TabIndex = 120;
            label10.Text = "ملاحظات";
            label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            label11.AutoSize = true;
            label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label11.Location = new System.Drawing.Point(129, 4);
            label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(22, 19);
            label11.TabIndex = 125;
            label11.Text = "=";
            label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            label12.AutoSize = true;
            label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label12.Location = new System.Drawing.Point(129, 4);
            label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(22, 19);
            label12.TabIndex = 127;
            label12.Text = "=";
            label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(222, 3);
            this.label14.Margin = new System.Windows.Forms.Padding(3);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label14.Size = new System.Drawing.Size(65, 21);
            this.label14.TabIndex = 159;
            this.label14.Text = "اجمالي الكمية";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(339, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(3);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(65, 21);
            this.label1.TabIndex = 132;
            this.label1.Text = "العميل";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(339, 57);
            this.label6.Margin = new System.Windows.Forms.Padding(3);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(65, 21);
            this.label6.TabIndex = 136;
            this.label6.Text = "قائمة الاسعار";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lp_Balance_client
            // 
            this.lp_Balance_client.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            this.lp_Balance_client.Location = new System.Drawing.Point(339, 30);
            this.lp_Balance_client.Margin = new System.Windows.Forms.Padding(3);
            this.lp_Balance_client.Name = "lp_Balance_client";
            this.lp_Balance_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lp_Balance_client.Size = new System.Drawing.Size(65, 21);
            this.lp_Balance_client.TabIndex = 140;
            this.lp_Balance_client.Text = "رصيد العميل";
            this.lp_Balance_client.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lp_Balance_client.Visible = false;
            // 
            // lb_mas
            // 
            this.lb_mas.BackColor = System.Drawing.Color.Gray;
            this.lb_mas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_mas.Font = new System.Drawing.Font("Tahoma", 11.25F);
            this.lb_mas.ForeColor = System.Drawing.Color.White;
            this.lb_mas.Location = new System.Drawing.Point(0, 575);
            this.lb_mas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_mas.Name = "lb_mas";
            this.lb_mas.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lb_mas.Size = new System.Drawing.Size(1221, 30);
            this.lb_mas.TabIndex = 53;
            this.lb_mas.Text = "F11 = اضافة ;  F12 = SAVE ; F2  NEW  ;  DELETE = DELETE ; CTRL + P = PRINT";
            this.lb_mas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_new
            // 
            this.btn_new.BackColor = System.Drawing.Color.DarkGray;
            this.btn_new.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_new.FlatAppearance.BorderSize = 0;
            this.btn_new.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_new.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_new.ForeColor = System.Drawing.Color.White;
            this.btn_new.Location = new System.Drawing.Point(229, 3);
            this.btn_new.Margin = new System.Windows.Forms.Padding(20, 3, 3, 3);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(90, 29);
            this.btn_new.TabIndex = 55;
            this.btn_new.Text = "جديد";
            this.btn_new.UseVisualStyleBackColor = false;
            this.btn_new.Visible = false;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(343, 3);
            this.btn_save.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(90, 29);
            this.btn_save.TabIndex = 54;
            this.btn_save.Text = "حفظ";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Visible = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // tx_name_cient
            // 
            this.tx_name_cient.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tx_name_cient.Cursor = System.Windows.Forms.Cursors.No;
            this.tx_name_cient.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider1.SetIconAlignment(this.tx_name_cient, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_name_cient.Location = new System.Drawing.Point(87, 3);
            this.tx_name_cient.Margin = new System.Windows.Forms.Padding(3);
            this.tx_name_cient.Name = "tx_name_cient";
            this.tx_name_cient.Size = new System.Drawing.Size(216, 21);
            this.tx_name_cient.TabIndex = 67;
            this.tx_name_cient.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // errorProvider1
            // 
            this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider1.ContainerControl = this;
            this.errorProvider1.RightToLeft = true;
            // 
            // tx_ItemName
            // 
            this.tx_ItemName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_ItemName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.errorProvider1.SetIconAlignment(this.tx_ItemName, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_ItemName.Location = new System.Drawing.Point(841, 75);
            this.tx_ItemName.Margin = new System.Windows.Forms.Padding(0);
            this.tx_ItemName.Name = "tx_ItemName";
            this.tx_ItemName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tx_ItemName.Size = new System.Drawing.Size(365, 26);
            this.tx_ItemName.TabIndex = 0;
            this.tx_ItemName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tx_ItemName.TextChanged += new System.EventHandler(this.tx_ItemName_TextChanged);
            this.tx_ItemName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tx_ItemName_KeyDown);
            // 
            // tx_Price
            // 
            this.tx_Price.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_Price.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider1.SetIconAlignment(this.tx_Price, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_Price.Location = new System.Drawing.Point(364, 36);
            this.tx_Price.Margin = new System.Windows.Forms.Padding(16, 5, 0, 0);
            this.tx_Price.Name = "tx_Price";
            this.tx_Price.Size = new System.Drawing.Size(100, 26);
            this.tx_Price.TabIndex = 105;
            this.tx_Price.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tx_Price.TextChanged += new System.EventHandler(this.tx_ItemQty_TextChanged);
            this.tx_Price.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tx_Price_KeyDown);
            this.tx_Price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_Discount_KeyPress);
            // 
            // tx_ItemQty
            // 
            this.tx_ItemQty.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_ItemQty.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider1.SetIconAlignment(this.tx_ItemQty, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_ItemQty.Location = new System.Drawing.Point(591, 75);
            this.tx_ItemQty.Name = "tx_ItemQty";
            this.tx_ItemQty.Size = new System.Drawing.Size(100, 26);
            this.tx_ItemQty.TabIndex = 106;
            this.tx_ItemQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tx_ItemQty.Enter += new System.EventHandler(this.tx_ItemQty_Enter);
            this.tx_ItemQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tx_ItemQty_KeyDown);
            this.tx_ItemQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_ItemQty_KeyPress);
            this.tx_ItemQty.Leave += new System.EventHandler(this.tx_ItemQty_Leave);
            // 
            // tx_Total_product
            // 
            this.tx_Total_product.Cursor = System.Windows.Forms.Cursors.No;
            this.tx_Total_product.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider1.SetIconAlignment(this.tx_Total_product, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_Total_product.Location = new System.Drawing.Point(18, 3);
            this.tx_Total_product.Name = "tx_Total_product";
            this.tx_Total_product.ReadOnly = true;
            this.tx_Total_product.Size = new System.Drawing.Size(243, 23);
            this.tx_Total_product.TabIndex = 114;
            this.tx_Total_product.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tx_total_item
            // 
            this.tx_total_item.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_total_item.Cursor = System.Windows.Forms.Cursors.No;
            this.tx_total_item.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider1.SetIconAlignment(this.tx_total_item, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_total_item.Location = new System.Drawing.Point(16, 36);
            this.tx_total_item.Margin = new System.Windows.Forms.Padding(16, 5, 0, 0);
            this.tx_total_item.Name = "tx_total_item";
            this.tx_total_item.ReadOnly = true;
            this.tx_total_item.Size = new System.Drawing.Size(100, 26);
            this.tx_total_item.TabIndex = 109;
            this.tx_total_item.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tx_total_item.Visible = false;
            // 
            // tx_Net
            // 
            this.tx_Net.BackColor = System.Drawing.Color.LimeGreen;
            this.tx_Net.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tx_Net.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_Net.ForeColor = System.Drawing.Color.White;
            this.errorProvider1.SetIconAlignment(this.tx_Net, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_Net.Location = new System.Drawing.Point(18, 3);
            this.tx_Net.Margin = new System.Windows.Forms.Padding(0);
            this.tx_Net.Name = "tx_Net";
            this.tx_Net.ReadOnly = true;
            this.tx_Net.Size = new System.Drawing.Size(243, 56);
            this.tx_Net.TabIndex = 117;
            this.tx_Net.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tx_Balance_type
            // 
            this.tx_Balance_type.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tx_Balance_type.Cursor = System.Windows.Forms.Cursors.No;
            this.tx_Balance_type.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider1.SetIconAlignment(this.tx_Balance_type, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_Balance_type.Location = new System.Drawing.Point(240, 3);
            this.tx_Balance_type.Margin = new System.Windows.Forms.Padding(3);
            this.tx_Balance_type.Name = "tx_Balance_type";
            this.tx_Balance_type.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_Balance_type.Size = new System.Drawing.Size(63, 21);
            this.tx_Balance_type.TabIndex = 139;
            this.tx_Balance_type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tx_Balance
            // 
            this.tx_Balance.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_Balance.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tx_Balance.Cursor = System.Windows.Forms.Cursors.No;
            this.tx_Balance.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider1.SetIconAlignment(this.tx_Balance, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.tx_Balance.Location = new System.Drawing.Point(4, 3);
            this.tx_Balance.Margin = new System.Windows.Forms.Padding(3);
            this.tx_Balance.Name = "tx_Balance";
            this.tx_Balance.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_Balance.Size = new System.Drawing.Size(230, 21);
            this.tx_Balance.TabIndex = 141;
            this.tx_Balance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TxTotalQty
            // 
            this.TxTotalQty.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TxTotalQty.Cursor = System.Windows.Forms.Cursors.No;
            this.TxTotalQty.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider1.SetIconAlignment(this.TxTotalQty, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.TxTotalQty.Location = new System.Drawing.Point(3, 3);
            this.TxTotalQty.Name = "TxTotalQty";
            this.TxTotalQty.ReadOnly = true;
            this.TxTotalQty.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TxTotalQty.Size = new System.Drawing.Size(213, 23);
            this.TxTotalQty.TabIndex = 160;
            this.TxTotalQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.DarkGray;
            this.btn_delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(3, 3);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(20, 3, 3, 3);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(90, 29);
            this.btn_delete.TabIndex = 72;
            this.btn_delete.Text = "حذف";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Visible = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // tx_id_cient
            // 
            this.tx_id_cient.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tx_id_cient.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tx_id_cient.Cursor = System.Windows.Forms.Cursors.No;
            this.tx_id_cient.Location = new System.Drawing.Point(16, -365);
            this.tx_id_cient.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tx_id_cient.Name = "tx_id_cient";
            this.tx_id_cient.Size = new System.Drawing.Size(45, 21);
            this.tx_id_cient.TabIndex = 81;
            this.tx_id_cient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tx_id_cient.Visible = false;
            // 
            // toolTip1
            // 
            this.toolTip1.BackColor = System.Drawing.Color.Red;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ch_not_celar_ItemQty
            // 
            this.ch_not_celar_ItemQty.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ch_not_celar_ItemQty.AutoSize = true;
            this.ch_not_celar_ItemQty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_not_celar_ItemQty.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch_not_celar_ItemQty.ForeColor = System.Drawing.Color.DimGray;
            this.ch_not_celar_ItemQty.Location = new System.Drawing.Point(561, 81);
            this.ch_not_celar_ItemQty.Name = "ch_not_celar_ItemQty";
            this.ch_not_celar_ItemQty.Size = new System.Drawing.Size(15, 14);
            this.ch_not_celar_ItemQty.TabIndex = 129;
            this.toolTip1.SetToolTip(this.ch_not_celar_ItemQty, "احتفظ بالكمية بعد اضافة الصنف");
            this.ch_not_celar_ItemQty.UseVisualStyleBackColor = true;
            this.ch_not_celar_ItemQty.Click += new System.EventHandler(this.ch_not_celar_ItemQty_Click);
            // 
            // ch_kilo
            // 
            this.ch_kilo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ch_kilo.AutoSize = true;
            this.ch_kilo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_kilo.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch_kilo.ForeColor = System.Drawing.Color.DimGray;
            this.ch_kilo.Location = new System.Drawing.Point(604, 48);
            this.ch_kilo.Name = "ch_kilo";
            this.ch_kilo.Size = new System.Drawing.Size(79, 19);
            this.ch_kilo.TabIndex = 131;
            this.ch_kilo.Text = "الكمية بالجرام";
            this.toolTip1.SetToolTip(this.ch_kilo, "تحويل الكمية الي جرام تلقائي");
            this.ch_kilo.UseVisualStyleBackColor = true;
            this.ch_kilo.Click += new System.EventHandler(this.ch_kilo_Click);
            // 
            // lb_balance
            // 
            this.lb_balance.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_balance.AutoSize = true;
            this.lb_balance.BackColor = System.Drawing.Color.Transparent;
            this.lb_balance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lb_balance.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance.ForeColor = System.Drawing.Color.DimGray;
            this.lb_balance.Location = new System.Drawing.Point(1102, 46);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(58, 15);
            this.lb_balance.TabIndex = 145;
            this.lb_balance.Text = "رصيد الصنف";
            this.lb_balance.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.lb_balance, "رصيد الصنف");
            // 
            // bt_save_is_agel
            // 
            this.bt_save_is_agel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bt_save_is_agel.BackColor = System.Drawing.Color.Transparent;
            this.bt_save_is_agel.BackgroundImage = global::tnerhbeauty.Properties.Resources.bookmark;
            this.bt_save_is_agel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_save_is_agel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_save_is_agel.FlatAppearance.BorderSize = 0;
            this.bt_save_is_agel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.bt_save_is_agel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.bt_save_is_agel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_save_is_agel.Location = new System.Drawing.Point(99, 6);
            this.bt_save_is_agel.Name = "bt_save_is_agel";
            this.bt_save_is_agel.Size = new System.Drawing.Size(21, 21);
            this.bt_save_is_agel.TabIndex = 142;
            this.toolTip1.SetToolTip(this.bt_save_is_agel, "جعل الفاتورة نقدي دائما عند انشاء بيان جديد");
            this.bt_save_is_agel.UseVisualStyleBackColor = false;
            this.bt_save_is_agel.Click += new System.EventHandler(this.bt_save_is_agel_Click);
            // 
            // btn_find_client
            // 
            this.btn_find_client.BackColor = System.Drawing.Color.Transparent;
            this.btn_find_client.BackgroundImage = global::tnerhbeauty.Properties.Resources.find_users;
            this.btn_find_client.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_find_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_find_client.FlatAppearance.BorderSize = 0;
            this.btn_find_client.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_find_client.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btn_find_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_find_client.ForeColor = System.Drawing.Color.White;
            this.btn_find_client.Location = new System.Drawing.Point(5, 3);
            this.btn_find_client.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_find_client.Name = "btn_find_client";
            this.btn_find_client.Size = new System.Drawing.Size(21, 21);
            this.btn_find_client.TabIndex = 0;
            this.toolTip1.SetToolTip(this.btn_find_client, "بحث عن عميل");
            this.btn_find_client.UseVisualStyleBackColor = false;
            this.btn_find_client.Click += new System.EventHandler(this.btn_find_client_Click);
            // 
            // btn_client_un_save
            // 
            this.btn_client_un_save.BackColor = System.Drawing.Color.Transparent;
            this.btn_client_un_save.BackgroundImage = global::tnerhbeauty.Properties.Resources.delete;
            this.btn_client_un_save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_client_un_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_client_un_save.FlatAppearance.BorderSize = 0;
            this.btn_client_un_save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_client_un_save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_client_un_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_client_un_save.Location = new System.Drawing.Point(33, 3);
            this.btn_client_un_save.Name = "btn_client_un_save";
            this.btn_client_un_save.Size = new System.Drawing.Size(21, 21);
            this.btn_client_un_save.TabIndex = 134;
            this.toolTip1.SetToolTip(this.btn_client_un_save, "قم بازالة العميل الافتراضي");
            this.btn_client_un_save.UseVisualStyleBackColor = false;
            this.btn_client_un_save.Click += new System.EventHandler(this.BtnClientUnSave_Click);
            // 
            // btn_client_save
            // 
            this.btn_client_save.BackColor = System.Drawing.Color.Transparent;
            this.btn_client_save.BackgroundImage = global::tnerhbeauty.Properties.Resources.bookmark;
            this.btn_client_save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_client_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_client_save.FlatAppearance.BorderSize = 0;
            this.btn_client_save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_client_save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_client_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_client_save.Location = new System.Drawing.Point(60, 3);
            this.btn_client_save.Name = "btn_client_save";
            this.btn_client_save.Size = new System.Drawing.Size(21, 21);
            this.btn_client_save.TabIndex = 133;
            this.toolTip1.SetToolTip(this.btn_client_save, "جعل العميل افتراضي عند البداء");
            this.btn_client_save.UseVisualStyleBackColor = false;
            this.btn_client_save.Click += new System.EventHandler(this.ClientSave_Click);
            // 
            // ch_notes
            // 
            this.ch_notes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ch_notes.AutoSize = true;
            this.ch_notes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_notes.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch_notes.ForeColor = System.Drawing.Color.DimGray;
            this.ch_notes.Location = new System.Drawing.Point(7, 7);
            this.ch_notes.Margin = new System.Windows.Forms.Padding(7);
            this.ch_notes.Name = "ch_notes";
            this.ch_notes.Size = new System.Drawing.Size(51, 19);
            this.ch_notes.TabIndex = 151;
            this.ch_notes.Text = "مسودة";
            this.toolTip1.SetToolTip(this.ch_notes, "اذا قمت بالتاشير علي مسودة ... سيتم حفظ البيان مسودة دون التاثير علي الاصناف في ا" +
        "لمخازن او حتي علي حساب العميل وايضا لا يلزم وجود رصيد من الصنف بالمخازن");
            this.ch_notes.UseVisualStyleBackColor = true;
            // 
            // ch_auto_insert
            // 
            this.ch_auto_insert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ch_auto_insert.AutoSize = true;
            this.ch_auto_insert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_auto_insert.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch_auto_insert.ForeColor = System.Drawing.Color.DimGray;
            this.ch_auto_insert.Location = new System.Drawing.Point(844, 48);
            this.ch_auto_insert.Name = "ch_auto_insert";
            this.ch_auto_insert.Size = new System.Drawing.Size(103, 19);
            this.ch_auto_insert.TabIndex = 122;
            this.ch_auto_insert.Text = "اضف الصنف تلقائي";
            this.toolTip1.SetToolTip(this.ch_auto_insert, "اضف الصنف تلقائي بعد الاختيار");
            this.ch_auto_insert.UseVisualStyleBackColor = true;
            this.ch_auto_insert.Click += new System.EventHandler(this.ch_auto_insert_Click);
            // 
            // ch_is_agel
            // 
            this.ch_is_agel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ch_is_agel.AutoSize = true;
            this.ch_is_agel.BackColor = System.Drawing.Color.LimeGreen;
            this.ch_is_agel.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ch_is_agel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_is_agel.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch_is_agel.ForeColor = System.Drawing.Color.White;
            this.ch_is_agel.Location = new System.Drawing.Point(18, 3);
            this.ch_is_agel.Name = "ch_is_agel";
            this.ch_is_agel.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.ch_is_agel.Size = new System.Drawing.Size(73, 26);
            this.ch_is_agel.TabIndex = 138;
            this.ch_is_agel.Text = "اجل";
            this.ch_is_agel.UseVisualStyleBackColor = false;
            this.ch_is_agel.CheckedChanged += new System.EventHandler(this.ch_is_agel_CheckedChanged);
            // 
            // tx_Notes
            // 
            this.tx_Notes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_Notes.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_Notes.Location = new System.Drawing.Point(33, 60);
            this.tx_Notes.Name = "tx_Notes";
            this.tx_Notes.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tx_Notes.Size = new System.Drawing.Size(300, 23);
            this.tx_Notes.TabIndex = 87;
            this.tx_Notes.Text = "";
            // 
            // tx_DateAdd
            // 
            this.tx_DateAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_DateAdd.CalendarFont = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_DateAdd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.tx_DateAdd.Location = new System.Drawing.Point(33, 32);
            this.tx_DateAdd.Name = "tx_DateAdd";
            this.tx_DateAdd.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_DateAdd.Size = new System.Drawing.Size(300, 22);
            this.tx_DateAdd.TabIndex = 88;
            this.tx_DateAdd.Visible = false;
            // 
            // btn_add_grid
            // 
            this.btn_add_grid.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btn_add_grid.BackColor = System.Drawing.Color.DarkGray;
            this.btn_add_grid.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_add_grid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_add_grid.FlatAppearance.BorderSize = 0;
            this.btn_add_grid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add_grid.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_add_grid.ForeColor = System.Drawing.Color.White;
            this.btn_add_grid.Location = new System.Drawing.Point(0, 34);
            this.btn_add_grid.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.btn_add_grid.Name = "btn_add_grid";
            this.btn_add_grid.Size = new System.Drawing.Size(65, 28);
            this.btn_add_grid.TabIndex = 94;
            this.btn_add_grid.Text = "اضافة";
            this.btn_add_grid.UseVisualStyleBackColor = false;
            this.btn_add_grid.Click += new System.EventHandler(this.btn_add_grid_Click);
            // 
            // lp_TotalPrice_ditals
            // 
            this.lp_TotalPrice_ditals.AutoSize = true;
            this.lp_TotalPrice_ditals.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_TotalPrice_ditals.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_TotalPrice_ditals.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_TotalPrice_ditals.ForeColor = System.Drawing.Color.DimGray;
            this.lp_TotalPrice_ditals.Location = new System.Drawing.Point(235, 0);
            this.lp_TotalPrice_ditals.Name = "lp_TotalPrice_ditals";
            this.lp_TotalPrice_ditals.Size = new System.Drawing.Size(110, 31);
            this.lp_TotalPrice_ditals.TabIndex = 93;
            this.lp_TotalPrice_ditals.Text = "اجمالي";
            this.lp_TotalPrice_ditals.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_total_item
            // 
            this.lp_total_item.AutoSize = true;
            this.lp_total_item.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_total_item.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_total_item.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_total_item.ForeColor = System.Drawing.Color.DimGray;
            this.lp_total_item.Location = new System.Drawing.Point(3, 0);
            this.lp_total_item.Name = "lp_total_item";
            this.lp_total_item.Size = new System.Drawing.Size(110, 31);
            this.lp_total_item.TabIndex = 102;
            this.lp_total_item.Text = "الصافي";
            this.lp_total_item.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lp_total_item.Visible = false;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(1166, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 15);
            this.label4.TabIndex = 103;
            this.label4.Text = "الصنف";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // tx_TotalPrice_ditals
            // 
            this.tx_TotalPrice_ditals.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_TotalPrice_ditals.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tx_TotalPrice_ditals.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_TotalPrice_ditals.Location = new System.Drawing.Point(248, 36);
            this.tx_TotalPrice_ditals.Margin = new System.Windows.Forms.Padding(16, 5, 0, 0);
            this.tx_TotalPrice_ditals.Name = "tx_TotalPrice_ditals";
            this.tx_TotalPrice_ditals.Size = new System.Drawing.Size(100, 26);
            this.tx_TotalPrice_ditals.TabIndex = 107;
            this.tx_TotalPrice_ditals.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tx_TotalPrice_ditals.Enter += new System.EventHandler(this.tx_ItemQty_Enter);
            this.tx_TotalPrice_ditals.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_Discount_KeyPress);
            this.tx_TotalPrice_ditals.Leave += new System.EventHandler(this.tx_ItemQty_Leave);
            // 
            // tx_discunt_item
            // 
            this.tx_discunt_item.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tx_discunt_item.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_discunt_item.Location = new System.Drawing.Point(132, 36);
            this.tx_discunt_item.Margin = new System.Windows.Forms.Padding(16, 5, 0, 0);
            this.tx_discunt_item.Name = "tx_discunt_item";
            this.tx_discunt_item.Size = new System.Drawing.Size(100, 26);
            this.tx_discunt_item.TabIndex = 108;
            this.tx_discunt_item.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tx_discunt_item.Visible = false;
            this.tx_discunt_item.TextChanged += new System.EventHandler(this.tx_ItemQty_TextChanged);
            this.tx_discunt_item.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tx_discunt_item_KeyDown);
            this.tx_discunt_item.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_Discount_KeyPress);
            // 
            // tx_Discount
            // 
            this.tx_Discount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tx_Discount.Cursor = System.Windows.Forms.Cursors.No;
            this.tx_Discount.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_Discount.Location = new System.Drawing.Point(18, 3);
            this.tx_Discount.Name = "tx_Discount";
            this.tx_Discount.ReadOnly = true;
            this.tx_Discount.Size = new System.Drawing.Size(106, 23);
            this.tx_Discount.TabIndex = 115;
            this.tx_Discount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tx_Extra
            // 
            this.tx_Extra.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tx_Extra.Cursor = System.Windows.Forms.Cursors.No;
            this.tx_Extra.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_Extra.Location = new System.Drawing.Point(18, 3);
            this.tx_Extra.Name = "tx_Extra";
            this.tx_Extra.ReadOnly = true;
            this.tx_Extra.Size = new System.Drawing.Size(106, 23);
            this.tx_Extra.TabIndex = 116;
            this.tx_Extra.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dr_Discount_type
            // 
            this.dr_Discount_type.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dr_Discount_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_Discount_type.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.dr_Discount_type.FormattingEnabled = true;
            this.dr_Discount_type.Items.AddRange(new object[] {
            "خصم نسبة %",
            "خصم مبلغ"});
            this.dr_Discount_type.Location = new System.Drawing.Point(265, 2);
            this.dr_Discount_type.Margin = new System.Windows.Forms.Padding(0);
            this.dr_Discount_type.Name = "dr_Discount_type";
            this.dr_Discount_type.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dr_Discount_type.Size = new System.Drawing.Size(105, 24);
            this.dr_Discount_type.TabIndex = 123;
            this.dr_Discount_type.SelectionChangeCommitted += new System.EventHandler(this.tx_Discount_percent_TextChanged);
            // 
            // tx_Discount_percent
            // 
            this.tx_Discount_percent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tx_Discount_percent.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_Discount_percent.Location = new System.Drawing.Point(155, 3);
            this.tx_Discount_percent.Name = "tx_Discount_percent";
            this.tx_Discount_percent.Size = new System.Drawing.Size(106, 23);
            this.tx_Discount_percent.TabIndex = 124;
            this.tx_Discount_percent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tx_Discount_percent.TextChanged += new System.EventHandler(this.tx_Discount_percent_TextChanged);
            this.tx_Discount_percent.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_Discount_KeyPress);
            // 
            // tx_Extra_percent
            // 
            this.tx_Extra_percent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tx_Extra_percent.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_Extra_percent.Location = new System.Drawing.Point(155, 3);
            this.tx_Extra_percent.Name = "tx_Extra_percent";
            this.tx_Extra_percent.Size = new System.Drawing.Size(106, 23);
            this.tx_Extra_percent.TabIndex = 126;
            this.tx_Extra_percent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tx_Extra_percent.TextChanged += new System.EventHandler(this.tx_Discount_percent_TextChanged);
            this.tx_Extra_percent.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_Discount_KeyPress);
            // 
            // dr_Extra_type
            // 
            this.dr_Extra_type.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dr_Extra_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_Extra_type.Font = new System.Drawing.Font("Tahoma", 9.45F);
            this.dr_Extra_type.FormattingEnabled = true;
            this.dr_Extra_type.Items.AddRange(new object[] {
            "اضافة نسبة %",
            "اضافة مبلغ"});
            this.dr_Extra_type.Location = new System.Drawing.Point(265, 2);
            this.dr_Extra_type.Margin = new System.Windows.Forms.Padding(0);
            this.dr_Extra_type.Name = "dr_Extra_type";
            this.dr_Extra_type.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dr_Extra_type.Size = new System.Drawing.Size(105, 24);
            this.dr_Extra_type.TabIndex = 128;
            this.dr_Extra_type.SelectionChangeCommitted += new System.EventHandler(this.tx_Discount_percent_TextChanged);
            // 
            // gv_InvoiceDetails
            // 
            this.gv_InvoiceDetails.AllowUserToAddRows = false;
            this.gv_InvoiceDetails.AllowUserToResizeRows = false;
            this.gv_InvoiceDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gv_InvoiceDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_InvoiceDetails.BackgroundColor = System.Drawing.Color.White;
            this.gv_InvoiceDetails.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv_InvoiceDetails.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_InvoiceDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gv_InvoiceDetails.ColumnHeadersHeight = 28;
            this.gv_InvoiceDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DrItemID,
            this.DrStore_id,
            this.deleteitem});
            this.tableLayoutPanel6.SetColumnSpan(this.gv_InvoiceDetails, 2);
            this.gv_InvoiceDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_InvoiceDetails.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.gv_InvoiceDetails.EnableHeadersVisualStyles = false;
            this.gv_InvoiceDetails.Location = new System.Drawing.Point(1, 1);
            this.gv_InvoiceDetails.Margin = new System.Windows.Forms.Padding(1);
            this.gv_InvoiceDetails.MultiSelect = false;
            this.gv_InvoiceDetails.Name = "gv_InvoiceDetails";
            this.gv_InvoiceDetails.ReadOnly = true;
            this.gv_InvoiceDetails.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gv_InvoiceDetails.RowHeadersVisible = false;
            this.gv_InvoiceDetails.RowHeadersWidth = 45;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.gv_InvoiceDetails.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_InvoiceDetails.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_InvoiceDetails.RowTemplate.Height = 30;
            this.gv_InvoiceDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.gv_InvoiceDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_InvoiceDetails.Size = new System.Drawing.Size(1195, 199);
            this.gv_InvoiceDetails.TabIndex = 90;
            this.gv_InvoiceDetails.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gv_CellClick);
            this.gv_InvoiceDetails.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.gv_InvoiceDetails_UserDeletedRow);
            this.gv_InvoiceDetails.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.gv_InvoiceDetails_UserDeletingRow);
            // 
            // DrItemID
            // 
            this.DrItemID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.DrItemID.DefaultCellStyle = dataGridViewCellStyle4;
            this.DrItemID.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.DrItemID.DisplayStyleForCurrentCellOnly = true;
            this.DrItemID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DrItemID.HeaderText = "اسم الصنف";
            this.DrItemID.MaxDropDownItems = 1;
            this.DrItemID.MinimumWidth = 490;
            this.DrItemID.Name = "DrItemID";
            this.DrItemID.ReadOnly = true;
            this.DrItemID.Width = 490;
            // 
            // DrStore_id
            // 
            this.DrStore_id.DisplayStyleForCurrentCellOnly = true;
            this.DrStore_id.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DrStore_id.HeaderText = "المخزن";
            this.DrStore_id.MaxDropDownItems = 1;
            this.DrStore_id.MinimumWidth = 6;
            this.DrStore_id.Name = "DrStore_id";
            this.DrStore_id.ReadOnly = true;
            // 
            // deleteitem
            // 
            this.deleteitem.HeaderText = "حذف";
            this.deleteitem.Image = global::tnerhbeauty.Properties.Resources.trash_25px;
            this.deleteitem.MinimumWidth = 39;
            this.deleteitem.Name = "deleteitem";
            this.deleteitem.ReadOnly = true;
            this.deleteitem.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dr_price
            // 
            this.dr_price.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_price.Font = new System.Drawing.Font("Arial", 9.75F);
            this.dr_price.Location = new System.Drawing.Point(33, 57);
            this.dr_price.Name = "dr_price";
            this.dr_price.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dr_price.Size = new System.Drawing.Size(300, 24);
            this.dr_price.TabIndex = 135;
            this.dr_price.SelectionChangeCommitted += new System.EventHandler(this.dr_price_SelectionChangeCommitted);
            // 
            // lp_Price
            // 
            this.lp_Price.AutoSize = true;
            this.lp_Price.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_Price.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_Price.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_Price.ForeColor = System.Drawing.Color.DimGray;
            this.lp_Price.Location = new System.Drawing.Point(351, 0);
            this.lp_Price.Name = "lp_Price";
            this.lp_Price.Size = new System.Drawing.Size(110, 31);
            this.lp_Price.TabIndex = 137;
            this.lp_Price.Text = "السعر";
            this.lp_Price.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dr_store
            // 
            this.dr_store.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dr_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dr_store.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_store.Font = new System.Drawing.Font("Arial", 11.89565F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_store.FormattingEnabled = true;
            this.dr_store.Location = new System.Drawing.Point(707, 75);
            this.dr_store.Name = "dr_store";
            this.dr_store.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dr_store.Size = new System.Drawing.Size(121, 26);
            this.dr_store.TabIndex = 143;
            this.dr_store.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dr_store_KeyDown);
            // 
            // dr_discunt_item
            // 
            this.dr_discunt_item.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dr_discunt_item.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_discunt_item.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_discunt_item.ForeColor = System.Drawing.Color.DimGray;
            this.dr_discunt_item.FormattingEnabled = true;
            this.dr_discunt_item.Items.AddRange(new object[] {
            "خصم نسبة %",
            "خصم مبلغ"});
            this.dr_discunt_item.Location = new System.Drawing.Point(132, 8);
            this.dr_discunt_item.Margin = new System.Windows.Forms.Padding(0);
            this.dr_discunt_item.Name = "dr_discunt_item";
            this.dr_discunt_item.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dr_discunt_item.Size = new System.Drawing.Size(100, 23);
            this.dr_discunt_item.TabIndex = 147;
            this.dr_discunt_item.Visible = false;
            this.dr_discunt_item.SelectionChangeCommitted += new System.EventHandler(this.dr_discunt_item_SelectionChangeCommitted);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.btn_save, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_new, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_delete, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_print, 2, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(757, 409);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(437, 35);
            this.tableLayoutPanel1.TabIndex = 149;
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.DarkGray;
            this.btn_print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_print.FlatAppearance.BorderSize = 0;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(116, 3);
            this.btn_print.Margin = new System.Windows.Forms.Padding(20, 3, 3, 3);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(90, 29);
            this.btn_print.TabIndex = 79;
            this.btn_print.Text = "طباعة";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Visible = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "حذف";
            this.dataGridViewImageColumn1.Image = global::tnerhbeauty.Properties.Resources.trash_25px;
            this.dataGridViewImageColumn1.MinimumWidth = 39;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn1.Width = 689;
            // 
            // lp_titel
            // 
            this.lp_titel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.lp_titel.Dock = System.Windows.Forms.DockStyle.Top;
            this.lp_titel.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_titel.ForeColor = System.Drawing.Color.White;
            this.lp_titel.Image = global::tnerhbeauty.Properties.Resources.history_time_clock_10192;
            this.lp_titel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp_titel.Location = new System.Drawing.Point(0, 0);
            this.lp_titel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_titel.Name = "lp_titel";
            this.lp_titel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lp_titel.Size = new System.Drawing.Size(1221, 30);
            this.lp_titel.TabIndex = 52;
            this.lp_titel.Text = "بيان اسعار";
            this.lp_titel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pic_login
            // 
            this.pic_login.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pic_login.BackColor = System.Drawing.Color.Transparent;
            this.pic_login.Image = global::tnerhbeauty.Properties.Resources.kOnzy;
            this.pic_login.Location = new System.Drawing.Point(844, 77);
            this.pic_login.Margin = new System.Windows.Forms.Padding(0);
            this.pic_login.Name = "pic_login";
            this.pic_login.Size = new System.Drawing.Size(22, 22);
            this.pic_login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_login.TabIndex = 152;
            this.pic_login.TabStop = false;
            this.pic_login.Visible = false;
            // 
            // lpstore_to
            // 
            this.lpstore_to.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            this.lpstore_to.ForeColor = System.Drawing.Color.Black;
            this.lpstore_to.Location = new System.Drawing.Point(339, 3);
            this.lpstore_to.Margin = new System.Windows.Forms.Padding(3);
            this.lpstore_to.Name = "lpstore_to";
            this.lpstore_to.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lpstore_to.Size = new System.Drawing.Size(65, 21);
            this.lpstore_to.TabIndex = 154;
            this.lpstore_to.Text = "الي مخزن";
            this.lpstore_to.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dr_store_to
            // 
            this.dr_store_to.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dr_store_to.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dr_store_to.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dr_store_to.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dr_store_to.FormattingEnabled = true;
            this.dr_store_to.Location = new System.Drawing.Point(33, 3);
            this.dr_store_to.Name = "dr_store_to";
            this.dr_store_to.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dr_store_to.Size = new System.Drawing.Size(300, 23);
            this.dr_store_to.TabIndex = 153;
            this.dr_store_to.Visible = false;
            // 
            // PanClient
            // 
            this.PanClient.AutoSize = true;
            this.PanClient.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.PanClient.BackColor = System.Drawing.Color.Transparent;
            this.PanClient.ColumnCount = 2;
            this.PanClient.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.PanClient.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.PanClient.Controls.Add(this.label1, 0, 0);
            this.PanClient.Controls.Add(this.lp_Balance_client, 0, 1);
            this.PanClient.Controls.Add(this.label6, 0, 2);
            this.PanClient.Controls.Add(this.dr_price, 1, 2);
            this.PanClient.Controls.Add(this.flowLayoutPanel1, 1, 0);
            this.PanClient.Controls.Add(this.pan_Balance_client, 1, 1);
            this.PanClient.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            this.PanClient.Location = new System.Drawing.Point(0, 29);
            this.PanClient.Margin = new System.Windows.Forms.Padding(0);
            this.PanClient.Name = "PanClient";
            this.PanClient.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.PanClient.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.PanClient.RowCount = 3;
            this.PanClient.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PanClient.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PanClient.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PanClient.Size = new System.Drawing.Size(407, 84);
            this.PanClient.TabIndex = 156;
            this.PanClient.Visible = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.tx_name_cient);
            this.flowLayoutPanel1.Controls.Add(this.btn_client_save);
            this.flowLayoutPanel1.Controls.Add(this.btn_client_un_save);
            this.flowLayoutPanel1.Controls.Add(this.btn_find_client);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(30, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.flowLayoutPanel1.Size = new System.Drawing.Size(306, 27);
            this.flowLayoutPanel1.TabIndex = 157;
            // 
            // pan_Balance_client
            // 
            this.pan_Balance_client.AutoSize = true;
            this.pan_Balance_client.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pan_Balance_client.Controls.Add(this.tx_Balance_type);
            this.pan_Balance_client.Controls.Add(this.tx_Balance);
            this.pan_Balance_client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_Balance_client.Location = new System.Drawing.Point(30, 27);
            this.pan_Balance_client.Margin = new System.Windows.Forms.Padding(0);
            this.pan_Balance_client.Name = "pan_Balance_client";
            this.pan_Balance_client.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.pan_Balance_client.Size = new System.Drawing.Size(306, 27);
            this.pan_Balance_client.TabIndex = 158;
            this.pan_Balance_client.Visible = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSize = true;
            this.tableLayoutPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.lpstore_to, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tx_Notes, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.dr_store_to, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.tx_DateAdd, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel3.Controls.Add(label10, 0, 2);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 113);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.tableLayoutPanel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(407, 86);
            this.tableLayoutPanel3.TabIndex = 157;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(339, 32);
            this.label2.Margin = new System.Windows.Forms.Padding(3);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(65, 21);
            this.label2.TabIndex = 164;
            this.label2.Text = "تاريخ الفاتورة";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Visible = false;
            // 
            // pan_Total_product
            // 
            this.pan_Total_product.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pan_Total_product.Controls.Add(label5);
            this.pan_Total_product.Controls.Add(this.tx_Total_product);
            this.pan_Total_product.Location = new System.Drawing.Point(0, 0);
            this.pan_Total_product.Margin = new System.Windows.Forms.Padding(0);
            this.pan_Total_product.Name = "pan_Total_product";
            this.pan_Total_product.Size = new System.Drawing.Size(375, 29);
            this.pan_Total_product.TabIndex = 167;
            this.pan_Total_product.Visible = false;
            // 
            // pan_is_agel
            // 
            this.pan_is_agel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pan_is_agel.Controls.Add(this.ch_is_agel);
            this.pan_is_agel.Controls.Add(this.bt_save_is_agel);
            this.pan_is_agel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_is_agel.Location = new System.Drawing.Point(0, 154);
            this.pan_is_agel.Margin = new System.Windows.Forms.Padding(0);
            this.pan_is_agel.Name = "pan_is_agel";
            this.pan_is_agel.Size = new System.Drawing.Size(375, 33);
            this.pan_is_agel.TabIndex = 166;
            // 
            // pan_Discount
            // 
            this.pan_Discount.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pan_Discount.Controls.Add(this.dr_Discount_type);
            this.pan_Discount.Controls.Add(label11);
            this.pan_Discount.Controls.Add(this.tx_Discount_percent);
            this.pan_Discount.Controls.Add(this.tx_Discount);
            this.pan_Discount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_Discount.Location = new System.Drawing.Point(0, 60);
            this.pan_Discount.Margin = new System.Windows.Forms.Padding(0);
            this.pan_Discount.Name = "pan_Discount";
            this.pan_Discount.Size = new System.Drawing.Size(375, 30);
            this.pan_Discount.TabIndex = 165;
            this.pan_Discount.Visible = false;
            // 
            // pan_Extra
            // 
            this.pan_Extra.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pan_Extra.Controls.Add(this.tx_Extra);
            this.pan_Extra.Controls.Add(this.dr_Extra_type);
            this.pan_Extra.Controls.Add(label12);
            this.pan_Extra.Controls.Add(this.tx_Extra_percent);
            this.pan_Extra.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_Extra.Location = new System.Drawing.Point(0, 29);
            this.pan_Extra.Margin = new System.Windows.Forms.Padding(0);
            this.pan_Extra.Name = "pan_Extra";
            this.pan_Extra.Size = new System.Drawing.Size(375, 31);
            this.pan_Extra.TabIndex = 143;
            this.pan_Extra.Visible = false;
            // 
            // PanPrice
            // 
            this.PanPrice.AutoSize = true;
            this.PanPrice.Controls.Add(this.tableLayoutPanel4);
            this.PanPrice.Location = new System.Drawing.Point(65, 0);
            this.PanPrice.Margin = new System.Windows.Forms.Padding(0);
            this.PanPrice.Name = "PanPrice";
            this.tableLayoutPanel2.SetRowSpan(this.PanPrice, 2);
            this.PanPrice.Size = new System.Drawing.Size(464, 62);
            this.PanPrice.TabIndex = 162;
            this.PanPrice.Visible = false;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.AutoSize = true;
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.tx_total_item, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.lp_Price, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.lp_TotalPrice_ditals, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.lp_total_item, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.tx_TotalPrice_ditals, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.dr_discunt_item, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.tx_discunt_item, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.tx_Price, 3, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(464, 62);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.btn_add_grid, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.PanPrice, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.ch_notes, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(16, 37);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(529, 66);
            this.tableLayoutPanel2.TabIndex = 163;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.765218F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(752, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 165;
            this.label3.Text = "المخزن";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // pan
            // 
            this.pan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan.AutoSize = true;
            this.pan.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pan.BackColor = System.Drawing.Color.Transparent;
            this.pan.ColumnCount = 1;
            this.pan.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.pan.Controls.Add(this.PanClient, 0, 1);
            this.pan.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.pan.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.pan.Location = new System.Drawing.Point(787, 204);
            this.pan.Name = "pan";
            this.pan.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.pan.RowCount = 3;
            this.pan.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.pan.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.pan.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.pan.Size = new System.Drawing.Size(407, 199);
            this.pan.TabIndex = 158;
            this.pan.Paint += new System.Windows.Forms.PaintEventHandler(this.pan_Paint);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.AutoSize = true;
            this.tableLayoutPanel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.Controls.Add(this.TxTotalQty, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(117, 0);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(290, 29);
            this.tableLayoutPanel5.TabIndex = 158;
            // 
            // PanTotal
            // 
            this.PanTotal.AutoSize = true;
            this.PanTotal.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.PanTotal.BackColor = System.Drawing.Color.Transparent;
            this.PanTotal.ColumnCount = 1;
            this.PanTotal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PanTotal.Controls.Add(this.panel1, 0, 3);
            this.PanTotal.Controls.Add(this.pan_is_agel, 0, 4);
            this.PanTotal.Controls.Add(this.pan_Total_product, 0, 0);
            this.PanTotal.Controls.Add(this.pan_Discount, 0, 2);
            this.PanTotal.Controls.Add(this.pan_Extra, 0, 1);
            this.PanTotal.Location = new System.Drawing.Point(0, 201);
            this.PanTotal.Margin = new System.Windows.Forms.Padding(0);
            this.PanTotal.Name = "PanTotal";
            this.PanTotal.RowCount = 5;
            this.PanTotal.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PanTotal.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PanTotal.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PanTotal.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PanTotal.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PanTotal.Size = new System.Drawing.Size(375, 187);
            this.PanTotal.TabIndex = 167;
            this.PanTotal.Visible = false;
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.Controls.Add(label8);
            this.panel1.Controls.Add(this.tx_Net);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 90);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(375, 64);
            this.panel1.TabIndex = 168;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.pan, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.gv_InvoiceDetails, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel1, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.PanTotal, 0, 1);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(12, 109);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 3;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1197, 447);
            this.tableLayoutPanel6.TabIndex = 168;
            // 
            // gvSerchProduct
            // 
            this.gvSerchProduct.AllowUserToAddRows = false;
            this.gvSerchProduct.AllowUserToDeleteRows = false;
            this.gvSerchProduct.AllowUserToResizeColumns = false;
            this.gvSerchProduct.AllowUserToResizeRows = false;
            this.gvSerchProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gvSerchProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gvSerchProduct.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gvSerchProduct.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gvSerchProduct.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gvSerchProduct.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gvSerchProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gvSerchProduct.ColumnHeadersHeight = 30;
            this.gvSerchProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gvSerchProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gvSerchProduct.EnableHeadersVisualStyles = false;
            this.gvSerchProduct.GridColor = System.Drawing.Color.Black;
            this.gvSerchProduct.Location = new System.Drawing.Point(592, 103);
            this.gvSerchProduct.Margin = new System.Windows.Forms.Padding(0);
            this.gvSerchProduct.MaximumSize = new System.Drawing.Size(613, 620);
            this.gvSerchProduct.MinimumSize = new System.Drawing.Size(613, 0);
            this.gvSerchProduct.MultiSelect = false;
            this.gvSerchProduct.Name = "gvSerchProduct";
            this.gvSerchProduct.ReadOnly = true;
            this.gvSerchProduct.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gvSerchProduct.RowHeadersVisible = false;
            this.gvSerchProduct.RowHeadersWidth = 49;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gvSerchProduct.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.gvSerchProduct.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gvSerchProduct.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gvSerchProduct.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gvSerchProduct.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gvSerchProduct.RowTemplate.Height = 30;
            this.gvSerchProduct.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gvSerchProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gvSerchProduct.Size = new System.Drawing.Size(613, 10);
            this.gvSerchProduct.TabIndex = 164;
            this.gvSerchProduct.Visible = false;
            this.gvSerchProduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvSerchProduct_CellDoubleClick);
            // 
            // frm_InvoiceHeader_nots
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1221, 605);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.gvSerchProduct);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.pic_login);
            this.Controls.Add(this.lb_balance);
            this.Controls.Add(this.dr_store);
            this.Controls.Add(this.tx_id_cient);
            this.Controls.Add(this.ch_kilo);
            this.Controls.Add(this.ch_not_celar_ItemQty);
            this.Controls.Add(this.ch_auto_insert);
            this.Controls.Add(this.tx_ItemQty);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lb_mas);
            this.Controls.Add(this.lp_titel);
            this.Controls.Add(this.tx_ItemName);
            this.Controls.Add(this.tableLayoutPanel6);
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frm_InvoiceHeader_nots";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فاتورة";
            this.Load += new System.EventHandler(this.frm_kushufat_Load);
            this.Shown += new System.EventHandler(this.frm_InvoiceHeader_nots_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_kushufat_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_InvoiceDetails)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).EndInit();
            this.PanClient.ResumeLayout(false);
            this.PanClient.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.pan_Balance_client.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.pan_Total_product.ResumeLayout(false);
            this.pan_Total_product.PerformLayout();
            this.pan_is_agel.ResumeLayout(false);
            this.pan_is_agel.PerformLayout();
            this.pan_Discount.ResumeLayout(false);
            this.pan_Discount.PerformLayout();
            this.pan_Extra.ResumeLayout(false);
            this.pan_Extra.PerformLayout();
            this.PanPrice.ResumeLayout(false);
            this.PanPrice.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.pan.ResumeLayout(false);
            this.pan.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.PanTotal.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvSerchProduct)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lp_titel;
        private System.Windows.Forms.Label lb_mas;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_find_client;
        private System.Windows.Forms.Label tx_name_cient;
        private System.Windows.Forms.ErrorProvider errorProvider1;
      
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label tx_id_cient;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.RichTextBox tx_Notes;
        private System.Windows.Forms.DateTimePicker tx_DateAdd;
        private System.Windows.Forms.Button btn_add_grid;
        private System.Windows.Forms.Label lp_TotalPrice_ditals;
        private System.Windows.Forms.Label lp_total_item;
        private System.Windows.Forms.Label label4;
        
        private System.Windows.Forms.TextBox tx_ItemName;
        private System.Windows.Forms.TextBox tx_total_item;
        private System.Windows.Forms.TextBox tx_discunt_item;
        private System.Windows.Forms.TextBox tx_TotalPrice_ditals;
        private System.Windows.Forms.TextBox tx_ItemQty;
        private System.Windows.Forms.TextBox tx_Price;
        private System.Windows.Forms.TextBox tx_Net;
        private System.Windows.Forms.TextBox tx_Extra;
        private System.Windows.Forms.TextBox tx_Discount;
        private System.Windows.Forms.TextBox tx_Total_product;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.CheckBox ch_auto_insert;
        private System.Windows.Forms.ComboBox dr_Discount_type;
        private System.Windows.Forms.ComboBox dr_Extra_type;
        private System.Windows.Forms.TextBox tx_Extra_percent;
        private System.Windows.Forms.TextBox tx_Discount_percent;
        private System.Windows.Forms.DataGridView gv_InvoiceDetails;
        private System.Windows.Forms.CheckBox ch_not_celar_ItemQty;
        private System.Windows.Forms.CheckBox ch_kilo;
        private System.Windows.Forms.Button btn_client_save;
        private System.Windows.Forms.Button btn_client_un_save;
        private System.Windows.Forms.ComboBox dr_price;
        private System.Windows.Forms.Label lp_Price;
        private System.Windows.Forms.CheckBox ch_is_agel;
        private System.Windows.Forms.Label tx_Balance;
        private System.Windows.Forms.Label tx_Balance_type;
        private System.Windows.Forms.Button bt_save_is_agel;
        private System.Windows.Forms.ComboBox dr_store;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.ComboBox dr_discunt_item;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.CheckBox ch_notes;
        private System.Windows.Forms.PictureBox pic_login;
        private System.Windows.Forms.Label lpstore_to;
        private System.Windows.Forms.ComboBox dr_store_to;
        private System.Windows.Forms.TableLayoutPanel PanClient;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel pan_Balance_client;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TextBox TxTotalQty;
        private System.Windows.Forms.DataGridViewComboBoxColumn DrItemID;
        private System.Windows.Forms.DataGridViewComboBoxColumn DrStore_id;
        private System.Windows.Forms.DataGridViewImageColumn deleteitem;
        private System.Windows.Forms.Panel PanPrice;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private Class.datagrid gvSerchProduct;
        private System.Windows.Forms.Panel pan_Discount;
        private System.Windows.Forms.Panel pan_Extra;
        private System.Windows.Forms.Label lp_Balance_client;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pan_is_agel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pan_Total_product;
        private System.Windows.Forms.TableLayoutPanel pan;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel PanTotal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
    }
}