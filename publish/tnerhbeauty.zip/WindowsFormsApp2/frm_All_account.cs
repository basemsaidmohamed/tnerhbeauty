﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using tnerhbeauty.Class;

namespace tnerhbeauty
{
    public partial class frm_All_account : Form
    {
        DataClasses1DataContext db;
        public frm_All_account()
        {
            InitializeComponent();

        }
        public void getdata()
        {
            db = new DataClasses1DataContext();
            gv.DataSource = db.All_account_Views.Where(x => x.type_acount == 3 && x.type_amount.ToString().Contains(dr_typeAmount.SelectedValue.ToString()) && x.name.Contains(tx_serch.Text)).OrderBy(x => x.id);
            gv.CurrentCell = null;
        }
        private void gv_mariddata_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            int id = Convert.ToInt32(gv.Rows[e.RowIndex].Cells[nameof(All_account.id)].Value.ToString());
            add_account kushufat = new add_account(id);
            kushufat.ShowDialog();
            getdata();
        }
        private void all_marid_Load(object sender, EventArgs e)
        {
            gv.AutoGenerateColumns = false;
            dr_typeAmount.IntializeData(Session.TypeAmountList);
            getdata();
        }
        private void bt_search_Click(object sender, EventArgs e)
        {
            getdata();
        }
    }
}
