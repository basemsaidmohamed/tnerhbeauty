﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using tnerhbeauty.Class;

namespace tnerhbeauty
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        static List<int> list_ids_store;
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBBETTERLIFESERVERDataSet.type_cash' table. You can move, or remove it, as needed.


        }
        //public List<T> GetDataNoParams(string procname)
        //{
        //    var query = db.ExecuteQuery<T>("Exec " + procname);

        //    return query.ToList();
        //}

        //public List<fara> GetDataParams(string procname, Object[] parameters)
        //{
        //    //var query = db.ExecuteQuery<fara>("Exec " + procname, parameters);

        //    //return query.ToList();
        //}
        private void button1_Click(object sender, EventArgs e)
        {
            //  store f = new store();
            //  DataClasses1DataContext db = new DataClasses1DataContext();
            //List<store> a = Session.procedureNoParams<store>("addnew");
            ////var www = db.addnew();
            ////var qq = db.addnew(1);

            //var  ss =db.addnew(1);
            //  f= db.stores.FirstOrDefault();

            //Session.procedureDataParams<store>("addnew var1={0}, var2={1}, var3={2}", f) ;
            //var dddd=db.addnew(2);
            //datagrid1.DataSource = a;
            //MessageBox.Show("");

            //MessageBox.Show(qq.ReturnValue.ToString());
            //list_ids_store = Session.Store.Select(x => x.id).ToList();
            //MessageBox.Show(string.Join(",", list_ids_store));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //DataClasses1DataContext db = new DataClasses1DataContext();
            ////int? s1 = 0;
            ////int? s2 = 0;
            ////var _retun = db.ProcedureName();
            //////MessageBox.Show(_retun.ReturnValue.ToString());

            //////MessageBox.Show(s1.ToString());
            //////MessageBox.Show(s2.ToString());
            //var a=db.ProcedureName();
            //datagrid1.DataSource = a.ToList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //DataClasses1DataContext db = new DataClasses1DataContext();
            //var a = db.deleteInvoiceHeaderANDamount_client(3600);
            //MessageBox.Show(a.ReturnValue.ToString());
            //datagrid1.DataSource = a.ToList();

            //if (MyMessageBox.showMessage("هل انت متاكد", massege.AskDelete, "", MessageBoxButtons.YesNo) != DialogResult.Yes)
            //    return;

            if (invoice.deleteInvoice(Convert.ToInt32(textBox1.Text)))
                MessageBox.Show("ok");


        }

        private async void button4_Click(object sender, EventArgs e)
        {
            //  GetProductReturnView g = ( await Class.invoice.GetReturn("1971", "28871", "1") );
            //  //g = ;
            //  if(g != null ) 
            //MessageBox.Show(  g.store_name);
            //  //datagrid1.DataSource =await Class.invoice.GetReturn("1971","2071","1");

        }
    }
}
