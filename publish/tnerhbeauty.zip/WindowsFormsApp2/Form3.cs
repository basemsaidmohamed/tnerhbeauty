﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace tnerhbeauty
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext context = new DataClasses1DataContext();
            context.Connection.Open();
            context.Transaction = context.Connection.BeginTransaction();

            //context.stores.InsertOnSubmit(new store
            //{
            //    store_name = "st" + DateTime.Now.ToString(),
            //    adress = "ddd",
            //    id_fara = 1,
            //    id_user = 2,
            //    is_stop = true,
            //    DateServer = DateTime.Now,
            //});
            context.deleteInvoiceHeaderANDamount_client(12125);

            //context.stores.DeleteOnSubmit(s);

            context.SubmitChanges();
            dataGridView1.DataSource = context.store_Views;
            //Replace the flag condition with the one you need 
            //or remove it and leave only commit part
            if (checkBox1.Checked)
            {
                //transaction completed successfully, both calls succeeded 
                context.Transaction.Commit();
            }
            else
            {
                //something is wrong, both calls are rolled back 
                context.Transaction.Rollback();
            }

        }
        fara _fara = new fara();
        private void button2_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext context = new DataClasses1DataContext();
            _fara = context.faras.FirstOrDefault();
            context.faras.InsertOnSubmit(_fara);
            context.SubmitChanges();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
