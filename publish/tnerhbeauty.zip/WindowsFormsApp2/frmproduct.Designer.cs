﻿namespace tnerhbeauty
{
    partial class frmproduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lb_mas = new System.Windows.Forms.Label();
            this.tx_serch = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_print = new System.Windows.Forms.Button();
            this.gv_product = new tnerhbeauty.Class.datagrid();
            this.lp_titel = new System.Windows.Forms.Label();
            this.ch_zero = new System.Windows.Forms.CheckBox();
            this.ch_store = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lp_price_10 = new System.Windows.Forms.Label();
            this.lp_price_9 = new System.Windows.Forms.Label();
            this.lp_price_8 = new System.Windows.Forms.Label();
            this.lp_price_7 = new System.Windows.Forms.Label();
            this.lp_price_6 = new System.Windows.Forms.Label();
            this.lp_price_5 = new System.Windows.Forms.Label();
            this.lp_price_4 = new System.Windows.Forms.Label();
            this.lp_price_3 = new System.Windows.Forms.Label();
            this.lp_price_2 = new System.Windows.Forms.Label();
            this.lp_price_1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lp_price_sale_100 = new System.Windows.Forms.Label();
            this.lp2 = new System.Windows.Forms.Label();
            this.lp4 = new System.Windows.Forms.Label();
            this.lp3 = new System.Windows.Forms.Label();
            this.lp1 = new System.Windows.Forms.Label();
            this.lp5 = new System.Windows.Forms.Label();
            this.lp_price_sale_vip2 = new System.Windows.Forms.Label();
            this.lp_price_sale = new System.Windows.Forms.Label();
            this.lp_price_sale_vip1 = new System.Windows.Forms.Label();
            this.lp_price_sale_75 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lp6 = new System.Windows.Forms.Label();
            this.lp_total = new System.Windows.Forms.Label();
            this.btn_export_exal = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.lp_price_buy = new System.Windows.Forms.Label();
            this.pic_login = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.gv_product)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_mas
            // 
            this.lb_mas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lb_mas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_mas.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mas.ForeColor = System.Drawing.Color.White;
            this.lb_mas.Location = new System.Drawing.Point(0, 674);
            this.lb_mas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_mas.Name = "lb_mas";
            this.lb_mas.Size = new System.Drawing.Size(1582, 42);
            this.lb_mas.TabIndex = 53;
            this.lb_mas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tx_serch
            // 
            this.tx_serch.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.tx_serch.Location = new System.Drawing.Point(119, 54);
            this.tx_serch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tx_serch.Name = "tx_serch";
            this.tx_serch.Size = new System.Drawing.Size(346, 29);
            this.tx_serch.TabIndex = 72;
            this.tx_serch.TextChanged += new System.EventHandler(this.tx_serch_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(14, 58);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 24);
            this.label5.TabIndex = 73;
            this.label5.Text = "بحث عن صنف";
            // 
            // btn_print
            // 
            this.btn_print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_print.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_print.FlatAppearance.BorderSize = 0;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(1451, 47);
            this.btn_print.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(119, 36);
            this.btn_print.TabIndex = 108;
            this.btn_print.Text = "طباعة";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // gv_product
            // 
            this.gv_product.AllowUserToAddRows = false;
            this.gv_product.AllowUserToDeleteRows = false;
            this.gv_product.AllowUserToResizeColumns = false;
            this.gv_product.AllowUserToResizeRows = false;
            this.gv_product.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gv_product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_product.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_product.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv_product.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv_product.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_product.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.gv_product.ColumnHeadersHeight = 30;
            this.gv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv_product.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_product.EnableHeadersVisualStyles = false;
            this.gv_product.GridColor = System.Drawing.Color.Black;
            this.gv_product.Location = new System.Drawing.Point(10, 90);
            this.gv_product.Margin = new System.Windows.Forms.Padding(0);
            this.gv_product.Name = "gv_product";
            this.gv_product.ReadOnly = true;
            this.gv_product.RowHeadersVisible = false;
            this.gv_product.RowHeadersWidth = 49;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_product.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.gv_product.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_product.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_product.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_product.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv_product.RowTemplate.Height = 30;
            this.gv_product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_product.Size = new System.Drawing.Size(1561, 481);
            this.gv_product.TabIndex = 70;
            this.gv_product.TabStop = false;
            this.gv_product.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_mariddata_CellDoubleClick);
            // 
            // lp_titel
            // 
            this.lp_titel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lp_titel.Dock = System.Windows.Forms.DockStyle.Top;
            this.lp_titel.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold);
            this.lp_titel.ForeColor = System.Drawing.Color.White;
            this.lp_titel.Image = global::tnerhbeauty.Properties.Resources.database_data;
            this.lp_titel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp_titel.Location = new System.Drawing.Point(0, 0);
            this.lp_titel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lp_titel.Name = "lp_titel";
            this.lp_titel.Size = new System.Drawing.Size(1582, 43);
            this.lp_titel.TabIndex = 52;
            this.lp_titel.Text = "الاصناف";
            this.lp_titel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ch_zero
            // 
            this.ch_zero.AutoSize = true;
            this.ch_zero.Checked = true;
            this.ch_zero.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ch_zero.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_zero.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.ch_zero.Location = new System.Drawing.Point(472, 55);
            this.ch_zero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ch_zero.Name = "ch_zero";
            this.ch_zero.Size = new System.Drawing.Size(175, 26);
            this.ch_zero.TabIndex = 109;
            this.ch_zero.Text = "اخفاء الارصدة الصفرية";
            this.ch_zero.UseVisualStyleBackColor = true;
            this.ch_zero.CheckedChanged += new System.EventHandler(this.ch_zero_CheckedChanged);
            // 
            // ch_store
            // 
            this.ch_store.AutoSize = true;
            this.ch_store.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_store.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.ch_store.Location = new System.Drawing.Point(656, 55);
            this.ch_store.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ch_store.Name = "ch_store";
            this.ch_store.Size = new System.Drawing.Size(163, 26);
            this.ch_store.TabIndex = 149;
            this.ch_store.Text = "عرض رصيد المخازن";
            this.ch_store.UseVisualStyleBackColor = true;
            this.ch_store.CheckedChanged += new System.EventHandler(this.ch_zero_CheckedChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 17;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.Controls.Add(this.lp_price_buy, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_10, 15, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_9, 14, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_8, 13, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_7, 12, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_6, 11, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_5, 10, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_4, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_3, 8, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_2, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_1, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.label10, 14, 0);
            this.tableLayoutPanel1.Controls.Add(this.label8, 12, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 11, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_sale_100, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp4, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp5, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_sale_vip2, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_sale, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_sale_vip1, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.lp_price_sale_75, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label4, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.label9, 13, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 15, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp6, 16, 0);
            this.tableLayoutPanel1.Controls.Add(this.lp_total, 16, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 590);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.61905F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.38095F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1558, 78);
            this.tableLayoutPanel1.TabIndex = 150;
            // 
            // lp_price_10
            // 
            this.lp_price_10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_10.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_10.Location = new System.Drawing.Point(106, 37);
            this.lp_price_10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_10.Name = "lp_price_10";
            this.lp_price_10.Size = new System.Drawing.Size(83, 41);
            this.lp_price_10.TabIndex = 153;
            this.lp_price_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_9
            // 
            this.lp_price_9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_9.Location = new System.Drawing.Point(197, 37);
            this.lp_price_9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_9.Name = "lp_price_9";
            this.lp_price_9.Size = new System.Drawing.Size(83, 41);
            this.lp_price_9.TabIndex = 153;
            this.lp_price_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_8
            // 
            this.lp_price_8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_8.Location = new System.Drawing.Point(288, 37);
            this.lp_price_8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_8.Name = "lp_price_8";
            this.lp_price_8.Size = new System.Drawing.Size(83, 41);
            this.lp_price_8.TabIndex = 153;
            this.lp_price_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_7
            // 
            this.lp_price_7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_7.Location = new System.Drawing.Point(379, 37);
            this.lp_price_7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_7.Name = "lp_price_7";
            this.lp_price_7.Size = new System.Drawing.Size(83, 41);
            this.lp_price_7.TabIndex = 153;
            this.lp_price_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_6
            // 
            this.lp_price_6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_6.Location = new System.Drawing.Point(470, 37);
            this.lp_price_6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_6.Name = "lp_price_6";
            this.lp_price_6.Size = new System.Drawing.Size(83, 41);
            this.lp_price_6.TabIndex = 153;
            this.lp_price_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_5
            // 
            this.lp_price_5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_5.Location = new System.Drawing.Point(561, 37);
            this.lp_price_5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_5.Name = "lp_price_5";
            this.lp_price_5.Size = new System.Drawing.Size(83, 41);
            this.lp_price_5.TabIndex = 153;
            this.lp_price_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_4
            // 
            this.lp_price_4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_4.Location = new System.Drawing.Point(652, 37);
            this.lp_price_4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_4.Name = "lp_price_4";
            this.lp_price_4.Size = new System.Drawing.Size(83, 41);
            this.lp_price_4.TabIndex = 153;
            this.lp_price_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_3
            // 
            this.lp_price_3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_3.Location = new System.Drawing.Point(743, 37);
            this.lp_price_3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_3.Name = "lp_price_3";
            this.lp_price_3.Size = new System.Drawing.Size(83, 41);
            this.lp_price_3.TabIndex = 153;
            this.lp_price_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_2
            // 
            this.lp_price_2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_2.Location = new System.Drawing.Point(834, 37);
            this.lp_price_2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_2.Name = "lp_price_2";
            this.lp_price_2.Size = new System.Drawing.Size(83, 41);
            this.lp_price_2.TabIndex = 153;
            this.lp_price_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_1
            // 
            this.lp_price_1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_1.Location = new System.Drawing.Point(925, 37);
            this.lp_price_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_1.Name = "lp_price_1";
            this.lp_price_1.Size = new System.Drawing.Size(83, 41);
            this.lp_price_1.TabIndex = 153;
            this.lp_price_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(197, 0);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 37);
            this.label10.TabIndex = 151;
            this.label10.Text = "price_9";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(379, 0);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 37);
            this.label8.TabIndex = 151;
            this.label8.Text = "price_7";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(470, 0);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 37);
            this.label7.TabIndex = 151;
            this.label7.Text = "price_6";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(561, 0);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 37);
            this.label6.TabIndex = 151;
            this.label6.Text = "price_5";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(743, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 37);
            this.label3.TabIndex = 151;
            this.label3.Text = "price_3";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(834, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 37);
            this.label2.TabIndex = 151;
            this.label2.Text = "price_2";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(925, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 37);
            this.label1.TabIndex = 151;
            this.label1.Text = "price_1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_sale_100
            // 
            this.lp_price_sale_100.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_sale_100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_sale_100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_sale_100.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_sale_100.Location = new System.Drawing.Point(1289, 37);
            this.lp_price_sale_100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_sale_100.Name = "lp_price_sale_100";
            this.lp_price_sale_100.Size = new System.Drawing.Size(83, 41);
            this.lp_price_sale_100.TabIndex = 94;
            this.lp_price_sale_100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp2
            // 
            this.lp2.AutoSize = true;
            this.lp2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp2.Location = new System.Drawing.Point(1289, 0);
            this.lp2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp2.Name = "lp2";
            this.lp2.Size = new System.Drawing.Size(83, 37);
            this.lp2.TabIndex = 87;
            this.lp2.Text = "سعر البيع  100";
            this.lp2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp4
            // 
            this.lp4.AutoSize = true;
            this.lp4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp4.Location = new System.Drawing.Point(1107, 0);
            this.lp4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp4.Name = "lp4";
            this.lp4.Size = new System.Drawing.Size(83, 37);
            this.lp4.TabIndex = 90;
            this.lp4.Text = "سعر البيع VIP2";
            this.lp4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp3
            // 
            this.lp3.AutoSize = true;
            this.lp3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp3.Location = new System.Drawing.Point(1198, 0);
            this.lp3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp3.Name = "lp3";
            this.lp3.Size = new System.Drawing.Size(83, 37);
            this.lp3.TabIndex = 88;
            this.lp3.Text = "سعر البيع 75";
            this.lp3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp1
            // 
            this.lp1.AutoSize = true;
            this.lp1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp1.Location = new System.Drawing.Point(1380, 0);
            this.lp1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp1.Name = "lp1";
            this.lp1.Size = new System.Drawing.Size(83, 37);
            this.lp1.TabIndex = 89;
            this.lp1.Text = "سعر بيع محل";
            this.lp1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp5
            // 
            this.lp5.AutoSize = true;
            this.lp5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp5.Location = new System.Drawing.Point(1016, 0);
            this.lp5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp5.Name = "lp5";
            this.lp5.Size = new System.Drawing.Size(83, 37);
            this.lp5.TabIndex = 151;
            this.lp5.Text = "سعر البيع VIP1";
            this.lp5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_sale_vip2
            // 
            this.lp_price_sale_vip2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_sale_vip2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_sale_vip2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_sale_vip2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_sale_vip2.Location = new System.Drawing.Point(1107, 37);
            this.lp_price_sale_vip2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_sale_vip2.Name = "lp_price_sale_vip2";
            this.lp_price_sale_vip2.Size = new System.Drawing.Size(83, 41);
            this.lp_price_sale_vip2.TabIndex = 92;
            this.lp_price_sale_vip2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_sale
            // 
            this.lp_price_sale.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_sale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_sale.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_sale.Location = new System.Drawing.Point(1380, 37);
            this.lp_price_sale.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_sale.Name = "lp_price_sale";
            this.lp_price_sale.Size = new System.Drawing.Size(83, 41);
            this.lp_price_sale.TabIndex = 93;
            this.lp_price_sale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_sale_vip1
            // 
            this.lp_price_sale_vip1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_sale_vip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_sale_vip1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_sale_vip1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_sale_vip1.Location = new System.Drawing.Point(1016, 37);
            this.lp_price_sale_vip1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_sale_vip1.Name = "lp_price_sale_vip1";
            this.lp_price_sale_vip1.Size = new System.Drawing.Size(83, 41);
            this.lp_price_sale_vip1.TabIndex = 86;
            this.lp_price_sale_vip1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_sale_75
            // 
            this.lp_price_sale_75.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_sale_75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_sale_75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_sale_75.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_sale_75.Location = new System.Drawing.Point(1198, 37);
            this.lp_price_sale_75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_sale_75.Name = "lp_price_sale_75";
            this.lp_price_sale_75.Size = new System.Drawing.Size(83, 41);
            this.lp_price_sale_75.TabIndex = 91;
            this.lp_price_sale_75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(652, 0);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 37);
            this.label4.TabIndex = 151;
            this.label4.Text = "price_4";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(288, 0);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 37);
            this.label9.TabIndex = 151;
            this.label9.Text = "price_8";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label11.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(106, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 37);
            this.label11.TabIndex = 151;
            this.label11.Text = "price_10";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp6
            // 
            this.lp6.AutoSize = true;
            this.lp6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp6.Location = new System.Drawing.Point(4, 0);
            this.lp6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp6.Name = "lp6";
            this.lp6.Size = new System.Drawing.Size(94, 37);
            this.lp6.TabIndex = 89;
            this.lp6.Text = "الرصيد";
            this.lp6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_total
            // 
            this.lp_total.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_total.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_total.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_total.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_total.Location = new System.Drawing.Point(4, 37);
            this.lp_total.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_total.Name = "lp_total";
            this.lp_total.Size = new System.Drawing.Size(94, 41);
            this.lp_total.TabIndex = 152;
            this.lp_total.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_export_exal
            // 
            this.btn_export_exal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_export_exal.BackColor = System.Drawing.Color.Purple;
            this.btn_export_exal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_export_exal.FlatAppearance.BorderSize = 0;
            this.btn_export_exal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_export_exal.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_export_exal.ForeColor = System.Drawing.Color.White;
            this.btn_export_exal.Image = global::tnerhbeauty.Properties.Resources.excel;
            this.btn_export_exal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_export_exal.Location = new System.Drawing.Point(1306, 47);
            this.btn_export_exal.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btn_export_exal.Name = "btn_export_exal";
            this.btn_export_exal.Size = new System.Drawing.Size(136, 36);
            this.btn_export_exal.TabIndex = 151;
            this.btn_export_exal.Text = "تصدير اكسيل";
            this.btn_export_exal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_export_exal.UseVisualStyleBackColor = false;
            this.btn_export_exal.Click += new System.EventHandler(this.btn_export_exal_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(1471, 0);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 37);
            this.label12.TabIndex = 152;
            this.label12.Text = "سعر الشراء";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lp_price_buy
            // 
            this.lp_price_buy.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lp_price_buy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lp_price_buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lp_price_buy.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lp_price_buy.Location = new System.Drawing.Point(1471, 37);
            this.lp_price_buy.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lp_price_buy.Name = "lp_price_buy";
            this.lp_price_buy.Size = new System.Drawing.Size(83, 41);
            this.lp_price_buy.TabIndex = 154;
            this.lp_price_buy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pic_login
            // 
            this.pic_login.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pic_login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pic_login.Image = global::tnerhbeauty.Properties.Resources.kOnzy;
            this.pic_login.Location = new System.Drawing.Point(4, 675);
            this.pic_login.Margin = new System.Windows.Forms.Padding(0);
            this.pic_login.Name = "pic_login";
            this.pic_login.Size = new System.Drawing.Size(40, 40);
            this.pic_login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_login.TabIndex = 154;
            this.pic_login.TabStop = false;
            this.pic_login.Visible = false;
            // 
            // frmproduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1582, 716);
            this.Controls.Add(this.pic_login);
            this.Controls.Add(this.btn_export_exal);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.ch_store);
            this.Controls.Add(this.ch_zero);
            this.Controls.Add(this.btn_print);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tx_serch);
            this.Controls.Add(this.gv_product);
            this.Controls.Add(this.lb_mas);
            this.Controls.Add(this.lp_titel);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmproduct";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.Text = "frmproduct";
            this.Load += new System.EventHandler(this.frmproduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gv_product)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lp_titel;
        private System.Windows.Forms.Label lb_mas;
        private Class.datagrid gv_product;
        private System.Windows.Forms.TextBox tx_serch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.CheckBox ch_zero;
        private System.Windows.Forms.CheckBox ch_store;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lp_price_sale_75;
        private System.Windows.Forms.Label lp2;
        private System.Windows.Forms.Label lp6;
        private System.Windows.Forms.Label lp4;
        private System.Windows.Forms.Label lp3;
        private System.Windows.Forms.Label lp_price_sale_vip1;
        private System.Windows.Forms.Label lp1;
        private System.Windows.Forms.Label lp_price_sale_vip2;
        private System.Windows.Forms.Label lp_price_sale;
        private System.Windows.Forms.Label lp_price_sale_100;
        private System.Windows.Forms.Label lp5;
        private System.Windows.Forms.Label lp_total;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lp_price_10;
        private System.Windows.Forms.Label lp_price_9;
        private System.Windows.Forms.Label lp_price_8;
        private System.Windows.Forms.Label lp_price_7;
        private System.Windows.Forms.Label lp_price_6;
        private System.Windows.Forms.Label lp_price_5;
        private System.Windows.Forms.Label lp_price_4;
        private System.Windows.Forms.Label lp_price_3;
        private System.Windows.Forms.Label lp_price_2;
        private System.Windows.Forms.Label lp_price_1;
        private System.Windows.Forms.Button btn_export_exal;
        private System.Windows.Forms.Label lp_price_buy;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pic_login;
    }
}