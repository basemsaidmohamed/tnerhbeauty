﻿namespace tnerhbeauty
{
    partial class add_product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label adressLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label notsLabel;
            System.Windows.Forms.Label telLabel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label label10;
            System.Windows.Forms.Label lp_price_10;
            System.Windows.Forms.Label lp_price_9;
            System.Windows.Forms.Label lp_price_8;
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label label11;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(add_product));
            this.tx_name = new System.Windows.Forms.TextBox();
            this.tx_code = new System.Windows.Forms.TextBox();
            this.lb_mas = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btn_new = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.ch_isstop = new System.Windows.Forms.CheckBox();
            this.btn_print = new System.Windows.Forms.Button();
            this.tx_price_buy = new System.Windows.Forms.TextBox();
            this.tx_price_sale = new System.Windows.Forms.TextBox();
            this.lp_titel = new System.Windows.Forms.Label();
            this.tx_price_sale_100 = new System.Windows.Forms.TextBox();
            this.tx_price_sale_75 = new System.Windows.Forms.TextBox();
            this.tx_price_sale_vip2 = new System.Windows.Forms.TextBox();
            this.tx_price_sale_vip1 = new System.Windows.Forms.TextBox();
            this.tx_price_6 = new System.Windows.Forms.TextBox();
            this.tx_price_5 = new System.Windows.Forms.TextBox();
            this.tx_price_4 = new System.Windows.Forms.TextBox();
            this.tx_price_3 = new System.Windows.Forms.TextBox();
            this.tx_price_2 = new System.Windows.Forms.TextBox();
            this.tx_price_1 = new System.Windows.Forms.TextBox();
            this.tx_price_10 = new System.Windows.Forms.TextBox();
            this.tx_price_9 = new System.Windows.Forms.TextBox();
            this.tx_price_8 = new System.Windows.Forms.TextBox();
            this.tx_price_7 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tx_min_mum = new System.Windows.Forms.TextBox();
            this.maridBindingSource = new System.Windows.Forms.BindingSource(this.components);
            adressLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            notsLabel = new System.Windows.Forms.Label();
            telLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            lp_price_10 = new System.Windows.Forms.Label();
            lp_price_9 = new System.Windows.Forms.Label();
            lp_price_8 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maridBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // adressLabel
            // 
            adressLabel.AutoSize = true;
            adressLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            adressLabel.Location = new System.Drawing.Point(71, 130);
            adressLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            adressLabel.Name = "adressLabel";
            adressLabel.Size = new System.Drawing.Size(73, 19);
            adressLabel.TabIndex = 1;
            adressLabel.Text = "سعر الشراء";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            nameLabel.Location = new System.Drawing.Point(113, 98);
            nameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(31, 19);
            nameLabel.TabIndex = 17;
            nameLabel.Text = "كود ";
            // 
            // notsLabel
            // 
            notsLabel.AutoSize = true;
            notsLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            notsLabel.Location = new System.Drawing.Point(58, 162);
            notsLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            notsLabel.Name = "notsLabel";
            notsLabel.Size = new System.Drawing.Size(86, 19);
            notsLabel.TabIndex = 19;
            notsLabel.Text = "سعر البيع محل";
            // 
            // telLabel
            // 
            telLabel.AutoSize = true;
            telLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            telLabel.Location = new System.Drawing.Point(75, 66);
            telLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            telLabel.Name = "telLabel";
            telLabel.Size = new System.Drawing.Size(69, 19);
            telLabel.TabIndex = 23;
            telLabel.Text = "اسم الصنف";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.Location = new System.Drawing.Point(49, 194);
            label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(95, 19);
            label1.TabIndex = 1002;
            label1.Text = "سعر البيع  100";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.Location = new System.Drawing.Point(62, 226);
            label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(82, 19);
            label2.TabIndex = 1004;
            label2.Text = "سعر البيع 75";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.Location = new System.Drawing.Point(45, 258);
            label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(99, 19);
            label3.TabIndex = 1006;
            label3.Text = "سعر البيع VIP2";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label4.Location = new System.Drawing.Point(45, 290);
            label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(99, 19);
            label4.TabIndex = 1008;
            label4.Text = "سعر البيع VIP1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.Location = new System.Drawing.Point(79, 478);
            label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(65, 19);
            label5.TabIndex = 1020;
            label5.Text = "price_6";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label6.Location = new System.Drawing.Point(79, 446);
            label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(65, 19);
            label6.TabIndex = 1018;
            label6.Text = "price_5";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label7.Location = new System.Drawing.Point(79, 414);
            label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(65, 19);
            label7.TabIndex = 1016;
            label7.Text = "price_4";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label8.Location = new System.Drawing.Point(79, 382);
            label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(65, 19);
            label8.TabIndex = 1014;
            label8.Text = "price_3";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label9.Location = new System.Drawing.Point(79, 318);
            label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(65, 19);
            label9.TabIndex = 1009;
            label9.Text = "price_1";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label10.Location = new System.Drawing.Point(79, 350);
            label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(65, 19);
            label10.TabIndex = 1012;
            label10.Text = "price_2";
            // 
            // lp_price_10
            // 
            lp_price_10.AutoSize = true;
            lp_price_10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lp_price_10.Location = new System.Drawing.Point(70, 599);
            lp_price_10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            lp_price_10.Name = "lp_price_10";
            lp_price_10.Size = new System.Drawing.Size(74, 19);
            lp_price_10.TabIndex = 1028;
            lp_price_10.Text = "price_10";
            // 
            // lp_price_9
            // 
            lp_price_9.AutoSize = true;
            lp_price_9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lp_price_9.Location = new System.Drawing.Point(79, 567);
            lp_price_9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            lp_price_9.Name = "lp_price_9";
            lp_price_9.Size = new System.Drawing.Size(65, 19);
            lp_price_9.TabIndex = 1026;
            lp_price_9.Text = "price_9";
            // 
            // lp_price_8
            // 
            lp_price_8.AutoSize = true;
            lp_price_8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lp_price_8.Location = new System.Drawing.Point(79, 535);
            lp_price_8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            lp_price_8.Name = "lp_price_8";
            lp_price_8.Size = new System.Drawing.Size(65, 19);
            lp_price_8.TabIndex = 1024;
            lp_price_8.Text = "price_8";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label14.Location = new System.Drawing.Point(79, 503);
            label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(65, 19);
            label14.TabIndex = 1022;
            label14.Text = "price_7";
            // 
            // tx_name
            // 
            this.tx_name.BackColor = System.Drawing.Color.White;
            this.tx_name.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.maridBindingSource, "name", true));
            this.tx_name.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_name.Location = new System.Drawing.Point(149, 67);
            this.tx_name.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tx_name.Name = "tx_name";
            this.tx_name.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_name.Size = new System.Drawing.Size(467, 23);
            this.tx_name.TabIndex = 0;
            this.tx_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tx_code
            // 
            this.tx_code.BackColor = System.Drawing.Color.White;
            this.tx_code.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.maridBindingSource, "name", true));
            this.tx_code.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_code.Location = new System.Drawing.Point(149, 101);
            this.tx_code.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tx_code.MaxLength = 40;
            this.tx_code.Name = "tx_code";
            this.tx_code.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_code.Size = new System.Drawing.Size(467, 23);
            this.tx_code.TabIndex = 1;
            this.tx_code.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lb_mas
            // 
            this.lb_mas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lb_mas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_mas.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mas.ForeColor = System.Drawing.Color.White;
            this.lb_mas.Location = new System.Drawing.Point(0, 732);
            this.lb_mas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_mas.Name = "lb_mas";
            this.lb_mas.Size = new System.Drawing.Size(690, 34);
            this.lb_mas.TabIndex = 37;
            this.lb_mas.Text = "F12 = SAVE ; F2  NEW  ;  DELETE = DELETE ; CTRL +P = PRINT";
            this.lb_mas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_save
            // 
            this.btn_save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_save.BackColor = System.Drawing.Color.Purple;
            this.btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(272, 3);
            this.btn_save.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(86, 29);
            this.btn_save.TabIndex = 0;
            this.btn_save.Text = "حفظ";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Visible = false;
            this.btn_save.Click += new System.EventHandler(this.bt_save_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider1.ContainerControl = this;
            // 
            // btn_new
            // 
            this.btn_new.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_new.BackColor = System.Drawing.Color.Green;
            this.btn_new.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_new.FlatAppearance.BorderSize = 0;
            this.btn_new.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_new.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_new.ForeColor = System.Drawing.Color.White;
            this.btn_new.Location = new System.Drawing.Point(182, 3);
            this.btn_new.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(86, 29);
            this.btn_new.TabIndex = 38;
            this.btn_new.Text = "جديد";
            this.btn_new.UseVisualStyleBackColor = false;
            this.btn_new.Visible = false;
            this.btn_new.Click += new System.EventHandler(this.bt_new_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_delete.BackColor = System.Drawing.Color.Crimson;
            this.btn_delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(92, 3);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(86, 29);
            this.btn_delete.TabIndex = 40;
            this.btn_delete.Text = "حذف";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Visible = false;
            this.btn_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // ch_isstop
            // 
            this.ch_isstop.AutoSize = true;
            this.ch_isstop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch_isstop.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch_isstop.Location = new System.Drawing.Point(149, 658);
            this.ch_isstop.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ch_isstop.Name = "ch_isstop";
            this.ch_isstop.Size = new System.Drawing.Size(101, 23);
            this.ch_isstop.TabIndex = 18;
            this.ch_isstop.Text = "ايقاف التعامل ";
            this.ch_isstop.UseVisualStyleBackColor = true;
            // 
            // btn_print
            // 
            this.btn_print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_print.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_print.FlatAppearance.BorderSize = 0;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(2, 3);
            this.btn_print.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(86, 29);
            this.btn_print.TabIndex = 80;
            this.btn_print.Text = "طباعة";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Visible = false;
            this.btn_print.Click += new System.EventHandler(this.bt_print_Click);
            // 
            // tx_price_buy
            // 
            this.tx_price_buy.Location = new System.Drawing.Point(149, 135);
            this.tx_price_buy.Name = "tx_price_buy";
            this.tx_price_buy.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_buy.Size = new System.Drawing.Size(467, 20);
            this.tx_price_buy.TabIndex = 2;
            this.tx_price_buy.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_buy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_sale
            // 
            this.tx_price_sale.Location = new System.Drawing.Point(149, 166);
            this.tx_price_sale.Name = "tx_price_sale";
            this.tx_price_sale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_sale.Size = new System.Drawing.Size(467, 20);
            this.tx_price_sale.TabIndex = 3;
            this.tx_price_sale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_sale.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // lp_titel
            // 
            this.lp_titel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lp_titel.Dock = System.Windows.Forms.DockStyle.Top;
            this.lp_titel.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold);
            this.lp_titel.ForeColor = System.Drawing.Color.White;
            this.lp_titel.Image = global::tnerhbeauty.Properties.Resources.cubes;
            this.lp_titel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp_titel.Location = new System.Drawing.Point(0, 0);
            this.lp_titel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lp_titel.Name = "lp_titel";
            this.lp_titel.Size = new System.Drawing.Size(690, 35);
            this.lp_titel.TabIndex = 51;
            this.lp_titel.Text = "صنف جديد";
            this.lp_titel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tx_price_sale_100
            // 
            this.tx_price_sale_100.Location = new System.Drawing.Point(149, 197);
            this.tx_price_sale_100.Name = "tx_price_sale_100";
            this.tx_price_sale_100.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_sale_100.Size = new System.Drawing.Size(467, 20);
            this.tx_price_sale_100.TabIndex = 4;
            this.tx_price_sale_100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_sale_100.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_sale_75
            // 
            this.tx_price_sale_75.Location = new System.Drawing.Point(149, 228);
            this.tx_price_sale_75.Name = "tx_price_sale_75";
            this.tx_price_sale_75.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_sale_75.Size = new System.Drawing.Size(467, 20);
            this.tx_price_sale_75.TabIndex = 5;
            this.tx_price_sale_75.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_sale_75.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_sale_vip2
            // 
            this.tx_price_sale_vip2.Location = new System.Drawing.Point(149, 259);
            this.tx_price_sale_vip2.Name = "tx_price_sale_vip2";
            this.tx_price_sale_vip2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_sale_vip2.Size = new System.Drawing.Size(467, 20);
            this.tx_price_sale_vip2.TabIndex = 6;
            this.tx_price_sale_vip2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_sale_vip2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_sale_vip1
            // 
            this.tx_price_sale_vip1.Location = new System.Drawing.Point(149, 290);
            this.tx_price_sale_vip1.Name = "tx_price_sale_vip1";
            this.tx_price_sale_vip1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_sale_vip1.Size = new System.Drawing.Size(467, 20);
            this.tx_price_sale_vip1.TabIndex = 7;
            this.tx_price_sale_vip1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_sale_vip1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_6
            // 
            this.tx_price_6.Location = new System.Drawing.Point(149, 478);
            this.tx_price_6.Name = "tx_price_6";
            this.tx_price_6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_6.Size = new System.Drawing.Size(467, 20);
            this.tx_price_6.TabIndex = 13;
            this.tx_price_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_5
            // 
            this.tx_price_5.Location = new System.Drawing.Point(149, 447);
            this.tx_price_5.Name = "tx_price_5";
            this.tx_price_5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_5.Size = new System.Drawing.Size(467, 20);
            this.tx_price_5.TabIndex = 12;
            this.tx_price_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_4
            // 
            this.tx_price_4.Location = new System.Drawing.Point(149, 416);
            this.tx_price_4.Name = "tx_price_4";
            this.tx_price_4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_4.Size = new System.Drawing.Size(467, 20);
            this.tx_price_4.TabIndex = 11;
            this.tx_price_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_3
            // 
            this.tx_price_3.Location = new System.Drawing.Point(149, 385);
            this.tx_price_3.Name = "tx_price_3";
            this.tx_price_3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_3.Size = new System.Drawing.Size(467, 20);
            this.tx_price_3.TabIndex = 10;
            this.tx_price_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_2
            // 
            this.tx_price_2.Location = new System.Drawing.Point(149, 354);
            this.tx_price_2.Name = "tx_price_2";
            this.tx_price_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_2.Size = new System.Drawing.Size(467, 20);
            this.tx_price_2.TabIndex = 9;
            this.tx_price_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_1
            // 
            this.tx_price_1.Location = new System.Drawing.Point(149, 323);
            this.tx_price_1.Name = "tx_price_1";
            this.tx_price_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_1.Size = new System.Drawing.Size(467, 20);
            this.tx_price_1.TabIndex = 8;
            this.tx_price_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_10
            // 
            this.tx_price_10.Location = new System.Drawing.Point(149, 599);
            this.tx_price_10.Name = "tx_price_10";
            this.tx_price_10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_10.Size = new System.Drawing.Size(467, 20);
            this.tx_price_10.TabIndex = 17;
            this.tx_price_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_9
            // 
            this.tx_price_9.Location = new System.Drawing.Point(149, 568);
            this.tx_price_9.Name = "tx_price_9";
            this.tx_price_9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_9.Size = new System.Drawing.Size(467, 20);
            this.tx_price_9.TabIndex = 16;
            this.tx_price_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_8
            // 
            this.tx_price_8.Location = new System.Drawing.Point(149, 537);
            this.tx_price_8.Name = "tx_price_8";
            this.tx_price_8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_8.Size = new System.Drawing.Size(467, 20);
            this.tx_price_8.TabIndex = 15;
            this.tx_price_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tx_price_7
            // 
            this.tx_price_7.Location = new System.Drawing.Point(149, 506);
            this.tx_price_7.Name = "tx_price_7";
            this.tx_price_7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_price_7.Size = new System.Drawing.Size(467, 20);
            this.tx_price_7.TabIndex = 14;
            this.tx_price_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_price_7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.btn_save, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_new, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_delete, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_print, 3, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 694);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(360, 35);
            this.tableLayoutPanel1.TabIndex = 1029;
            // 
            // tx_min_mum
            // 
            this.tx_min_mum.Location = new System.Drawing.Point(149, 632);
            this.tx_min_mum.Name = "tx_min_mum";
            this.tx_min_mum.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tx_min_mum.Size = new System.Drawing.Size(467, 20);
            this.tx_min_mum.TabIndex = 1030;
            this.tx_min_mum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tx_min_mum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_price_buy_KeyPress);
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label11.Location = new System.Drawing.Point(91, 633);
            label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(53, 19);
            label11.TabIndex = 1031;
            label11.Text = "اقل كمية";
            // 
            // maridBindingSource
            // 
            this.maridBindingSource.DataSource = typeof(tnerhbeauty.Client);
            // 
            // add_product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(690, 766);
            this.Controls.Add(this.tx_min_mum);
            this.Controls.Add(label11);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tx_price_10);
            this.Controls.Add(lp_price_10);
            this.Controls.Add(this.tx_price_9);
            this.Controls.Add(lp_price_9);
            this.Controls.Add(this.tx_price_8);
            this.Controls.Add(lp_price_8);
            this.Controls.Add(this.tx_price_7);
            this.Controls.Add(label14);
            this.Controls.Add(this.tx_price_6);
            this.Controls.Add(label5);
            this.Controls.Add(this.tx_price_5);
            this.Controls.Add(label6);
            this.Controls.Add(this.tx_price_4);
            this.Controls.Add(label7);
            this.Controls.Add(this.tx_price_3);
            this.Controls.Add(label8);
            this.Controls.Add(this.tx_price_2);
            this.Controls.Add(this.tx_price_1);
            this.Controls.Add(label9);
            this.Controls.Add(label10);
            this.Controls.Add(this.tx_price_sale_vip1);
            this.Controls.Add(label4);
            this.Controls.Add(this.tx_price_sale_vip2);
            this.Controls.Add(label3);
            this.Controls.Add(this.tx_price_sale_75);
            this.Controls.Add(label2);
            this.Controls.Add(this.tx_price_sale_100);
            this.Controls.Add(label1);
            this.Controls.Add(this.tx_price_sale);
            this.Controls.Add(this.tx_price_buy);
            this.Controls.Add(this.ch_isstop);
            this.Controls.Add(this.lp_titel);
            this.Controls.Add(this.lb_mas);
            this.Controls.Add(this.tx_code);
            this.Controls.Add(adressLabel);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.tx_name);
            this.Controls.Add(notsLabel);
            this.Controls.Add(telLabel);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "add_product";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "صنف";
            this.Load += new System.EventHandler(this.add_marid_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.add_marid_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.maridBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource maridBindingSource;
        private System.Windows.Forms.TextBox tx_name;
        private System.Windows.Forms.TextBox tx_code;

        private System.Windows.Forms.Label lb_mas;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btn_new;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label lp_titel;
        private System.Windows.Forms.CheckBox ch_isstop;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.TextBox tx_price_sale;
        private System.Windows.Forms.TextBox tx_price_buy;
        private System.Windows.Forms.TextBox tx_price_sale_100;
        private System.Windows.Forms.TextBox tx_price_sale_vip1;
        private System.Windows.Forms.TextBox tx_price_sale_vip2;
        private System.Windows.Forms.TextBox tx_price_sale_75;
        private System.Windows.Forms.TextBox tx_price_6;
        private System.Windows.Forms.TextBox tx_price_5;
        private System.Windows.Forms.TextBox tx_price_4;
        private System.Windows.Forms.TextBox tx_price_3;
        private System.Windows.Forms.TextBox tx_price_2;
        private System.Windows.Forms.TextBox tx_price_1;
        private System.Windows.Forms.TextBox tx_price_10;
        private System.Windows.Forms.TextBox tx_price_9;
        private System.Windows.Forms.TextBox tx_price_8;
        private System.Windows.Forms.TextBox tx_price_7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox tx_min_mum;
    }
}