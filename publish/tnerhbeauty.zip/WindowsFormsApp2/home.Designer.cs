﻿namespace tnerhbeauty
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
            this.pan_home = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Img_Company = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.gv_max_sale = new tnerhbeauty.Class.datagrid();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.gv_min_balanc = new tnerhbeauty.Class.datagrid();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gv_max_balanc = new tnerhbeauty.Class.datagrid();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ts_groub_invoices = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_pay = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_pay_from_store = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_sale = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_to_store = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_return_to_supplier = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_return_from_client = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_taswiat_khasm = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_taswet_edafa = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_invoice_broken = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_show_invoice_pay = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_invoice_pay_from_store = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_invoice_sale = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_invoice_to_store = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_invoice_return_to_supplier = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_invoice_return_from_client = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_invoice_taswiat_khasm = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_invoice_taswet_edafa = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_invoice_broken = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_groub_product = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_new_product = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_all_product = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_update_price_producut = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_update_price_producut_exal = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_product_min_mum = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_frm_up_product_min_mum = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_groub_report_product = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_kashf_hesab_prodct = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_blance_in_storses = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_store_in_and_out = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_report_mabeat_product = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_groub_client = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_amount_client = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_all_amount_client = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_add_new_client = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_show_all_client = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_kashf_hesab_client = new System.Windows.Forms.ToolStripMenuItem();
            this.lb_company = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_groub_report = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_Amount = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_all_amount = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_report_all_amount = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_groub_setting = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_fara = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_all_fara = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_add_store = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_all_store = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_add_user = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_all_user = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_add_type_cash = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_all_type_cash = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_add_account = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_all_account = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.ts_all_user_access_store = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_add_setting = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_all_setting = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_server = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_groub_login = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_chang_pass = new System.Windows.Forms.ToolStripMenuItem();
            this.ts_logout = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Img_Company)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_max_sale)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_min_balanc)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_max_balanc)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pan_home
            // 
            this.pan_home.AutoSize = true;
            this.pan_home.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pan_home.Controls.Add(this.label4);
            this.pan_home.Controls.Add(this.Img_Company);
            this.pan_home.Controls.Add(this.panel3);
            this.pan_home.Controls.Add(this.panel2);
            this.pan_home.Controls.Add(this.panel1);
            this.pan_home.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_home.Location = new System.Drawing.Point(0, 70);
            this.pan_home.Margin = new System.Windows.Forms.Padding(0);
            this.pan_home.Name = "pan_home";
            this.pan_home.Size = new System.Drawing.Size(1298, 529);
            this.pan_home.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(5, 506);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 23);
            this.label4.TabIndex = 10;
            this.label4.Text = "Designed By Basem said";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Img_Company
            // 
            this.Img_Company.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Img_Company.BackgroundImage = global::tnerhbeauty.Properties.Resources.imgcompany;
            this.Img_Company.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Img_Company.ErrorImage = global::tnerhbeauty.Properties.Resources.imgcompany;
            this.Img_Company.Image = global::tnerhbeauty.Properties.Resources.imgcompany;
            this.Img_Company.Location = new System.Drawing.Point(5, 371);
            this.Img_Company.Margin = new System.Windows.Forms.Padding(0);
            this.Img_Company.Name = "Img_Company";
            this.Img_Company.Size = new System.Drawing.Size(148, 135);
            this.Img_Company.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Img_Company.TabIndex = 5;
            this.Img_Company.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.gv_max_sale);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(14, 11);
            this.panel3.Margin = new System.Windows.Forms.Padding(5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(411, 464);
            this.panel3.TabIndex = 14;
            // 
            // gv_max_sale
            // 
            this.gv_max_sale.AllowUserToAddRows = false;
            this.gv_max_sale.AllowUserToDeleteRows = false;
            this.gv_max_sale.AllowUserToResizeColumns = false;
            this.gv_max_sale.AllowUserToResizeRows = false;
            this.gv_max_sale.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_max_sale.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_max_sale.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv_max_sale.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv_max_sale.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_max_sale.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.gv_max_sale.ColumnHeadersHeight = 30;
            this.gv_max_sale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv_max_sale.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.gv_max_sale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_max_sale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_max_sale.EnableHeadersVisualStyles = false;
            this.gv_max_sale.GridColor = System.Drawing.Color.Black;
            this.gv_max_sale.Location = new System.Drawing.Point(0, 43);
            this.gv_max_sale.Margin = new System.Windows.Forms.Padding(0);
            this.gv_max_sale.Name = "gv_max_sale";
            this.gv_max_sale.ReadOnly = true;
            this.gv_max_sale.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gv_max_sale.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gv_max_sale.RowHeadersVisible = false;
            this.gv_max_sale.RowHeadersWidth = 35;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_max_sale.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.gv_max_sale.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_max_sale.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_max_sale.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_max_sale.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv_max_sale.RowTemplate.Height = 30;
            this.gv_max_sale.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_max_sale.Size = new System.Drawing.Size(411, 421);
            this.gv_max_sale.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "product_name";
            this.dataGridViewTextBoxColumn3.HeaderText = "اسم الصنف";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 160;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ItemQty_out";
            this.dataGridViewTextBoxColumn4.HeaderText = "الكمية";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(128)))), ((int)(((byte)(236)))));
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Arial", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(411, 43);
            this.label3.TabIndex = 12;
            this.label3.Text = "اصناف اعلي مبيعات شهر";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.gv_min_balanc);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(430, 10);
            this.panel2.Margin = new System.Windows.Forms.Padding(5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(458, 464);
            this.panel2.TabIndex = 13;
            // 
            // gv_min_balanc
            // 
            this.gv_min_balanc.AllowUserToAddRows = false;
            this.gv_min_balanc.AllowUserToDeleteRows = false;
            this.gv_min_balanc.AllowUserToResizeColumns = false;
            this.gv_min_balanc.AllowUserToResizeRows = false;
            this.gv_min_balanc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_min_balanc.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_min_balanc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv_min_balanc.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv_min_balanc.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_min_balanc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.gv_min_balanc.ColumnHeadersHeight = 30;
            this.gv_min_balanc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv_min_balanc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.Column3});
            this.gv_min_balanc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_min_balanc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_min_balanc.EnableHeadersVisualStyles = false;
            this.gv_min_balanc.GridColor = System.Drawing.Color.Black;
            this.gv_min_balanc.Location = new System.Drawing.Point(0, 43);
            this.gv_min_balanc.Margin = new System.Windows.Forms.Padding(0);
            this.gv_min_balanc.Name = "gv_min_balanc";
            this.gv_min_balanc.ReadOnly = true;
            this.gv_min_balanc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gv_min_balanc.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gv_min_balanc.RowHeadersVisible = false;
            this.gv_min_balanc.RowHeadersWidth = 35;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_min_balanc.RowsDefaultCellStyle = dataGridViewCellStyle27;
            this.gv_min_balanc.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_min_balanc.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_min_balanc.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_min_balanc.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv_min_balanc.RowTemplate.Height = 30;
            this.gv_min_balanc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_min_balanc.Size = new System.Drawing.Size(458, 421);
            this.gv_min_balanc.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "fullname";
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle24;
            this.dataGridViewTextBoxColumn1.HeaderText = "اسم الصنف";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Balance";
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridViewTextBoxColumn2.HeaderText = "الرصيد الحالي";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column3.DataPropertyName = "min_mum";
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.DefaultCellStyle = dataGridViewCellStyle26;
            this.Column3.HeaderText = "الحد الادني";
            this.Column3.MinimumWidth = 100;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 102;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(128)))), ((int)(((byte)(236)))));
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Arial", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(458, 43);
            this.label2.TabIndex = 12;
            this.label2.Text = "اصناف مطلوبه";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.gv_max_balanc);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(898, 10);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(390, 464);
            this.panel1.TabIndex = 12;
            // 
            // gv_max_balanc
            // 
            this.gv_max_balanc.AllowUserToAddRows = false;
            this.gv_max_balanc.AllowUserToDeleteRows = false;
            this.gv_max_balanc.AllowUserToResizeColumns = false;
            this.gv_max_balanc.AllowUserToResizeRows = false;
            this.gv_max_balanc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gv_max_balanc.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_max_balanc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gv_max_balanc.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gv_max_balanc.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(96)))), ((int)(((byte)(232)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_max_balanc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.gv_max_balanc.ColumnHeadersHeight = 30;
            this.gv_max_balanc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gv_max_balanc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.gv_max_balanc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gv_max_balanc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_max_balanc.EnableHeadersVisualStyles = false;
            this.gv_max_balanc.GridColor = System.Drawing.Color.Black;
            this.gv_max_balanc.Location = new System.Drawing.Point(0, 43);
            this.gv_max_balanc.Margin = new System.Windows.Forms.Padding(0);
            this.gv_max_balanc.Name = "gv_max_balanc";
            this.gv_max_balanc.ReadOnly = true;
            this.gv_max_balanc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gv_max_balanc.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gv_max_balanc.RowHeadersVisible = false;
            this.gv_max_balanc.RowHeadersWidth = 35;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_max_balanc.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.gv_max_balanc.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_max_balanc.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_max_balanc.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.gv_max_balanc.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gv_max_balanc.RowTemplate.Height = 30;
            this.gv_max_balanc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_max_balanc.Size = new System.Drawing.Size(390, 421);
            this.gv_max_balanc.TabIndex = 11;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.DataPropertyName = "name";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle29;
            this.Column1.HeaderText = "اسم الصنف";
            this.Column1.MinimumWidth = 160;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.Column2.DataPropertyName = "Balance";
            this.Column2.HeaderText = "الرصيد الحالي";
            this.Column2.MinimumWidth = 100;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(128)))), ((int)(((byte)(236)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(390, 43);
            this.label1.TabIndex = 12;
            this.label1.Text = "الاصناف الاعلي رصيد";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.menuStrip1.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(0);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(19, 19);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts_groub_invoices,
            this.ts_groub_product,
            this.ts_groub_report_product,
            this.ts_groub_client,
            this.lb_company,
            this.ts_groub_report,
            this.ts_groub_setting,
            this.ts_server,
            this.ts_groub_login});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 7, 7, 5);
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(1298, 70);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ts_groub_invoices
            // 
            this.ts_groub_invoices.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts_add_invoice_pay,
            this.ts_add_invoice_pay_from_store,
            this.ts_add_invoice_sale,
            this.ts_add_invoice_to_store,
            this.ts_add_invoice_return_to_supplier,
            this.ts_add_invoice_return_from_client,
            this.ts_add_invoice_taswiat_khasm,
            this.ts_add_invoice_taswet_edafa,
            this.ts_add_invoice_broken,
            this.toolStripSeparator6,
            this.ts_show_invoice_pay,
            this.ts_show_invoice_pay_from_store,
            this.ts_show_invoice_sale,
            this.ts_show_invoice_to_store,
            this.ts_show_invoice_return_to_supplier,
            this.ts_show_invoice_return_from_client,
            this.ts_show_invoice_taswiat_khasm,
            this.ts_show_invoice_taswet_edafa,
            this.ts_show_invoice_broken});
            this.ts_groub_invoices.ForeColor = System.Drawing.Color.White;
            this.ts_groub_invoices.Image = global::tnerhbeauty.Properties.Resources.invoice;
            this.ts_groub_invoices.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_invoices.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_groub_invoices.Name = "ts_groub_invoices";
            this.ts_groub_invoices.Size = new System.Drawing.Size(63, 58);
            this.ts_groub_invoices.Text = "فاتورة";
            this.ts_groub_invoices.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_invoices.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ts_add_invoice_pay
            // 
            this.ts_add_invoice_pay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_pay.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_pay.Image = global::tnerhbeauty.Properties.Resources.price_list;
            this.ts_add_invoice_pay.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_pay.Name = "ts_add_invoice_pay";
            this.ts_add_invoice_pay.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_pay.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_pay.Tag = "1";
            this.ts_add_invoice_pay.Text = "فاتورة بيان اسعار";
            this.ts_add_invoice_pay.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // ts_add_invoice_pay_from_store
            // 
            this.ts_add_invoice_pay_from_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_pay_from_store.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_pay_from_store.Image = global::tnerhbeauty.Properties.Resources.time;
            this.ts_add_invoice_pay_from_store.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_pay_from_store.Name = "ts_add_invoice_pay_from_store";
            this.ts_add_invoice_pay_from_store.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_pay_from_store.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_pay_from_store.Tag = "4";
            this.ts_add_invoice_pay_from_store.Text = "فاتورة بيان اسعار من المخزن للعميل";
            this.ts_add_invoice_pay_from_store.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // ts_add_invoice_sale
            // 
            this.ts_add_invoice_sale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_sale.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_sale.Image = global::tnerhbeauty.Properties.Resources.payment_method;
            this.ts_add_invoice_sale.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_sale.Name = "ts_add_invoice_sale";
            this.ts_add_invoice_sale.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_sale.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_sale.Tag = "2";
            this.ts_add_invoice_sale.Text = "فاتورة مشتريات";
            this.ts_add_invoice_sale.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // ts_add_invoice_to_store
            // 
            this.ts_add_invoice_to_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_to_store.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_to_store.Image = global::tnerhbeauty.Properties.Resources.exchange;
            this.ts_add_invoice_to_store.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_to_store.Name = "ts_add_invoice_to_store";
            this.ts_add_invoice_to_store.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_to_store.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_to_store.Tag = "3";
            this.ts_add_invoice_to_store.Text = "فاتورة تحويل من مخزن الي مخزن";
            this.ts_add_invoice_to_store.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // ts_add_invoice_return_to_supplier
            // 
            this.ts_add_invoice_return_to_supplier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_return_to_supplier.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_return_to_supplier.Image = global::tnerhbeauty.Properties.Resources.arrow_right;
            this.ts_add_invoice_return_to_supplier.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_return_to_supplier.Name = "ts_add_invoice_return_to_supplier";
            this.ts_add_invoice_return_to_supplier.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_return_to_supplier.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_return_to_supplier.Tag = "8";
            this.ts_add_invoice_return_to_supplier.Text = "فاتورة مرتجع الي المصنع";
            this.ts_add_invoice_return_to_supplier.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // ts_add_invoice_return_from_client
            // 
            this.ts_add_invoice_return_from_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_return_from_client.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_return_from_client.Image = global::tnerhbeauty.Properties.Resources.return_box;
            this.ts_add_invoice_return_from_client.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_return_from_client.Name = "ts_add_invoice_return_from_client";
            this.ts_add_invoice_return_from_client.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_return_from_client.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_return_from_client.Tag = "9";
            this.ts_add_invoice_return_from_client.Text = "فاتورة مرتجع من العميل";
            this.ts_add_invoice_return_from_client.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // ts_add_invoice_taswiat_khasm
            // 
            this.ts_add_invoice_taswiat_khasm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_taswiat_khasm.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_taswiat_khasm.Image = global::tnerhbeauty.Properties.Resources.right_arrow;
            this.ts_add_invoice_taswiat_khasm.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_taswiat_khasm.Name = "ts_add_invoice_taswiat_khasm";
            this.ts_add_invoice_taswiat_khasm.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_taswiat_khasm.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_taswiat_khasm.Tag = "7";
            this.ts_add_invoice_taswiat_khasm.Text = "فاتورة تسوية خصم رصيد";
            this.ts_add_invoice_taswiat_khasm.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // ts_add_invoice_taswet_edafa
            // 
            this.ts_add_invoice_taswet_edafa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_taswet_edafa.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_taswet_edafa.Image = global::tnerhbeauty.Properties.Resources.left_arrow;
            this.ts_add_invoice_taswet_edafa.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_taswet_edafa.Name = "ts_add_invoice_taswet_edafa";
            this.ts_add_invoice_taswet_edafa.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_taswet_edafa.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_taswet_edafa.Tag = "6";
            this.ts_add_invoice_taswet_edafa.Text = "فاتورة تسوية اضافة رصيد";
            this.ts_add_invoice_taswet_edafa.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // ts_add_invoice_broken
            // 
            this.ts_add_invoice_broken.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_invoice_broken.ForeColor = System.Drawing.Color.White;
            this.ts_add_invoice_broken.Image = global::tnerhbeauty.Properties.Resources.damaged_package;
            this.ts_add_invoice_broken.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_invoice_broken.Name = "ts_add_invoice_broken";
            this.ts_add_invoice_broken.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_invoice_broken.Size = new System.Drawing.Size(364, 38);
            this.ts_add_invoice_broken.Tag = "10";
            this.ts_add_invoice_broken.Text = "فاتورة هالك";
            this.ts_add_invoice_broken.Click += new System.EventHandler(this.ts_new_invoice_nots_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.AutoSize = false;
            this.toolStripSeparator6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.toolStripSeparator6.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(360, 1);
            // 
            // ts_show_invoice_pay
            // 
            this.ts_show_invoice_pay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_pay.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_pay.Image = global::tnerhbeauty.Properties.Resources.price_list;
            this.ts_show_invoice_pay.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_pay.Name = "ts_show_invoice_pay";
            this.ts_show_invoice_pay.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_pay.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_pay.Tag = "1";
            this.ts_show_invoice_pay.Text = "عرض فواتير بيان اسعار";
            this.ts_show_invoice_pay.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_show_invoice_pay_from_store
            // 
            this.ts_show_invoice_pay_from_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_pay_from_store.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_pay_from_store.Image = global::tnerhbeauty.Properties.Resources.time;
            this.ts_show_invoice_pay_from_store.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_pay_from_store.Name = "ts_show_invoice_pay_from_store";
            this.ts_show_invoice_pay_from_store.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_pay_from_store.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_pay_from_store.Tag = "4";
            this.ts_show_invoice_pay_from_store.Text = "عرض  فواتير بيان اسعار من المخزن";
            this.ts_show_invoice_pay_from_store.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_show_invoice_sale
            // 
            this.ts_show_invoice_sale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_sale.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_sale.Image = global::tnerhbeauty.Properties.Resources.payment_method;
            this.ts_show_invoice_sale.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_sale.Name = "ts_show_invoice_sale";
            this.ts_show_invoice_sale.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_sale.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_sale.Tag = "2";
            this.ts_show_invoice_sale.Text = "عرض فواتير المشتريات";
            this.ts_show_invoice_sale.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_show_invoice_to_store
            // 
            this.ts_show_invoice_to_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_to_store.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_to_store.Image = global::tnerhbeauty.Properties.Resources.exchange;
            this.ts_show_invoice_to_store.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_to_store.Name = "ts_show_invoice_to_store";
            this.ts_show_invoice_to_store.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_to_store.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_to_store.Tag = "3";
            this.ts_show_invoice_to_store.Text = "عرض  فواتير تحويل من مخزن الي مخزن";
            this.ts_show_invoice_to_store.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_show_invoice_return_to_supplier
            // 
            this.ts_show_invoice_return_to_supplier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_return_to_supplier.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_return_to_supplier.Image = global::tnerhbeauty.Properties.Resources.arrow_right;
            this.ts_show_invoice_return_to_supplier.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_return_to_supplier.Name = "ts_show_invoice_return_to_supplier";
            this.ts_show_invoice_return_to_supplier.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_return_to_supplier.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_return_to_supplier.Tag = "8";
            this.ts_show_invoice_return_to_supplier.Text = "عرض  فواتير مرتجع الي المصنع";
            this.ts_show_invoice_return_to_supplier.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_show_invoice_return_from_client
            // 
            this.ts_show_invoice_return_from_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_return_from_client.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_return_from_client.Image = global::tnerhbeauty.Properties.Resources.return_box;
            this.ts_show_invoice_return_from_client.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_return_from_client.Name = "ts_show_invoice_return_from_client";
            this.ts_show_invoice_return_from_client.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_return_from_client.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_return_from_client.Tag = "9";
            this.ts_show_invoice_return_from_client.Text = "عرض  فواتير مرتجع من العميل";
            this.ts_show_invoice_return_from_client.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_show_invoice_taswiat_khasm
            // 
            this.ts_show_invoice_taswiat_khasm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_taswiat_khasm.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_taswiat_khasm.Image = global::tnerhbeauty.Properties.Resources.right_arrow;
            this.ts_show_invoice_taswiat_khasm.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_taswiat_khasm.Name = "ts_show_invoice_taswiat_khasm";
            this.ts_show_invoice_taswiat_khasm.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_taswiat_khasm.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_taswiat_khasm.Tag = "7";
            this.ts_show_invoice_taswiat_khasm.Text = "عرض  فواتير تسوية خصم";
            this.ts_show_invoice_taswiat_khasm.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_show_invoice_taswet_edafa
            // 
            this.ts_show_invoice_taswet_edafa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_taswet_edafa.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_taswet_edafa.Image = global::tnerhbeauty.Properties.Resources.left_arrow;
            this.ts_show_invoice_taswet_edafa.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_taswet_edafa.Name = "ts_show_invoice_taswet_edafa";
            this.ts_show_invoice_taswet_edafa.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_taswet_edafa.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_taswet_edafa.Tag = "6";
            this.ts_show_invoice_taswet_edafa.Text = "عرض  فواتير تسوية اضافة";
            this.ts_show_invoice_taswet_edafa.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_show_invoice_broken
            // 
            this.ts_show_invoice_broken.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_invoice_broken.ForeColor = System.Drawing.Color.White;
            this.ts_show_invoice_broken.Image = global::tnerhbeauty.Properties.Resources.damaged_package1;
            this.ts_show_invoice_broken.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_invoice_broken.Name = "ts_show_invoice_broken";
            this.ts_show_invoice_broken.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_invoice_broken.Size = new System.Drawing.Size(364, 38);
            this.ts_show_invoice_broken.Tag = "10";
            this.ts_show_invoice_broken.Text = "عرض  فواتير الهالك";
            this.ts_show_invoice_broken.Click += new System.EventHandler(this.ts_all_invoice_pay_cash_Click);
            // 
            // ts_groub_product
            // 
            this.ts_groub_product.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts_add_new_product,
            this.ts_show_all_product,
            this.toolStripSeparator4,
            this.ts_update_price_producut,
            this.ts_update_price_producut_exal,
            this.toolStripSeparator3,
            this.ts_product_min_mum,
            this.ts_frm_up_product_min_mum});
            this.ts_groub_product.ForeColor = System.Drawing.Color.White;
            this.ts_groub_product.Image = global::tnerhbeauty.Properties.Resources.database_data;
            this.ts_groub_product.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_product.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_groub_product.Name = "ts_groub_product";
            this.ts_groub_product.Size = new System.Drawing.Size(75, 58);
            this.ts_groub_product.Text = "الاصناف";
            this.ts_groub_product.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_product.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ts_add_new_product
            // 
            this.ts_add_new_product.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_new_product.ForeColor = System.Drawing.Color.White;
            this.ts_add_new_product.Image = global::tnerhbeauty.Properties.Resources.cubes__1_;
            this.ts_add_new_product.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_new_product.Name = "ts_add_new_product";
            this.ts_add_new_product.Padding = new System.Windows.Forms.Padding(0, 1, 1, 0);
            this.ts_add_new_product.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ts_add_new_product.Size = new System.Drawing.Size(284, 37);
            this.ts_add_new_product.Text = "اضافة صنف جديد";
            this.ts_add_new_product.Click += new System.EventHandler(this.ts_add_new_product_Click);
            // 
            // ts_show_all_product
            // 
            this.ts_show_all_product.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_all_product.ForeColor = System.Drawing.Color.White;
            this.ts_show_all_product.Image = global::tnerhbeauty.Properties.Resources.search;
            this.ts_show_all_product.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_all_product.Name = "ts_show_all_product";
            this.ts_show_all_product.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_all_product.Size = new System.Drawing.Size(284, 38);
            this.ts_show_all_product.Text = "عرض الاصناف";
            this.ts_show_all_product.Click += new System.EventHandler(this.ts_show_all_product_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.AutoSize = false;
            this.toolStripSeparator4.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator4.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(280, 1);
            // 
            // ts_update_price_producut
            // 
            this.ts_update_price_producut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_update_price_producut.ForeColor = System.Drawing.Color.White;
            this.ts_update_price_producut.Image = global::tnerhbeauty.Properties.Resources.product;
            this.ts_update_price_producut.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_update_price_producut.Name = "ts_update_price_producut";
            this.ts_update_price_producut.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_update_price_producut.Size = new System.Drawing.Size(284, 38);
            this.ts_update_price_producut.Text = "زيادة وخفض اسعار الاصناف";
            this.ts_update_price_producut.Click += new System.EventHandler(this.ts_update_price_producut_Click);
            // 
            // ts_update_price_producut_exal
            // 
            this.ts_update_price_producut_exal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_update_price_producut_exal.ForeColor = System.Drawing.Color.White;
            this.ts_update_price_producut_exal.Image = global::tnerhbeauty.Properties.Resources.excel;
            this.ts_update_price_producut_exal.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_update_price_producut_exal.Name = "ts_update_price_producut_exal";
            this.ts_update_price_producut_exal.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_update_price_producut_exal.Size = new System.Drawing.Size(284, 38);
            this.ts_update_price_producut_exal.Text = "تحديث اسعار الاصناف اكسل";
            this.ts_update_price_producut_exal.Click += new System.EventHandler(this.ts_update_price_producut_exal_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.AutoSize = false;
            this.toolStripSeparator3.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator3.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(280, 1);
            // 
            // ts_product_min_mum
            // 
            this.ts_product_min_mum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_product_min_mum.ForeColor = System.Drawing.Color.White;
            this.ts_product_min_mum.Image = global::tnerhbeauty.Properties.Resources.notification;
            this.ts_product_min_mum.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_product_min_mum.Name = "ts_product_min_mum";
            this.ts_product_min_mum.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_product_min_mum.Size = new System.Drawing.Size(284, 38);
            this.ts_product_min_mum.Text = "اصناف حد الطلب";
            this.ts_product_min_mum.Click += new System.EventHandler(this.ts_product_min_mum_Click);
            // 
            // ts_frm_up_product_min_mum
            // 
            this.ts_frm_up_product_min_mum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_frm_up_product_min_mum.ForeColor = System.Drawing.Color.White;
            this.ts_frm_up_product_min_mum.Image = global::tnerhbeauty.Properties.Resources.reminder;
            this.ts_frm_up_product_min_mum.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_frm_up_product_min_mum.Name = "ts_frm_up_product_min_mum";
            this.ts_frm_up_product_min_mum.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_frm_up_product_min_mum.Size = new System.Drawing.Size(284, 38);
            this.ts_frm_up_product_min_mum.Text = "تحديث حد الطلب من الاكسل";
            this.ts_frm_up_product_min_mum.Click += new System.EventHandler(this.ts_frm_up_product_min_mum_Click);
            // 
            // ts_groub_report_product
            // 
            this.ts_groub_report_product.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts_kashf_hesab_prodct,
            this.ts_blance_in_storses,
            this.ts_store_in_and_out,
            this.ts_report_mabeat_product});
            this.ts_groub_report_product.ForeColor = System.Drawing.Color.White;
            this.ts_groub_report_product.Image = global::tnerhbeauty.Properties.Resources.trend;
            this.ts_groub_report_product.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_report_product.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_groub_report_product.Name = "ts_groub_report_product";
            this.ts_groub_report_product.Size = new System.Drawing.Size(112, 58);
            this.ts_groub_report_product.Text = "تقرير الاصناف";
            this.ts_groub_report_product.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_report_product.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ts_kashf_hesab_prodct
            // 
            this.ts_kashf_hesab_prodct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_kashf_hesab_prodct.ForeColor = System.Drawing.Color.White;
            this.ts_kashf_hesab_prodct.Image = global::tnerhbeauty.Properties.Resources.accounts;
            this.ts_kashf_hesab_prodct.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_kashf_hesab_prodct.Name = "ts_kashf_hesab_prodct";
            this.ts_kashf_hesab_prodct.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_kashf_hesab_prodct.Size = new System.Drawing.Size(307, 38);
            this.ts_kashf_hesab_prodct.Text = "كشف حساب صنف";
            this.ts_kashf_hesab_prodct.Click += new System.EventHandler(this.ts_kashf_hesab_prodct_Click);
            // 
            // ts_blance_in_storses
            // 
            this.ts_blance_in_storses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_blance_in_storses.ForeColor = System.Drawing.Color.White;
            this.ts_blance_in_storses.Image = global::tnerhbeauty.Properties.Resources.report;
            this.ts_blance_in_storses.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_blance_in_storses.Name = "ts_blance_in_storses";
            this.ts_blance_in_storses.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_blance_in_storses.Size = new System.Drawing.Size(307, 38);
            this.ts_blance_in_storses.Text = "ارصده الاصناف";
            this.ts_blance_in_storses.Click += new System.EventHandler(this.ts_blance_in_storses_Click);
            // 
            // ts_store_in_and_out
            // 
            this.ts_store_in_and_out.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_store_in_and_out.ForeColor = System.Drawing.Color.White;
            this.ts_store_in_and_out.Image = global::tnerhbeauty.Properties.Resources.fifo;
            this.ts_store_in_and_out.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_store_in_and_out.Name = "ts_store_in_and_out";
            this.ts_store_in_and_out.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_store_in_and_out.Size = new System.Drawing.Size(307, 38);
            this.ts_store_in_and_out.Text = "حركة الاصناف الواردة والصادرة";
            this.ts_store_in_and_out.Click += new System.EventHandler(this.ts_store_in_and_out_Click);
            // 
            // ts_report_mabeat_product
            // 
            this.ts_report_mabeat_product.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_report_mabeat_product.ForeColor = System.Drawing.Color.White;
            this.ts_report_mabeat_product.Image = global::tnerhbeauty.Properties.Resources.price;
            this.ts_report_mabeat_product.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_report_mabeat_product.Name = "ts_report_mabeat_product";
            this.ts_report_mabeat_product.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_report_mabeat_product.Size = new System.Drawing.Size(307, 38);
            this.ts_report_mabeat_product.Text = "تقرير حركات العملاء والاصناف";
            this.ts_report_mabeat_product.Click += new System.EventHandler(this.ts_report_mabeat_product_Click);
            // 
            // ts_groub_client
            // 
            this.ts_groub_client.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts_add_amount_client,
            this.ts_all_amount_client,
            this.toolStripSeparator2,
            this.ts_add_new_client,
            this.ts_show_all_client,
            this.toolStripSeparator1,
            this.ts_kashf_hesab_client});
            this.ts_groub_client.ForeColor = System.Drawing.Color.White;
            this.ts_groub_client.Image = global::tnerhbeauty.Properties.Resources.profile;
            this.ts_groub_client.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_client.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_groub_client.Name = "ts_groub_client";
            this.ts_groub_client.Size = new System.Drawing.Size(66, 58);
            this.ts_groub_client.Text = "العملاء";
            this.ts_groub_client.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_client.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ts_add_amount_client
            // 
            this.ts_add_amount_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_amount_client.ForeColor = System.Drawing.Color.White;
            this.ts_add_amount_client.Image = global::tnerhbeauty.Properties.Resources.payment_method;
            this.ts_add_amount_client.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_amount_client.Name = "ts_add_amount_client";
            this.ts_add_amount_client.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_amount_client.Size = new System.Drawing.Size(231, 38);
            this.ts_add_amount_client.Text = "اضافة دفعة عميل";
            this.ts_add_amount_client.Click += new System.EventHandler(this.ts_add_amount_client_Click);
            // 
            // ts_all_amount_client
            // 
            this.ts_all_amount_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_amount_client.ForeColor = System.Drawing.Color.White;
            this.ts_all_amount_client.Image = global::tnerhbeauty.Properties.Resources.profile;
            this.ts_all_amount_client.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_amount_client.Name = "ts_all_amount_client";
            this.ts_all_amount_client.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.ts_all_amount_client.Size = new System.Drawing.Size(231, 36);
            this.ts_all_amount_client.Text = "عرض جميع الدفعات";
            this.ts_all_amount_client.Click += new System.EventHandler(this.ts_all_amount_client_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.AutoSize = false;
            this.toolStripSeparator2.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator2.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(227, 1);
            // 
            // ts_add_new_client
            // 
            this.ts_add_new_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_new_client.ForeColor = System.Drawing.Color.White;
            this.ts_add_new_client.Image = global::tnerhbeauty.Properties.Resources.add_user;
            this.ts_add_new_client.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_new_client.Name = "ts_add_new_client";
            this.ts_add_new_client.Padding = new System.Windows.Forms.Padding(0, 0, 1, 1);
            this.ts_add_new_client.Size = new System.Drawing.Size(231, 37);
            this.ts_add_new_client.Text = "اضافة عميل جديد";
            this.ts_add_new_client.Click += new System.EventHandler(this.ts_add_new_client_Click);
            // 
            // ts_show_all_client
            // 
            this.ts_show_all_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_show_all_client.ForeColor = System.Drawing.Color.White;
            this.ts_show_all_client.Image = global::tnerhbeauty.Properties.Resources.profile;
            this.ts_show_all_client.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_show_all_client.Name = "ts_show_all_client";
            this.ts_show_all_client.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_show_all_client.Size = new System.Drawing.Size(231, 38);
            this.ts_show_all_client.Text = "عرض جميع العملاء";
            this.ts_show_all_client.Click += new System.EventHandler(this.ts_show_all_sick_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.AutoSize = false;
            this.toolStripSeparator1.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator1.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(227, 1);
            // 
            // ts_kashf_hesab_client
            // 
            this.ts_kashf_hesab_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_kashf_hesab_client.ForeColor = System.Drawing.Color.White;
            this.ts_kashf_hesab_client.Image = global::tnerhbeauty.Properties.Resources.price_list;
            this.ts_kashf_hesab_client.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_kashf_hesab_client.Name = "ts_kashf_hesab_client";
            this.ts_kashf_hesab_client.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_kashf_hesab_client.Size = new System.Drawing.Size(231, 38);
            this.ts_kashf_hesab_client.Text = "كشف حساب عميل";
            this.ts_kashf_hesab_client.Click += new System.EventHandler(this.ts_kashf_hesab_client_Click);
            // 
            // lb_company
            // 
            this.lb_company.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lb_company.Font = new System.Drawing.Font("Arial", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_company.ForeColor = System.Drawing.Color.Lime;
            this.lb_company.Image = global::tnerhbeauty.Properties.Resources.setting_cogwheel;
            this.lb_company.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.lb_company.Name = "lb_company";
            this.lb_company.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lb_company.Size = new System.Drawing.Size(97, 58);
            this.lb_company.Text = "الشركة";
            this.lb_company.Click += new System.EventHandler(this.ts_CompanyInfo_Click);
            // 
            // ts_groub_report
            // 
            this.ts_groub_report.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts_add_Amount,
            this.ts_all_amount,
            this.toolStripSeparator11,
            this.ts_report_all_amount});
            this.ts_groub_report.ForeColor = System.Drawing.Color.White;
            this.ts_groub_report.Image = global::tnerhbeauty.Properties.Resources.price_list;
            this.ts_groub_report.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_report.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_groub_report.Name = "ts_groub_report";
            this.ts_groub_report.Size = new System.Drawing.Size(71, 58);
            this.ts_groub_report.Text = "حسابات";
            this.ts_groub_report.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_report.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ts_add_Amount
            // 
            this.ts_add_Amount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_Amount.ForeColor = System.Drawing.Color.White;
            this.ts_add_Amount.Image = global::tnerhbeauty.Properties.Resources.spreadsheet;
            this.ts_add_Amount.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_Amount.Name = "ts_add_Amount";
            this.ts_add_Amount.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_Amount.Size = new System.Drawing.Size(275, 38);
            this.ts_add_Amount.Text = "ايرادات و مصروفات";
            this.ts_add_Amount.Click += new System.EventHandler(this.ts_add_Amount_Click);
            // 
            // ts_all_amount
            // 
            this.ts_all_amount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_amount.ForeColor = System.Drawing.Color.White;
            this.ts_all_amount.Image = global::tnerhbeauty.Properties.Resources.budget;
            this.ts_all_amount.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_amount.Name = "ts_all_amount";
            this.ts_all_amount.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_all_amount.Size = new System.Drawing.Size(275, 38);
            this.ts_all_amount.Text = "عرض ايرادات و مصروفات";
            this.ts_all_amount.Click += new System.EventHandler(this.ts_all_amount_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.AutoSize = false;
            this.toolStripSeparator11.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator11.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(271, 1);
            // 
            // ts_report_all_amount
            // 
            this.ts_report_all_amount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_report_all_amount.ForeColor = System.Drawing.Color.White;
            this.ts_report_all_amount.Image = global::tnerhbeauty.Properties.Resources.expensive;
            this.ts_report_all_amount.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_report_all_amount.Name = "ts_report_all_amount";
            this.ts_report_all_amount.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_report_all_amount.Size = new System.Drawing.Size(275, 38);
            this.ts_report_all_amount.Text = "تقرير العمليات اليومية";
            this.ts_report_all_amount.Click += new System.EventHandler(this.ts_report_all_amount_Click);
            // 
            // ts_groub_setting
            // 
            this.ts_groub_setting.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts_add_fara,
            this.ts_all_fara,
            this.toolStripSeparator9,
            this.ts_add_store,
            this.ts_all_store,
            this.toolStripSeparator10,
            this.ts_add_user,
            this.ts_all_user,
            this.toolStripSeparator7,
            this.ts_add_type_cash,
            this.ts_all_type_cash,
            this.toolStripSeparator5,
            this.ts_add_account,
            this.ts_all_account,
            this.toolStripSeparator8,
            this.ts_all_user_access_store,
            this.ts_add_setting,
            this.ts_all_setting});
            this.ts_groub_setting.ForeColor = System.Drawing.Color.White;
            this.ts_groub_setting.Image = global::tnerhbeauty.Properties.Resources.shield;
            this.ts_groub_setting.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_setting.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_groub_setting.Name = "ts_groub_setting";
            this.ts_groub_setting.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ts_groub_setting.Size = new System.Drawing.Size(72, 58);
            this.ts_groub_setting.Text = "اعدادات";
            this.ts_groub_setting.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_setting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ts_add_fara
            // 
            this.ts_add_fara.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_fara.ForeColor = System.Drawing.Color.White;
            this.ts_add_fara.Image = global::tnerhbeauty.Properties.Resources.placeholder;
            this.ts_add_fara.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_fara.Name = "ts_add_fara";
            this.ts_add_fara.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_fara.Size = new System.Drawing.Size(317, 38);
            this.ts_add_fara.Text = "اضافة  فرع جديد";
            this.ts_add_fara.Click += new System.EventHandler(this.ts_add_fara_Click);
            // 
            // ts_all_fara
            // 
            this.ts_all_fara.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_fara.ForeColor = System.Drawing.Color.White;
            this.ts_all_fara.Image = global::tnerhbeauty.Properties.Resources.search_location;
            this.ts_all_fara.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_fara.Name = "ts_all_fara";
            this.ts_all_fara.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_all_fara.Size = new System.Drawing.Size(317, 38);
            this.ts_all_fara.Text = "عرض جميع الفروع";
            this.ts_all_fara.Click += new System.EventHandler(this.ts_all_fara_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.AutoSize = false;
            this.toolStripSeparator9.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator9.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(313, 1);
            // 
            // ts_add_store
            // 
            this.ts_add_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_store.ForeColor = System.Drawing.Color.White;
            this.ts_add_store.Image = global::tnerhbeauty.Properties.Resources.online_shop;
            this.ts_add_store.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_store.Name = "ts_add_store";
            this.ts_add_store.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_store.Size = new System.Drawing.Size(317, 38);
            this.ts_add_store.Text = "اضافة مخزن جديد";
            this.ts_add_store.Click += new System.EventHandler(this.ts_add_store_Click);
            // 
            // ts_all_store
            // 
            this.ts_all_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_store.ForeColor = System.Drawing.Color.White;
            this.ts_all_store.Image = global::tnerhbeauty.Properties.Resources.store;
            this.ts_all_store.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_store.Name = "ts_all_store";
            this.ts_all_store.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_all_store.Size = new System.Drawing.Size(317, 38);
            this.ts_all_store.Text = "عرض جميع المخازن";
            this.ts_all_store.Click += new System.EventHandler(this.ts_all_store_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.AutoSize = false;
            this.toolStripSeparator10.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator10.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(313, 1);
            // 
            // ts_add_user
            // 
            this.ts_add_user.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_user.ForeColor = System.Drawing.Color.White;
            this.ts_add_user.Image = global::tnerhbeauty.Properties.Resources.add_user;
            this.ts_add_user.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_user.Name = "ts_add_user";
            this.ts_add_user.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_user.Size = new System.Drawing.Size(317, 38);
            this.ts_add_user.Text = "اضافة موظف";
            this.ts_add_user.Click += new System.EventHandler(this.ts_add_user_Click);
            // 
            // ts_all_user
            // 
            this.ts_all_user.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_user.ForeColor = System.Drawing.Color.White;
            this.ts_all_user.Image = global::tnerhbeauty.Properties.Resources.business_man;
            this.ts_all_user.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_user.Name = "ts_all_user";
            this.ts_all_user.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_all_user.Size = new System.Drawing.Size(317, 38);
            this.ts_all_user.Text = "عرض جميع الموظفين";
            this.ts_all_user.Click += new System.EventHandler(this.ts_all_user_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.AutoSize = false;
            this.toolStripSeparator7.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator7.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(313, 1);
            // 
            // ts_add_type_cash
            // 
            this.ts_add_type_cash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_type_cash.ForeColor = System.Drawing.Color.White;
            this.ts_add_type_cash.Image = global::tnerhbeauty.Properties.Resources.visa;
            this.ts_add_type_cash.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_type_cash.Name = "ts_add_type_cash";
            this.ts_add_type_cash.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_type_cash.Size = new System.Drawing.Size(317, 38);
            this.ts_add_type_cash.Text = "اضافة طريقة دفع";
            this.ts_add_type_cash.Click += new System.EventHandler(this.ts_add_type_cash_Click);
            // 
            // ts_all_type_cash
            // 
            this.ts_all_type_cash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_type_cash.ForeColor = System.Drawing.Color.White;
            this.ts_all_type_cash.Image = global::tnerhbeauty.Properties.Resources.analysis;
            this.ts_all_type_cash.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_type_cash.Name = "ts_all_type_cash";
            this.ts_all_type_cash.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_all_type_cash.Size = new System.Drawing.Size(317, 38);
            this.ts_all_type_cash.Text = "عرض طريق دفع";
            this.ts_all_type_cash.Click += new System.EventHandler(this.ts_all_type_cash_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.AutoSize = false;
            this.toolStripSeparator5.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator5.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(313, 1);
            // 
            // ts_add_account
            // 
            this.ts_add_account.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_account.ForeColor = System.Drawing.Color.White;
            this.ts_add_account.Image = global::tnerhbeauty.Properties.Resources.spreadsheet;
            this.ts_add_account.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_account.Name = "ts_add_account";
            this.ts_add_account.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_add_account.Size = new System.Drawing.Size(317, 38);
            this.ts_add_account.Text = "اضافة حساب ايرادات و مصروفات";
            this.ts_add_account.Click += new System.EventHandler(this.ts_add_account_Click);
            // 
            // ts_all_account
            // 
            this.ts_all_account.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_account.ForeColor = System.Drawing.Color.White;
            this.ts_all_account.Image = global::tnerhbeauty.Properties.Resources.balance_scale;
            this.ts_all_account.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_account.Name = "ts_all_account";
            this.ts_all_account.Padding = new System.Windows.Forms.Padding(0, 1, 1, 1);
            this.ts_all_account.Size = new System.Drawing.Size(317, 38);
            this.ts_all_account.Text = "عرض الحسابات";
            this.ts_all_account.Click += new System.EventHandler(this.ts_all_account_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.AutoSize = false;
            this.toolStripSeparator8.BackColor = System.Drawing.Color.White;
            this.toolStripSeparator8.ForeColor = System.Drawing.Color.White;
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(313, 1);
            // 
            // ts_all_user_access_store
            // 
            this.ts_all_user_access_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_user_access_store.ForeColor = System.Drawing.Color.White;
            this.ts_all_user_access_store.Image = global::tnerhbeauty.Properties.Resources.hacker;
            this.ts_all_user_access_store.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_user_access_store.Name = "ts_all_user_access_store";
            this.ts_all_user_access_store.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.ts_all_user_access_store.Size = new System.Drawing.Size(317, 36);
            this.ts_all_user_access_store.Text = "التحكم في الاجهزة المتصلة";
            this.ts_all_user_access_store.Click += new System.EventHandler(this.ts_user_access_store_Click);
            // 
            // ts_add_setting
            // 
            this.ts_add_setting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_add_setting.ForeColor = System.Drawing.Color.White;
            this.ts_add_setting.Image = global::tnerhbeauty.Properties.Resources.private_account;
            this.ts_add_setting.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_add_setting.Name = "ts_add_setting";
            this.ts_add_setting.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.ts_add_setting.Size = new System.Drawing.Size(317, 36);
            this.ts_add_setting.Text = "اضافة نموذج صلاحيات";
            this.ts_add_setting.Click += new System.EventHandler(this.ts_add_setting_Click);
            // 
            // ts_all_setting
            // 
            this.ts_all_setting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_all_setting.ForeColor = System.Drawing.Color.White;
            this.ts_all_setting.Image = global::tnerhbeauty.Properties.Resources.unlock__1_;
            this.ts_all_setting.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_all_setting.Name = "ts_all_setting";
            this.ts_all_setting.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.ts_all_setting.Size = new System.Drawing.Size(317, 36);
            this.ts_all_setting.Text = "عرض نماذج الصلاحيات";
            this.ts_all_setting.Click += new System.EventHandler(this.ts_all_setting_Click);
            // 
            // ts_server
            // 
            this.ts_server.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.ts_server.ForeColor = System.Drawing.Color.White;
            this.ts_server.Image = global::tnerhbeauty.Properties.Resources.database_management;
            this.ts_server.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_server.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_server.Name = "ts_server";
            this.ts_server.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ts_server.Size = new System.Drawing.Size(101, 58);
            this.ts_server.Text = "سيرفر محلي";
            this.ts_server.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_server.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ts_server.Visible = false;
            this.ts_server.Click += new System.EventHandler(this.ts_server_Click);
            // 
            // ts_groub_login
            // 
            this.ts_groub_login.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts_chang_pass,
            this.ts_logout});
            this.ts_groub_login.ForeColor = System.Drawing.Color.White;
            this.ts_groub_login.Image = global::tnerhbeauty.Properties.Resources.user__2_;
            this.ts_groub_login.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_login.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_groub_login.Name = "ts_groub_login";
            this.ts_groub_login.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ts_groub_login.Size = new System.Drawing.Size(66, 58);
            this.ts_groub_login.Text = "user";
            this.ts_groub_login.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ts_groub_login.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ts_chang_pass
            // 
            this.ts_chang_pass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_chang_pass.ForeColor = System.Drawing.Color.White;
            this.ts_chang_pass.Image = ((System.Drawing.Image)(resources.GetObject("ts_chang_pass.Image")));
            this.ts_chang_pass.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_chang_pass.Margin = new System.Windows.Forms.Padding(0, -2, 0, 0);
            this.ts_chang_pass.Name = "ts_chang_pass";
            this.ts_chang_pass.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.ts_chang_pass.Size = new System.Drawing.Size(197, 36);
            this.ts_chang_pass.Text = "تغير كلمة السر";
            this.ts_chang_pass.Click += new System.EventHandler(this.ts_chang_pass_Click);
            // 
            // ts_logout
            // 
            this.ts_logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ts_logout.ForeColor = System.Drawing.Color.White;
            this.ts_logout.Image = global::tnerhbeauty.Properties.Resources.turn_off;
            this.ts_logout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ts_logout.Margin = new System.Windows.Forms.Padding(0, -2, 0, 0);
            this.ts_logout.Name = "ts_logout";
            this.ts_logout.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.ts_logout.Size = new System.Drawing.Size(197, 36);
            this.ts_logout.Text = "تسجيل خروج";
            this.ts_logout.Click += new System.EventHandler(this.ts_logout_Click);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1298, 599);
            this.Controls.Add(this.pan_home);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.home_Load);
            this.Shown += new System.EventHandler(this.home_Shown);
            this.pan_home.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Img_Company)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_max_sale)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_min_balanc)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_max_balanc)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel pan_home;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ts_groub_invoices;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_pay;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_sale;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_to_store;
        private System.Windows.Forms.ToolStripMenuItem ts_groub_product;
        private System.Windows.Forms.ToolStripMenuItem ts_groub_client;
        private System.Windows.Forms.ToolStripMenuItem ts_add_new_client;
        private System.Windows.Forms.ToolStripMenuItem ts_show_all_client;
        private System.Windows.Forms.ToolStripMenuItem ts_kashf_hesab_client;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.PictureBox Img_Company;
        private System.Windows.Forms.ToolStripMenuItem ts_add_amount_client;
        private System.Windows.Forms.ToolStripMenuItem ts_all_amount_client;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_pay;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_sale;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_to_store;
        public System.Windows.Forms.ToolStripMenuItem lb_company;
        private System.Windows.Forms.ToolStripMenuItem ts_groub_report_product;
        private System.Windows.Forms.ToolStripMenuItem ts_report_mabeat_product;
        private System.Windows.Forms.ToolStripMenuItem ts_kashf_hesab_prodct;
        private System.Windows.Forms.ToolStripMenuItem ts_blance_in_storses;
        private System.Windows.Forms.ToolStripMenuItem ts_store_in_and_out;
        private System.Windows.Forms.ToolStripMenuItem ts_groub_login;
        private System.Windows.Forms.ToolStripMenuItem ts_chang_pass;
        private System.Windows.Forms.ToolStripMenuItem ts_logout;
        private System.Windows.Forms.ToolStripMenuItem ts_groub_setting;
        private System.Windows.Forms.ToolStripMenuItem ts_add_setting;
        private System.Windows.Forms.ToolStripMenuItem ts_update_price_producut_exal;
        private System.Windows.Forms.ToolStripMenuItem ts_add_new_product;
        private System.Windows.Forms.ToolStripMenuItem ts_product_min_mum;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem ts_update_price_producut;
        public System.Windows.Forms.ToolStripMenuItem ts_server;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_pay_from_store;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_pay_from_store;
        private System.Windows.Forms.ToolStripMenuItem ts_show_all_product;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private Class.datagrid gv_max_balanc;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private Class.datagrid gv_min_balanc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private Class.datagrid gv_max_sale;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem ts_frm_up_product_min_mum;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_taswiat_khasm;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_return_to_supplier;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_return_from_client;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_taswet_edafa;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_return_to_supplier;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_return_from_client;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_taswet_edafa;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_taswiat_khasm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.ToolStripMenuItem ts_groub_report;
        private System.Windows.Forms.ToolStripMenuItem ts_all_setting;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem ts_all_user;
        private System.Windows.Forms.ToolStripMenuItem ts_add_user;
        private System.Windows.Forms.ToolStripMenuItem ts_add_fara;
        private System.Windows.Forms.ToolStripMenuItem ts_all_fara;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem ts_add_store;
        private System.Windows.Forms.ToolStripMenuItem ts_all_store;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem ts_add_type_cash;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem ts_all_type_cash;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem ts_add_account;
        private System.Windows.Forms.ToolStripMenuItem ts_all_account;
        private System.Windows.Forms.ToolStripMenuItem ts_report_all_amount;
        private System.Windows.Forms.ToolStripMenuItem ts_add_Amount;
        private System.Windows.Forms.ToolStripMenuItem ts_all_amount;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem ts_add_invoice_broken;
        private System.Windows.Forms.ToolStripMenuItem ts_show_invoice_broken;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem ts_all_user_access_store;
    }
}