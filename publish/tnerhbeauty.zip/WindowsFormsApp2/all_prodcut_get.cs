﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using tnerhbeauty.Class;
using tnerhbeauty.rport;
namespace tnerhbeauty
{   
    public partial class all_prodcut_get : Form
    {
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;  // Turn on WS_EX_COMPOSITED
                return cp;
            }
        }
        public all_prodcut_get()
        {
            InitializeComponent();
        }
        DataClasses1DataContext db;
        private async void all_kushufat_Load(object sender, EventArgs e)
        {
            //gv.DataSource = await invoice.GetProductDataAsync(ItemID: 0, id: 0, dt_date_from: DateTime.Now.AddDays(-30), dt_date_to: DateTime.Now);
            //return;
           

            dr_type.IntializeData(invoice.ListInvoiceType.Where(x => x.showClient == true), nameof(invoice_type.name_invoice_type), nameof(invoice_type.id), true);
            dr_report.SelectedIndex = 0;
            dr_fara.IntializeData(cproduct.FaraUser, nameof(fara.name_fara), nameof(fara.id));
            dr_fara.SelectedValue = Session.User_login.id_fara;
            dr_fara_SelectionChangeCommitted(null, null);
            await getdata();            
        }
        private void intion_gv()
        {
            string[] hiddenColumns =
            {
                nameof(prodcut_get_View.id),
                nameof(prodcut_get_View.id_fara),
                nameof(prodcut_get_View.store_id),
                nameof(prodcut_get_View.id_cient),
                nameof(prodcut_get_View.type_qty),
                nameof(prodcut_get_View.id_user),
                nameof(prodcut_get_View.ItemID),
                nameof(prodcut_get_View.ItemQty),
                nameof(prodcut_get_View.id_invoice_type),
                nameof(prodcut_get_View.Net_ItemQty),
                nameof(prodcut_get_View.Net_price),
                nameof(prodcut_get_View.Total),
                nameof(prodcut_get_View.Net_price),
            };

            // إخفاء الأعمدة
            foreach (var columnName in hiddenColumns)
            {
                if (gv.Columns.Contains(columnName))
                {
                    gv.Columns[columnName].Visible = false;
                }
            }
            // تعديل نصوص الأعمدة
            Dictionary<string, string> columnHeaders = new Dictionary<string, string>
        {
            { nameof(prodcut_get_View.name_invoice_type), "العملية" },
            { nameof(prodcut_get_View.Client_name), "اسم العميل" },
            { nameof(prodcut_get_View.code), "كود الصنف" },
            { nameof(prodcut_get_View.product_name), "اسم الصنف" },
            { nameof(prodcut_get_View.Total), "السعر" },
            { nameof(prodcut_get_View.DateServer), "تاريخ الفاتورة" },
            { nameof(prodcut_get_View.is_agel), "اجل" },
            { nameof(prodcut_get_View.name_fara), "الفرع" },
            { nameof(prodcut_get_View.ItemQty_in), " كمية مشتريات" },
            { nameof(prodcut_get_View.ItemQty_out), "كمية مبيعات" },
            { nameof(prodcut_get_View.Price_in), " قيمة مشتريات" },
            { nameof(prodcut_get_View.Price_out), "قيمة مبيعات" },
            { nameof(prodcut_get_View.user_name), "الموظف" },
            { nameof(prodcut_get_View.store_name), "المخزن" }
        };

            foreach (var header in columnHeaders)
            {
                if (gv.Columns.Contains(header.Key))
                {
                    gv.Columns[header.Key].HeaderText = header.Value;
                }
            }

        }
        int id = 0;
        private void bt_serch_client_Click(object sender, EventArgs e)
        {
            selct_sick frm_Clint = new selct_sick();
            frm_Clint.ShowDialog();
            client_View client_View = frm_Clint.GetClient();
            if (client_View != null)
            {
                id = client_View.id;
                tx_name_cient.Text = client_View.name;
            }
        }
        string p_name_client = "";
        string p_prodct = "";
        string p_date_from;
        string p_date_to;
        string p_report_name = "";
        string reportname = "";      
        private async void bt_search_Click(object sender, EventArgs e)
        {
            await getdata();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            id = 0;
            tx_name_cient.Text = "";
        }
        private void gv_kushf_with_marid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.RowIndex < 0)
            //    return;
            //if (reportselct == 0)
            //{
            //    int id = Convert.ToInt32(gv.Rows[e.RowIndex].Cells[0].Value.ToString());
            //    frm_InvoiceHeader_nots kushufat = new frm_InvoiceHeader_nots(id,100000) ;
            //    kushufat.ShowDialog();
            //    bt_search.PerformClick();
            //}
            //if (reportselct == 1)
            //{
            //    ItemID = Session.ConvertInt(gv.Rows[e.RowIndex].Cells[nameof(prodcut_get_View.ItemID)].Value.ToString());
            //    string prod_name = gv.Rows[e.RowIndex].Cells[nameof(prodcut_get_View.product_name)].Value.ToString();
            //    string prod_code = gv.Rows[e.RowIndex].Cells[nameof(prodcut_get_View.code)].Value.ToString();

            //    tx_prodct.Text = prod_name + " " + prod_code;

            //    id = Session.ConvertInt(gv.Rows[e.RowIndex].Cells[nameof(prodcut_get_View.id_cient)].Value.ToString()); ;
            //    tx_name.Text = gv.Rows[e.RowIndex].Cells[nameof(prodcut_get_View.Client_name)].Value.ToString();
            //    dr_report.SelectedIndex = 0;
            //    getdata();
            //}
            //if (reportselct == 2)
            //{
            //    ItemID = Session.ConvertInt(gv.Rows[e.RowIndex].Cells[nameof(prodcut_get_View.ItemID)].Value.ToString());
            //    string prod_name = gv.Rows[e.RowIndex].Cells[nameof(prodcut_get_View.product_name)].Value.ToString();
            //    string prod_code = gv.Rows[e.RowIndex].Cells[nameof(prodcut_get_View.code)].Value.ToString();

            //    tx_prodct.Text = prod_name + " " + prod_code;

            //    //id = 0; ;
            //    //tx_name.Text = "";
            //    dr_report.SelectedIndex = 1;
            //    getdata();
            //}

        }
        int ItemID = 0;
        private void bt_product_Click(object sender, EventArgs e)
        {
            selct_prodct _selct_prodct = new selct_prodct();
            _selct_prodct.ShowDialog();
            product_serch_View prod = _selct_prodct.retrnval();
            if (prod != null)
            {
                ItemID = prod.id;
                tx_prodct.Text = prod.fullname;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ItemID = 0;
            tx_prodct.Text = "";
        }
        private void btn_print_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0)
                return;
            List<ReportParameter> para = new List<ReportParameter>();
            para.Add(new ReportParameter("p_date_from", p_date_from));
            para.Add(new ReportParameter("p_dt_date_to", p_date_to));
            para.Add(new ReportParameter("p_name_client", p_name_client));
            para.Add(new ReportParameter("p_prodct", p_prodct));
            para.Add(new ReportParameter("p_report_name", p_report_name));
            ReportDataSource[] ReportDataSource = new ReportDataSource[]
            {
             new ReportDataSource("prodcut_get_View", gv.DataSource),
            };
            frm_show_report _Report = new frm_show_report(para, reportname, ReportDataSource, true);
            _Report.Show();
        }
        private void dr_fara_SelectionChangeCommitted(object sender, EventArgs e)
        {
            dr_user.IntializeData(Session.usersfara(Session.ConvertInt(dr_fara.SelectedValue.ToString())), nameof(user.user_name), nameof(user.id));
            dr_user.SelectedValue = Session.User_login.id;
            dr_user.Enabled = dr_fara.Enabled = !((Session.Accsess)Session.User_setting().AcssessStore == Session.Accsess.mowazf);
            if (dr_user.SelectedIndex == -1)
                dr_user.SelectedIndex = 0;
        }
        DataTable dt = new DataTable();
        private async Task getdata()
        {
            //DataTable dt = new DataTable();            
            dt = null;
            var parameters = new[]
            {
               new SqlParameter("@ItemID", ItemID),
               new SqlParameter("@id", id),
               new SqlParameter("@dt_date_from", dt_date_from.Value.Date),
               new SqlParameter("@dt_date_to", dt_date_to.Value.Date),
               new SqlParameter("@dr_type", dr_type.SelectedValue),
               new SqlParameter("@id_user", dr_user.SelectedValue),
               new SqlParameter("@id_fara", dr_fara.SelectedValue)
            };
            string query = @"
                SELECT top(300) {0}
                FROM prodcut_get_View
                WHERE
                    ItemID = COALESCE(NULLIF(@ItemID, 0), ItemID)
                AND id_cient = COALESCE(NULLIF(@id, 0), id_cient)
                AND CAST(DateServer AS DATE) BETWEEN @dt_date_from AND @dt_date_to
                AND id_invoice_type = COALESCE(NULLIF(@dr_type, 0), id_invoice_type)
                AND id_user = COALESCE(NULLIF(@id_user, 0), id_user)
                AND (@id_fara = 0 OR id_fara  in (@id_fara))
                ";
            if (dr_report.SelectedIndex == 0)
            {
                query = string.Format(query, " DateServer,  Client_name,  code, product_name, ItemQty_in, Price_in, ItemQty_out, Price_out,  Net_ItemQty,  Net_price, is_agel,  name_fara,  store_name,  user_name, name_invoice_type");
                reportname = "all_prodcut_get";
            }
            else if (dr_report.SelectedIndex == 1)
            {
                // بيانات مجمعة حسب العميل والعنصر
                query = string.Format(query, @"
          
            MAX(Client_name) AS Client_name,
            MAX(product_name) +' '+
            MAX(code) AS product_name,
            SUM(ItemQty_in) AS ItemQty_in,
            SUM(Price_in) AS Price_in,
            SUM(ItemQty_out) AS ItemQty_out,
            SUM(Price_out) AS Price_out,
            SUM(Net_ItemQty) AS Net_ItemQty,
            SUM(Net_price) AS Net_price
            ");
                query += " GROUP BY id_cient, ItemID";
                reportname = "all_prodcut_get_1";
            }
            else if (dr_report.SelectedIndex == 2)
            {
                // بيانات مجمعة حسب العنصر فقط
                query = string.Format(query, @"
                    
                 MAX(product_name) +' '+
                 MAX(code) AS product_name,
                 SUM(ItemQty_in) AS ItemQty_in,
                 SUM(Price_in) AS Price_in,
                 SUM(ItemQty_out) AS ItemQty_out,
                 SUM(Price_out) AS Price_out,
                 SUM(Net_ItemQty) AS Net_ItemQty,
                 SUM(Net_price) AS Net_price                        
             ");
                query += " GROUP BY ItemID";
                reportname = "all_prodcut_get_2";
            }
            else if (dr_report.SelectedIndex == 3)
            {
                // بيانات مجمعة حسب العنصر فقط
                query = string.Format(query, @"                      
                 MAX(Client_name) AS Client_name,           
                 SUM(ItemQty_in) AS ItemQty_in,
                 SUM(Price_in) AS Price_in,
                 SUM(ItemQty_out) AS ItemQty_out,
                 SUM(Price_out) AS Price_out,
                 SUM(Net_ItemQty) AS Net_ItemQty,
                 SUM(Net_price) AS Net_price                      
             ");
                query += " GROUP BY id_cient";
                reportname = "all_prodcut_get_2";
            }
            gv.DataSource = null;
            gv.DataSource = await cproduct.ExecuteQuery(query, parameters);
            intion_gv();
            AddTotalRow();
            p_date_from = null;
            p_date_to = null;
            p_name_client = tx_name_cient.Text;
            p_report_name = dr_report.Text;
            p_date_from = dt_date_from.Value.ToString();
            p_date_to = dt_date_to.Value.ToString();
            p_prodct = tx_prodct.Text;
            if (!Session.User_setting().show_Price_mabeat_product)
            {
                gv.Columns[nameof(prodcut_get_View.Price_in)].Visible = false;
                gv.Columns[nameof(prodcut_get_View.Price_out)].Visible = false;
                btn_print.Visible = false;
                button3.Visible = false;
            }

        }                
        private void AddTotalRow()
        {
            DataTable dt = (DataTable)gv.DataSource;
            // إنشاء صف جديد للإجماليات
            lp_ItemQty_in.Text = dt.AsEnumerable().Sum(x => x.Field<decimal>("ItemQty_in")).ToString("0.000"); // إجمالي الكميات
            lp_ItemQty_out.Text = dt.AsEnumerable().Sum(x => x.Field<decimal>("ItemQty_out")).ToString("0.000"); // إجمالي الأسعار
            lp_Net_ItemQty.Text = dt.AsEnumerable().Sum(x => x.Field<decimal>("Net_ItemQty")).ToString("0.000"); // إجمالي الأسعار
            if(!Session.User_setting().show_Price_mabeat_product)
                return;
            lp_Price_in.Text = dt.AsEnumerable().Sum(x => x.Field<decimal>("Price_in")).ToString("0.00"); // إجمالي الكميات
            lp_Price_out.Text = dt.AsEnumerable().Sum(x => x.Field<decimal>("Price_out")).ToString("0.00"); // إجمالي الأسعار
            lp_Net_price.Text = dt.AsEnumerable().Sum(x => x.Field<decimal>("Net_price")).ToString("0.00"); // إجمالي الأسعار            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (gv.RowCount == 0) return;
            lb_mas.Text = "  جاري انشاء ملف الاكسيل ...";          
            gv.DataSource.ExportDataGridViewToExal((p_report_name + " "+ p_name_client+" "+ p_prodct).Trim());
            lb_mas.Text = @"تم حفظ الملف  \" + Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\EasyTransfer" + @"\" + DateTime.Now.Ticks + "Response.xlsx" + "";
        }
    }
}
